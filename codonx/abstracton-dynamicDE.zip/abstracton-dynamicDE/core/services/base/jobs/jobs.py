from flask import jsonify, request, session, send_from_directory
from flask_restful import Resource, reqparse
#from models import UserModel, RevokedTokenModel, Role
from base.run import jwt, app
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
import base.appconfig as cfg
from base.run import conn
from functools import wraps
import traceback
import datetime
from bson.json_util import loads, dumps
import json, csv, ast
from bson.dbref import DBRef
import re
import hashlib
import os
from bson import ObjectId
import time
import schedule
import threading
from threading import Thread
from base.project import project_resources

class MyThread(threading.Thread): 
  
    # Thread class with a _stop() method.  
    # The thread itself has to check 
    # regularly for the stopped() condition. 
  
    def __init__(self, *args, **kwargs): 
        super(MyThread, self).__init__(*args, **kwargs) 
        self._stop = threading.Event() 
  
    # function using _stop function 
    def stop(self): 
        self._stop.set() 
  
    def stopped(self): 
        return self._stop.isSet() 
  
    def run(self): 
        while True: 
            if self.stopped(): 
                return
            schedule.run_pending()
            print("Running Pending Schedule") 
            time.sleep(1) 
  
 



class StartStatusJob(Resource):
    def get(self):
        global t1
        t1 = MyThread()
        schedule.every(60).seconds.do(project_resources.job)
        t1.start()
        return {"message": "Job started"}

class StopStatusJob(Resource):
    def get(self):
        t1.stop()
        return {"message": "Job stopped"}
