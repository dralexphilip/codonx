from flask import Flask, request
from flask_restful import Api
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from waitress import serve
from base.persistence import schema, conn
import base.appconfig as cfg
import datetime
import schedule
import time
from threading import Thread



app = Flask(__name__, static_url_path="", static_folder="../../ui")
cors = CORS(app)
api = Api(app)

app.config['SECRET_KEY'] = cfg.flask['SECRET_KEY']
app.config['PROPAGATE_EXCEPTIONS'] = cfg.flask['PROPAGATE_EXCEPTIONS']
app.config['UPLOAD_FOLDER'] = cfg.flask['UPLOAD_FOLDER']
app.config['JWT_BLACKLIST_ENABLED'] = cfg.flask['JWT_BLACKLIST_ENABLED']
app.config['JWT_BLACKLIST_TOKEN_CHECKS'] = cfg.flask['JWT_BLACKLIST_TOKEN_CHECKS']
app.config['JWT_SECRET_KEY'] = cfg.flask['JWT_SECRET_KEY']
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = datetime.timedelta(hours=24)

@app.before_first_request
def create_schema():    
    schema.create_schema()

#@app.before_request
#def verify_user_type():    
#    if request.path == '/login':
#        print(request.path)
#
#@app.after_request
def add_header(response):
    response.cache_control.max_age = 60
    if 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'no-store'
    return response

def run_schedule():
    while 1:
        schedule.run_pending()
        time.sleep(1)


jwt = JWTManager(app)

from base.user import user_resources
from base.note import note_resources
from base.abstraction import abstraction_resources
from base.project import project_resources
from base.jobs import jobs

@jwt.token_in_blacklist_loader
def check_if_token_in_blacklist(decrypted_token):
    return user_resources.check_if_token_in_blacklist(decrypted_token)

api.add_resource(user_resources.UserRegistration, '/register')
api.add_resource(user_resources.RegisterBusiness, '/register_business')
api.add_resource(user_resources.GenerateOTP, '/generate_otp')
api.add_resource(user_resources.UserLogin, '/login')
api.add_resource(user_resources.UserLogoutAccess, '/logout/access')
api.add_resource(user_resources.UserLogoutRefresh, '/logout/refresh')
api.add_resource(user_resources.TokenRefresh, '/token/refresh')
api.add_resource(user_resources.AllUsers, '/users')
api.add_resource(user_resources.NewUserCreation, '/new_user')
api.add_resource(user_resources.EnsureAuthenticated, '/ensure_auth')
api.add_resource(user_resources.AllRoles, '/roles')
api.add_resource(user_resources.NewRole, '/new_role')
api.add_resource(user_resources.AllPrivileges, '/privileges')
api.add_resource(note_resources.AllCharts, '/charts')
api.add_resource(note_resources.NewChart, '/new_chart')
api.add_resource(note_resources.UpdateChart, '/update_chart')
api.add_resource(note_resources.UploadFile, '/upload_file')
api.add_resource(note_resources.TempUploadFile, '/get_xml_content')
api.add_resource(note_resources.ViewChart, '/view_chart')
api.add_resource(note_resources.ViewChartDetail, '/chart_detail')
api.add_resource(note_resources.DownloadChart, '/download_chart')
api.add_resource(note_resources.DeleteChart, '/delete_chart')


api.add_resource(project_resources.AllProjects, '/projects')
api.add_resource(project_resources.NewProject, '/new_project')
api.add_resource(project_resources.UpdateProject, '/update_project')
api.add_resource(project_resources.ViewProjectDetail, '/project_detail')
api.add_resource(project_resources.UpdateProjectStatus, '/project_status')
api.add_resource(project_resources.DeleteProject, '/delete_project')

api.add_resource(abstraction_resources.AllAbstractions, '/abstractions')
api.add_resource(abstraction_resources.ViewAbstractionDetail, '/abstraction_detail')
api.add_resource(abstraction_resources.UpdateAbstraction, '/update_abstraction')
api.add_resource(abstraction_resources.ExtractData, '/extract_data')
api.add_resource(abstraction_resources.DownloadExtract, '/download_extract')
api.add_resource(abstraction_resources.AllQAReviews, '/qareviews')
api.add_resource(abstraction_resources.UpdateQA, '/update_qa')
api.add_resource(abstraction_resources.GetTemplate, '/get_template')
api.add_resource(abstraction_resources.DeleteAbstraction, '/delete_abstraction')
api.add_resource(jobs.StartStatusJob, '/start_status_job')
api.add_resource(jobs.StopStatusJob, '/stop_status_job')


api.add_resource(user_resources.AllInvestigators, '/investigators')
api.add_resource(user_resources.NewInvestigator, '/new_investigator')

api.add_resource(project_resources.NewCodelist, '/new_codelist')
api.add_resource(project_resources.AllCodelists, '/codelists')
api.add_resource(project_resources.UpdateCodelist, '/update_codelist')
api.add_resource(project_resources.ViewCodelistDetail, '/codelist_detail')
api.add_resource(project_resources.DeleteCodelist, '/delete_codelist')
api.add_resource(project_resources.GetCodelistConcepts, '/codelist_concepts')

api.add_resource(project_resources.NewDataitem, '/new_dataitem')
api.add_resource(project_resources.AllDataitems, '/dataitems')
api.add_resource(project_resources.UpdateDataitem, '/update_dataitem')
api.add_resource(project_resources.ViewDataitemDetail, '/dataitem_detail')
api.add_resource(project_resources.DeleteDataitem, '/delete_dataitem')

api.add_resource(project_resources.NewTemplate, '/new_template')
api.add_resource(project_resources.AllTemplates, '/templates')
api.add_resource(project_resources.UpdateTemplate, '/update_template')
api.add_resource(project_resources.ViewTemplateDetail, '/template_detail')
api.add_resource(project_resources.DeleteTemplate, '/delete_template')

api.add_resource(project_resources.NewWorkflow, '/new_workflow')
api.add_resource(project_resources.AllWorkflows, '/workflows')
api.add_resource(project_resources.UpdateWorkflow, '/update_workflow')
api.add_resource(project_resources.ViewWorkflowDetail, '/workflow_detail')
api.add_resource(project_resources.DeleteWorkflow, '/delete_workflow')
api.add_resource(project_resources.GetWorkflowStates, '/workflow_states')

if __name__ == '__main__':
##    schedule.every(10).seconds.do(project_resources.job)
##    t = Thread(target=run_schedule)
##    t.start()
    #print("test...test")
    #jobs.main 
    serve(app, host='0.0.0.0', port=5000)
        
