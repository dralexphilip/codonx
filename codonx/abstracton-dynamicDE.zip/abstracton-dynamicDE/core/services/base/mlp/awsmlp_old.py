import boto3
#client = boto3.client(service_name='comprehendmedical', region_name='Sydney')
client = boto3.client(service_name='comprehendmedical', 
<<<<<<< HEAD
                      aws_access_key_id='###', 
                      aws_secret_access_key='###', 
                      region_name='ap-southeast-2'
=======
                      aws_access_key_id='#######', 
                      aws_secret_access_key='######', 
                      region_name='ap-southeast-2########'
>>>>>>> 27e1ec212a7d21e88e57cf3f4c9d3feea8e76b01
                      )
result = client.detect_entities(Text='LESIONS ON BRAIN LESIONS ON BRAIN Active Bipolar disorder Brain stem MRI Colonic Polypectomy')
entities = result['Entities']
for entity in entities:
    print (entity)
