from base.run import app as app
from flask_pymongo import PyMongo
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import datetime
import base.appconfig as cfg


def mongodb(name, user, pwd, server_name=cfg.dbserver['server_name'], port=cfg.dbserver['port']):
    uri = "mongodb://{}:{}@{}:{}/{}".format(user, pwd, server_name, port, name)
    return PyMongo(app, uri=uri)

