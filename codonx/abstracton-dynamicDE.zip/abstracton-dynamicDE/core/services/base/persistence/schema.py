from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import datetime
from pymongo import MongoClient, errors
from base.run import cfg, conn


def generate_hash(password):
    return sha256.hash(password)

def generate_salt():
    return uuid.uuid4().hex

mongo_client_connect = MongoClient('mongodb://{}:{}'.format(cfg.dbserver['server_name'], cfg.dbserver['port']))
mongo = conn.mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'])


def create_schema():

    dbnames = mongo_client_connect.list_database_names()
    if 'basecore' not in dbnames:
        database = mongo_client_connect['basecore']        
    #if not database.command( { "usersInfo": { "user": "alphi", "db": "basecore" } } ):
        database.command("createUser", "alphi", pwd="philip", roles=["readWrite"])
    
    salt = generate_salt()
    password = generate_hash('Password1#'+salt)
    
    if mongo.db.users.find().count() == 0:
        mongo.db.users.insert_one(
            {"username": "codonadmin", "passkey": password, "salt": salt,
             "active": 1, "first_name": "Codon", "last_name": "Admin",
             "created_date": datetime.datetime.utcnow(),
             "roles":[{"_id":1}]}
            )
    
    if mongo.db.roles.find().count() == 0:
        mongo.db.roles.insert_many(
            [{'_id':1, "name": "Admin", "privileges":[{'_id':1}, {'_id':2}, {'_id':3}, {'_id':4}, {'_id':5}, {'_id':6}, {'_id':7}, {'_id':8}, {'_id':9}]}]
            )
    if mongo.db.privileges.find().count() == 0:
        mongo.db.privileges.insert_many(
            [
                {'_id':1, 'name':'View Users'},
                {'_id':2, 'name':'View Roles'},
                {'_id':3, 'name':'View Privileges'},
                {'_id':4, 'name':'Add User'},
                {'_id':5, 'name':'Add Role'},
                {'_id':6, 'name':'View Studies'},
                {'_id':7, 'name':'Add Study'},
                {'_id':8, 'name':'View Investigators'},
                {'_id':9, 'name':'Add Investigator'},
                ]
            )


def create_tenant_schema(data):

    dbnames = mongo_client_connect.list_database_names()
    dbname = (data['business_name']).replace(" ", "")
    data['roles'] = [{'_id':1}]
    if dbname not in dbnames:
        database = mongo_client_connect[dbname]        
        #if not database.command( { "usersInfo": { "user": data['email'], "db": dbname } } ):
        database.command("createUser", data['username'], pwd=cfg.tenantdb['pwd'], roles=["readWrite"])
    
    mongo = conn.mongo(name=dbname, user=data['username'], pwd=cfg.tenantdb['pwd'])
    mongo.db.users.save(data)
    
    if mongo.db.roles.find().count() == 0:
        mongo.db.roles.insert_many(
            [{'_id':1, "name": "Tenant Admin", "privileges":[{'_id':1}, {'_id':2}, {'_id':3}, {'_id':4}, {'_id':5}, {'_id':6}, {'_id':7}, {'_id':8}, {'_id':9}]}]
            )
    if mongo.db.privileges.find().count() == 0:
        mongo.db.privileges.insert_many(
            [
                {'_id':1, 'name':'View Users'},
                {'_id':2, 'name':'View Roles'},
                {'_id':3, 'name':'View Privileges'},
                {'_id':4, 'name':'Add User'},
                {'_id':5, 'name':'Add Role'},
                {'_id':6, 'name':'View Studies'},
                {'_id':7, 'name':'Add Study'},
                {'_id':8, 'name':'View Investigators'},
                {'_id':9, 'name':'Add Investigator'},
                ]
            )

    
