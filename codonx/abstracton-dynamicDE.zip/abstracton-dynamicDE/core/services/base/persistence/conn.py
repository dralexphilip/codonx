from base import run
from flask_pymongo import PyMongo
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import datetime
import base.appconfig as cfg
import urllib


def mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'], server_name=cfg.dbserver['server_name'], port=cfg.dbserver['port']):
    uri = "mongodb://{}:{}@{}:{}/{}".format(urllib.parse.quote(user), urllib.parse.quote(pwd), server_name, port, name)
    return PyMongo(run.app, uri=uri)

