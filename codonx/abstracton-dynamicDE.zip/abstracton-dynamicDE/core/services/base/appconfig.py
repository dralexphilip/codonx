

flask = {'SECRET_KEY': 'codon-for-all',
        'PROPAGATE_EXCEPTIONS': True,
        'MONGO_URI': 'mongodb://alphi:philip@localhost:27017/basecore',
        'UPLOAD_FOLDER': '../uploads/',
        'TEMP_FOLDER': '../temp/',
        'JWT_SECRET_KEY': 'jwt-secret-string',
        'JWT_BLACKLIST_ENABLED': True,
        'JWT_BLACKLIST_TOKEN_CHECKS': ['access', 'refresh'],
        'static_folder': '../ui',
        'static_url_path': ''         
        }

dbserver = {'server_name': 'localhost',
            'port': '27017'
            }

commondb = {'name': 'basecore',
            'user': 'alphi',
            'pwd': 'philip',
            'roles': ["readWrite"]
            }

tenantdb = {'name_prefix': 'codon',
            'pwd': 'philip',
            'roles': ["readWrite"]
            }

email = {
        'email': 'lxphilip@gmail.com',
        'pwd': '',
        'smtp_server': 'smtp.gmail.com',
        'port': 465
        }
