from flask import jsonify, request, session, send_from_directory
from flask_restful import Resource, reqparse
from base.run import jwt, app
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
from functools import wraps
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import traceback
import datetime
from datetime import timezone
from bson import json_util
from bson.json_util import loads, dumps
import json
from bson.dbref import DBRef
import re
import email, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import hashlib
from werkzeug.utils import secure_filename
import glob, os
import lxml.etree as ET
import pdfkit
import base.appconfig as cfg
from base.run import conn
from bson import ObjectId
import random
from random import randint
import xmltodict
import pprint

#parser = reqparse.RequestParser()
#parser.add_argument('username', help = 'This field cannot be blank', required = True)
#parser.add_argument('password', help = 'This field cannot be blank', required = True)

mongo = conn.mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'])

ALLOWED_EXTENSIONS = set(['xml','pdf', 'png', 'jpg', 'jpeg','tif','tiff'])

def privilege(id):
    def true_decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            r = {'message': 'Forbidden'}, 403
            #claims = get_jwt_claims() ##changing this in below line, not working in waitress server
            claims = get_jwt_identity()
            if id not in claims['roles']:
                r = {'message': 'Forbidden'}, 403
            else:
                r = f(*args, **kwargs)
            return r
        return wrapped
    return true_decorator

@jwt.user_claims_loader
def add_claims_to_access_token(user):
    return user


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def file_extension(filename):
    return filename.rsplit('.', 1)[1].lower()

class NewChart(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        if mongo.db.charts.find_one({"chart_id": data['chart_id']}):
            return {'message': 'Chart {} already exists'.format(data['chart_id'])}
        #if data['dob']:
         #   time = datetime.datetime.strptime(data['dob'], '%Y-%m-%dT%H:%M:%S.%fZ')
          #  stamp = time.replace(tzinfo=timezone.utc).timestamp()        
           # data['dob'] = stamp #datetime.datetime.fromtimestamp(stamp).strftime("%m/%d/%Y")
        data['chart_status'] = 'Uploaded'
        data['created_date'] = datetime.datetime.utcnow()

        
        try:
            mongo.db.charts.save(data)
            return {
                'message': 'Chart {} was created'.format(data['patient_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class UpdateChart(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        
        #if data['dob']:
         #   time = datetime.datetime.strptime(data['dob'], '%Y-%m-%dT%H:%M:%S.%fZ')
          #  stamp = time.replace(tzinfo=timezone.utc).timestamp()        
           # data['dob'] = datetime.datetime.fromtimestamp(stamp).strftime("%m/%d/%Y")
        #data['chart_status'] = 'Uploaded'
        #data['created_date'] = datetime.datetime.utcnow()
        
        try:
            chart = mongo.db.charts.find_one({"chart_id": data['chart_id']})
            mongo.db.charts.update({'_id': ObjectId(chart['_id'])},  {'$set': data})
            if not mongo.db.abstractions.find_one({"chart_id": data['chart_id']}):                
                if data['chart_status'] == 'Ready for Abstraction':
                    abstract = {'abstract_id': 'ABS'+random_with_5_digits(),
                                'chart_id': data['chart_id'],
                                'project_id': data['project_id'],
                                'abstract_created_date': datetime.datetime.utcnow(),
                                'abstract_status': 'Ready for Abstraction',
                                'chart': chart}
                    mongo.db.abstractions.save(abstract)
            return {
                'message': 'Chart {} was created'.format(data['patient_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class AllCharts(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        charts = []
        charts = json.loads(dumps(mongo.db.charts.find({"$query":
                                                        {"$and":[{"chart_status": {"$in": ['Uploaded', 'Review in-progress', 'Review Failed']}},
                                                                 {"$or": [{"patient_id": re_search_str},{"patient_name": re_search_str},{"filename": re_search_str}]}]},
                                                                    "$orderby": {sort_field: orderby}}, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        
        total_charts = len(charts)
        
        return {
                "charts": charts,
                'total_count': total_charts
                }


class UploadFile(Resource):
    #@jwt_required
    #@privilege('8')
    def post(self):
        project_id = request.form['project_id']
        chart_id = request.form['chart_id']
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename.replace(' ', ''))
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            if file_extension(file.filename) == 'xml':
                xml_path = app.config['UPLOAD_FOLDER'] + filename
                xsl_path = app.config['UPLOAD_FOLDER']+'xsl/view/'+project_id+'.xsl'
                pdf_path = app.config['UPLOAD_FOLDER'] + chart_id +'.pdf' #os.path.splitext(filename)[0] +'.pdf'
                file_content = getTransformedXml(xml_path, xsl_path)
                content = str(file_content)
                pdf = pdfkit.from_string(content, pdf_path)
                
                
            #data = {"filename": filename
            #        }
            #if file_extension(file.filename) == 'xml':
            #    data = parseXml(filename)
                
            #if mongo.db.charts.find_one({"patient_id": patient_id}):
                #return {'message': 'Chart {} already exists'.format(patient_id)}            
                
            #try:
            #    mongo.db.charts.save(data)
            return {'message': 'Chart was created', 'filename': filename}
            #except:
            #    return {'message': 'Something went wrong'}, 500


class TempUploadFile(Resource):
    #@jwt_required
    #@privilege('8')
    def post(self):
        file = request.files['file']
        project_id = request.form['project_id']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename.replace(' ', ''))
            print(app.config['UPLOAD_FOLDER'], filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            data = {}
            if file_extension(file.filename) == 'xml':
                #data = parseXml(filename)
                data = xmlToJson(filename, project_id)
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
            return {'message': 'Chart was read', 'filename': filename, 'data': data}

class ViewChartDetail(Resource):
    def get(self):
        chart_id = request.args.get('chart_id')
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        chart = json.loads(dumps(mongo.db.charts.find_one({'chart_id': chart_id})))
        chart.pop('_id')
        return {"message": "Chart Available",
                "chart": chart}


class ViewChart(Resource):
    def get(self):
        filename = request.args.get('filename').replace(' ', '')
        xml_path = app.config['UPLOAD_FOLDER'] + filename
        pdf_path = 'base/note/pdf/'+filename+'.pdf'
        xsl_path = 'base/note/xsl/CDA.xsl'
        file_content = getTransformedXml(xml_path, xsl_path)
        content = str(file_content)
        #with open(xml_path, 'r') as file:
            #data = file.read().replace('\n', '')
        pdf = pdfkit.from_string(content, pdf_path)
        return {"message": "Transformed Successfully",
                "file_content": content}


class DownloadChart(Resource):
    def get(self):
        filename = request.args.get('filename')
        root_dir = os.path.dirname(os.getcwd())
        filename = filename + '.pdf'
        #filename = secure_filename(filename.replace(' ', ''))
        #if file_extension(filename) == 'xml':
        #    filename = os.path.splitext(filename)[0] +'.pdf'
        
        uploads = os.path.join(root_dir, 'uploads')#'services', 'base', 'note', 'pdf')
        return send_from_directory(directory=uploads, filename=filename)
            
def getTransformedXml(xml_filename, xsl_filename):
    dom = ET.parse(xml_filename)
    xslt = ET.parse(xsl_filename)
    transform = ET.XSLT(xslt)
    newdom = transform(dom)
    #print(ET.tostring(newdom, pretty_print=True))
    return ET.tostring(newdom, pretty_print=True).decode()

def xmlToJson(filename, project_id):
    xml_path = app.config['UPLOAD_FOLDER'] +'/'+ filename
    xsl_path = app.config['UPLOAD_FOLDER'] +'/xsl/data/'+ project_id +'.xsl'
    file_content = getTransformedXml(xml_path, xsl_path)
    content = str(file_content)
    #with open(xml_path) as fd:
    #    doc = xmltodict.parse(fd.read(), process_namespaces=False)
    doc = xmltodict.parse(content, process_namespaces=False)
    #pp = pprint.PrettyPrinter(indent=4)
    #pp.pprint(json.dumps(doc))   
    return doc



def parseXml(filename):
    xml_path = app.config['UPLOAD_FOLDER'] +'/'+ filename
    ns = {'n1': 'urn:hl7-org:v3'}
    dom = ET.parse(xml_path)
    root = dom.getroot()
    patient_id = root.find('n1:recordTarget/n1:patientRole/n1:id', ns).attrib['extension']
    given_name = root.find('n1:recordTarget/n1:patientRole/n1:patient/n1:name/n1:given', ns).text
    family_name = root.find('n1:recordTarget/n1:patientRole/n1:patient/n1:name/n1:family', ns).text
    gender = root.find('n1:recordTarget/n1:patientRole/n1:patient/n1:administrativeGenderCode', ns).attrib['code']
    dob = root.find('n1:recordTarget/n1:patientRole/n1:patient/n1:birthTime', ns).attrib['value'] + 'T00:00:00.000Z'
    dob = datetime.datetime.strptime(dob, '%Y%m%dT%H:%M:%S.%fZ')
    dob = dob.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    #dob = dob_date.strftime('%m-%d-%Y')
    problem_code = 'Not Found'
    problem_name = 'Not Found'
    problem_date = ''
    problem_system_code = 'Not Found'
    problem_system_name = 'Not Found'
    problem_type = ''
    problems = []
    encounters = []
    encounter_desc = 'None'
    encounter_date = ''
    #problem = root.findall('n1:component/n1:structuredBody/n1:component/n1:section/n1:entry/n1:act/n1:entryRelationship/n1:observation/n1:value', ns).attrib['displayName']
    section_nodes = root.findall("n1:component/n1:structuredBody/n1:component/n1:section", ns)
    for section_node in section_nodes:                
        if '2.16.840.1.113883.10.20.22.2.5' in section_node.find('n1:templateId', ns).attrib['root']:
            problem_nodes = section_node.findall('n1:entry/n1:act/n1:entryRelationship/n1:observation', ns)
            for problem_node in problem_nodes:
                problem_code = problem_node.find('n1:value', ns).attrib['code']
                problem_name = problem_node.find('n1:value', ns).attrib['displayName']
                problem_system_code = problem_node.find('n1:value', ns).attrib['codeSystem']
                problem_date = problem_node.find('n1:effectiveTime/n1:low', ns).attrib['value']
                problem_type = problem_node.find('n1:code', ns).attrib['displayName']
                if len(problem_date) > 6:
                    problem_date = problem_date[:8]
                    problem_in_date = datetime.datetime.strptime(problem_date, '%Y%m%d')
                    problem_date = problem_in_date.strftime('%m-%d-%Y')
                if 'codeSystemName' in problem_node.find('n1:value', ns).attrib:
                    problem_system_name = problem_node.find('n1:value', ns).attrib['codeSystemName']
                elif problem_system_code == '2.16.840.1.113883.6.96':
                    problem_system_name = 'SNOMED CT'
                elif problem_system_code == '2.16.840.1.113883.6.90':
                    problem_system_name = 'ICD 10 CM'
                problem = {"code": problem_code, "name": problem_name, "system_code": problem_system_code,
                           "system_name": problem_system_name, "problem_date": problem_date, "problem_type": problem_type}
                problems.append(problem)
        elif '2.16.840.1.113883.10.20.22.2.22' in section_node.find('n1:templateId', ns).attrib['root']:
            encounter_nodes = section_node.findall('n1:entry/n1:encounter', ns)
            for encounter_node in encounter_nodes:
                encounter_code = encounter_node.find('n1:code', ns).attrib['code']
                if 'value' in encounter_node.find('n1:effectiveTime/n1:low', ns).attrib:
                    encounter_date = encounter_node.find('n1:effectiveTime/n1:low', ns).attrib['value']                            
                elif 'value' in encounter_node.find('n1:effectiveTime', ns).attrib:
                    encounter_date = encounter_node.find('n1:effectiveTime', ns).attrib['value']
                if len(encounter_date) > 6:
                    encounter_date = encounter_date[:8]
                    encounter_in_date = datetime.datetime.strptime(encounter_date, '%Y%m%d')
                    encounter_date = encounter_in_date.strftime('%m-%d-%Y')
                        
                encounter_details = encounter_node.find('n1:code', ns).attrib['displayName']
                if encounter_node.find('n1:text', ns) is not None:                            
                    encounter_desc = (encounter_node.find('n1:text', ns).text).strip()
                encounter_problem_nodes = encounter_node.findall('n1:entryRelationship/n1:act/n1:entryRelationship/n1:observation', ns)
                encounter_problems = []
                for problem_node in encounter_problem_nodes:
                    problem_code = problem_node.find('n1:value', ns).attrib['code']
                    problem_name = problem_node.find('n1:value', ns).attrib['displayName']
                    problem_system_code = problem_node.find('n1:value', ns).attrib['codeSystem']
                    problem_date = problem_node.find('n1:effectiveTime/n1:low', ns).attrib['value']
                    problem_type = problem_node.find('n1:code', ns).attrib['displayName']
                    if len(problem_date) > 6:
                        problem_date = problem_date[:8]
                        problem_in_date = datetime.datetime.strptime(problem_date, '%Y%m%d')
                        problem_date = problem_in_date.strftime('%m-%d-%Y')
                    if 'codeSystemName' in problem_node.find('n1:value', ns).attrib:
                        problem_system_name = problem_node.find('n1:value', ns).attrib['codeSystemName']
                    elif problem_system_code == '2.16.840.1.113883.6.96':
                        problem_system_name = 'SNOMED CT'
                    elif problem_system_code == '2.16.840.1.113883.6.90':
                        problem_system_name = 'ICD 10 CM'
                    encounter_problem = {"code": problem_code, "name": problem_name, "system_code": problem_system_code,
                               "system_name": problem_system_name, "problem_date": problem_date, "problem_type": problem_type}
                    encounter_problems.append(encounter_problem)

                
                encounter = {"code": encounter_code, "details": encounter_details, "encounter_date": encounter_date,
                             "encounter_desc": encounter_desc, "encounter_problems": encounter_problems}
                encounters.append(encounter)                       

            
    return {"patient_id": patient_id,
            "patient_name": given_name+' '+family_name,
            "given_name": given_name,
            "family_name": family_name,
            "dob": dob,
            "gender": gender,
            "filename": filename,
            "problems": problems,
            "encounters": encounters
            }


def random_with_5_digits():
    range_start = 10**(5-1)
    range_end = (10**5)-1
    return str(randint(range_start, range_end))


class DeleteChart(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        chart_id = request.args.get('chart_id')  
        try:
            chart = mongo.db.charts.find_one({"chart_id": chart_id})
            mongo.db.charts.delete_one({'_id': ObjectId(chart['_id'])})
            return {
                'message': 'Chart {} was deleted'.format(chart_id)
                }
        except:
            return {'message': 'Something went wrong'}, 500