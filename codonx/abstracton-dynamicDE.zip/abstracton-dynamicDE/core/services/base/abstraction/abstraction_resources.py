from flask import jsonify, request, session, send_from_directory
from flask_restful import Resource, reqparse
#from models import UserModel, RevokedTokenModel, Role
from base.run import jwt, app
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
from functools import wraps
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import traceback
import datetime
from bson.json_util import loads, dumps
import json, csv, ast
from bson.dbref import DBRef
import re
import hashlib
#import werkzeug
from werkzeug.utils import secure_filename
import os
import base.appconfig as cfg
from base.run import conn
from bson import ObjectId
#import pandas as pd
import time
import schedule

#parser = reqparse.RequestParser()
#parser.add_argument('username', help = 'This field cannot be blank', required = True)
#parser.add_argument('password', help = 'This field cannot be blank', required = True)


mongo = conn.mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'])

ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'csv'])

def privilege(id):
    def true_decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            r = {'message': 'Forbidden'}, 403
            #claims = get_jwt_claims() ##changing this in below line, not working in waitress server
            claims = get_jwt_identity()
            if id not in claims['roles']:
                r = {'message': 'Forbidden'}, 403
            else:
                r = f(*args, **kwargs)
            return r
        return wrapped
    return true_decorator

@jwt.user_claims_loader
def add_claims_to_access_token(user):
    return user


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class AllAbstractions(Resource):
    @jwt_required
    @privilege('6')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
        
        abstractions = []
        abstractions = json.loads(dumps(mongo.db.abstractions.find({"$query":
                                                                    {"$and":[{"abstract_status": {"$in": ['Ready for Abstraction', 'Abstraction in-progress', 'Abstraction Complete']}},
                                                                    {"$or": [{"abstract_id": re_search_str}, {"chart_id": re_search_str}, {"project_id": re_search_str}]}]},
                                                                        "$orderby": {sort_field: orderby}}, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        #print(abstractions)
        #print(len(abstractions))
        total_abstractions = len(abstractions)
        
        return {
                "abstractions": abstractions,
                'total_count': total_abstractions
                }

class AllQAReviews(Resource):
    @jwt_required
    @privilege('6')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
        
        abstractions = []
        abstractions = json.loads(dumps(mongo.db.abstractions.find({"$query":
                                                                    {"$and":[{"abstract_status": {"$in": ['Assigned for QA-review', 'QA-review in-progress', 'QA-review Complete']}},
                                                                    {"$or": [{"abstract_id": re_search_str}, {"chart_id": re_search_str}, {"project_id": re_search_str}]}]},
                                                                        "$orderby": {sort_field: orderby}}, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        
        total_abstractions = len(abstractions)
        
        return {
                "abstractions": abstractions,
                'total_count': total_abstractions
                }


class ViewAbstractionDetail(Resource):
    def get(self):
        abstract_id = request.args.get('abstract_id')
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        abstraction = json.loads(dumps(mongo.db.abstractions.find_one({'abstract_id': abstract_id})))
        abstraction.pop('_id')
        return {"message": "Abstraction Available",
                "abstraction": abstraction}


class UpdateAbstraction(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        abstract_status = 'Abstraction Complete'
        
        #if data['dob']:
         #   time = datetime.datetime.strptime(data['dob'], '%Y-%m-%dT%H:%M:%S.%fZ')
          #  stamp = time.replace(tzinfo=timezone.utc).timestamp()        
           # data['dob'] = datetime.datetime.fromtimestamp(stamp).strftime("%m/%d/%Y")
        #data['chart_status'] = 'Uploaded'
        abstract_date = datetime.datetime.utcnow()
        
        try:
            abstraction = mongo.db.abstractions.find_one({'abstract_id': data['abstract_id']})
            mongo.db.abstractions.update({'_id': ObjectId(abstraction['_id'])},  {'$set': {'abstract_status':abstract_status, 'abstract_by': data['abstract_by'], 'abstract_date': abstract_date, 'data': json.loads(data['data'])}}, upsert=True)
            
            return {
                'message': 'Abstraction {} was updated'.format(data['abstract_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class UpdateQA(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        abstract_status = 'QA Review Complete'
        
        abstract_date = datetime.datetime.utcnow()
        
        try:
            abstraction = mongo.db.abstractions.find_one({'abstract_id': data['abstract_id']})
            mongo.db.abstractions.update({'_id': ObjectId(abstraction['_id'])},  {'$set': {'abstract_status':abstract_status, 'abstract_by': data['abstract_by'], 'abstract_date': abstract_date, 'qa_data': json.loads(data['qa_data'])}}, upsert=True)
            
            return {
                'message': 'QA Review {} was updated'.format(data['abstract_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class ExtractData(Resource):
    def get(self):
        project_id = request.args.get('project_id') 
        abstractions = []
        

        abstractions = json.loads(dumps(mongo.db.abstractions.find({"$and":[{"abstract_status": {"$in": ['Abstraction Complete', 'QA-review Complete']}},
                                                                    {"project_id": project_id}]},{'chart_id':1,'abstract_by':1,'abstract_date':1,'data':1,'_id':0})))

        fieldnames = ['EventID', 'ChartID', 'AbstractorID', 'Field', 'Original_Value', 'Value', 'Code', 'Code_System', 'Abstracted_Date_Time']
        fieldnames = ['ChartID', 'AbstractorID', 'Field', 'Original_Value', 'Value', 'Code', 'Code_System', 'Abstracted_Date_Time']
        data = abstractions
        filename = project_id + time.strftime('_%Y%m%d-%H%M%S')+'.csv'
        with open('base/abstraction/csv/'+filename, 'w', newline='', encoding='utf-8') as outf:
            dw = csv.DictWriter(outf, fieldnames)#data[0]['data'].keys())
            dw.writeheader()
            for d in data:              #json loop
                chart_id = d['chart_id']
                abstractor_id = d['abstract_by']
                abstract_date = d['abstract_date']['$date']
                print(abstract_date)
                
                abstract_date_time = datetime.datetime.fromtimestamp(int(abstract_date)/1000).strftime("%m/%d/%Y %I:%M %p %Z")
                
                icd_code = ''
                coding_scheme = ''
                for key, value in d['data'].items():    #dict loop
                    #r['EventID'] = 'test'
                    new_dict = {'ChartID':chart_id, 'AbstractorID':abstractor_id, 'Field':key, 'Original_Value':value, 'Value':value, 'Code':icd_code, 'Code_System':coding_scheme, 'Abstracted_Date_Time':abstract_date_time}
                    dw.writerow(new_dict)

        project = mongo.db.projects.find_one({'project_id': project_id})
        extraction_status = 'Extract Available'
        mongo.db.projects.update({'_id': ObjectId(project['_id'])},  {'$set': {'extraction_status':extraction_status, 'extraction_file': filename}}, upsert=True)

        return {
                'message': 'Project {} extracts generated'.format(project_id)
                }


class DownloadExtract(Resource):
    def get(self):
        project_id = request.args.get('project_id')
        mongo = conn.mongo(name=cfg.commondb['name'])
        project = mongo.db.projects.find_one({'project_id': project_id})
        print(project['extraction_file'])

        root_dir = os.path.dirname(os.getcwd())
        uploads = os.path.join(root_dir, 'services', 'base', 'abstraction', 'csv')
        return send_from_directory(directory=uploads, filename=project['extraction_file'])


class GetTemplate(Resource):
    def get(self):
        abstract_id = request.args.get('abstract_id')

        abstraction = json.loads(dumps(mongo.db.abstractions.find_one({'abstract_id': abstract_id})))
        print(abstraction)
        project = json.loads(dumps(mongo.db.projects.find_one({'project_id':abstraction['project_id']})))
        print(project)
        template = project['template_data']
        return {"message": "Template Available",
                "template": template
                }

class DeleteAbstraction(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        abstract_id = request.args.get('abstract_id')  
        try:
            abstract = mongo.db.abstractions.find_one({"abstract_id": abstract_id})
            mongo.db.abstractions.delete_one({'_id': ObjectId(abstract['_id'])})
            return {
                'message': 'Abstraction {} was deleted'.format(abstract_id)
                }
        except:
            return {'message': 'Something went wrong'}, 500