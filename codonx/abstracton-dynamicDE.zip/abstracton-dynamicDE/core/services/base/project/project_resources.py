from flask import jsonify, request, session, send_from_directory
from flask_restful import Resource, reqparse
from base.run import jwt, app
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
from functools import wraps
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import traceback
import datetime
from datetime import timezone
from bson.json_util import loads, dumps
import json
from bson.dbref import DBRef
import re
import email, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import hashlib
from werkzeug.utils import secure_filename
import glob, os
import lxml.etree as ET
import pdfkit
import base.appconfig as cfg
from base.persistence import conn
from bson import ObjectId


#parser = reqparse.RequestParser()
#parser.add_argument('username', help = 'This field cannot be blank', required = True)
#parser.add_argument('password', help = 'This field cannot be blank', required = True)

mongo = conn.mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'])

ALLOWED_EXTENSIONS = set(['xml','pdf', 'png', 'jpg', 'jpeg','tif','tiff', 'xsl'])

def privilege(id):
    def true_decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            r = {'message': 'Forbidden'}, 403
            #claims = get_jwt_claims() ##changing this in below line, not working in waitress server
            claims = get_jwt_identity()
            if id not in claims['roles']:
                r = {'message': 'Forbidden'}, 403
            else:
                r = f(*args, **kwargs)
            return r
        return wrapped
    return true_decorator

@jwt.user_claims_loader
def add_claims_to_access_token(user):
    return user


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def file_extension(filename):
    return filename.rsplit('.', 1)[1].lower()

class NewProject(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = json.loads(request.form['data'])
        if "file" in request.files:
            file = request.files['file']
            if file and allowed_file(file.filename):
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'xsl', 'view', data['project_id'])+'.xsl') 
        
        if "src" in request.files:
            file = request.files['src']
            if file and allowed_file(file.filename):
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'xsl', 'data', data['project_id'])+'.xsl') 

        if mongo.db.projects.find_one({"project_id": data['project_id']}):
            return {'message': 'Project {} already exists'.format(data['project_id'])}
        
        data['project_status'] = 'Created'
        data['created_date'] = datetime.datetime.utcnow()
        #data['template_data'] = json.loads(data['template_data'])
        #data['data_access'] = json.loads(dumps(data['data_access']))

        
        try:
            mongo.db.projects.save(data)
            return {
                'message': 'Project {} was created'.format(data['project_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class UpdateProject(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        #file = request.files['file']
        data = json.loads(request.form['data'])
        if "file" in request.files:
            file = request.files['file']
            if file and allowed_file(file.filename):
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'xsl', 'view', data['project_id'])+'.xsl') 

        if "src" in request.files:
            file = request.files['src']
            if file and allowed_file(file.filename):
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'xsl', 'data', data['project_id'])+'.xsl') 
        
        data['created_date'] = datetime.datetime.utcnow()
        #data['template_data'] = json.loads(data['template_data'])
        #data['data_access'] = json.loads(dumps(data['data_access']))
        #data['data_access'].pop('created_date')
        #for user in data['data_access']:
            #print(user)
            #data_access = user['data_access']
            #print(data_access)
            #data_access.pop(user['created_date'])
        
        try:
            project = mongo.db.projects.find_one({"project_id": data['project_id']})
            mongo.db.projects.update({'_id': ObjectId(project['_id'])},  {'$set': data})
            return {
                'message': 'Project {} was updated'.format(data['project_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class AllProjects(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        projects = []
        projects = json.loads(dumps(mongo.db.projects.find({"$query": {"$or":
                                                      [
                                                          {"project_id": re_search_str},
                                                          {"name": re_search_str},
                                                          {"description": re_search_str},
                                                          {"customer": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        
        total_charts = mongo.db.projects.count()
        
        return {
                "projects": projects,
                'total_count': total_charts
                }


class ViewProjectDetail(Resource):
    def get(self):
        project_id = request.args.get('project_id')
        mongo = conn.mongo(name=cfg.commondb['name'])
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        project = json.loads(dumps(mongo.db.projects.find_one({"project_id": project_id})))
        project.pop('_id')
        return {"message": "Project Available",
                "project": project}


class UpdateProjectStatus(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        project_id = request.args.get('project_id') 
        project_status = request.args.get('project_status')
                
        try:
            project = mongo.db.projects.find_one({"project_id": project_id})
            mongo.db.projects.update({'_id': ObjectId(project['_id'])},  {'$set': {'project_status':project_status}}, upsert=False)
            return {
                'message': 'Project {} status was updated'.format(project_id)
                }
        except:
            return {'message': 'Something went wrong'}, 500


def job():
    ids = mongo.db.abstractions.find({'abstract_status': 'Abstraction Complete'})    
    count = mongo.db.abstractions.count({'abstract_status': 'Abstraction Complete'})
    if count > 0:
        #print(ObjectId(ids[0]['_id']))
        bulk = mongo.db.abstractions.initialize_unordered_bulk_op()
        for i in range (0, count):
            bulk.find( { '_id':  ids[i]['_id']}).update({ '$set': {  "abstract_status" : "Assigned for QA-review" }})
        return print(bulk.execute())
    return print('Job: Assigning for QA Review')


class DeleteProject(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        project_id = request.args.get('project_id')  
        try:
            project = mongo.db.projects.find_one({"project_id": project_id})
            mongo.db.projects.delete_one({'_id': ObjectId(project['_id'])})
            return {
                'message': 'Project {} was deleted'.format(project_id)
                }
        except:
            return {'message': 'Something went wrong'}, 500



########Codelists

class NewCodelist(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        if mongo.db.codelists.find_one({"code": data['code']}):
            return {'message': 'Codelist {} already exists'.format(data['code'])}
        #data['created_date'] = datetime.datetime.utcnow()
        #data['template_data'] = json.loads(data['template_data'])
        #data['data_access'] = json.loads(dumps(data['data_access']))
        
        try:
            mongo.db.codelists.save(data)
            return {
                'message': 'Codelist {} was created'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500




class AllCodelists(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        codelists = []
        codelists = json.loads(dumps(mongo.db.codelists.find({"$query": {"$or":
                                                      [
                                                          {"code": re_search_str},
                                                          {"name": re_search_str},
                                                          {"description": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        total_codelists = mongo.db.codelists.count()
        
        return {
                "codelists": codelists,
                'total_count': total_codelists
                }


class UpdateCodelist(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        #data['created_date'] = datetime.datetime.utcnow()
        
        try:
            codelist = mongo.db.codelists.find_one({"code": data['code']})
            mongo.db.codelists.update({'_id': ObjectId(codelist['_id'])},  {'$set': data})
            return {
                'message': 'Codelist {} was updated'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class ViewCodelistDetail(Resource):
    def get(self):
        code = request.args.get('code')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        codelist = json.loads(dumps(mongo.db.codelists.find_one({"code": code})))
        codelist.pop('_id')
        return {"message": "Codelist Available",
                "codelist": codelist}

class GetCodelistConcepts(Resource):
    def get(self):
        code = request.args.get('code')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        codelist = json.loads(dumps(mongo.db.codelists.find_one({"code": code})))
        codelist.pop('_id')
        return codelist.concepts

class DeleteCodelist(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        code = request.args.get('code')  
        try:
            codelist = mongo.db.codelists.find_one({"code": code})
            mongo.db.codelists.delete_one({'_id': ObjectId(codelist['_id'])})
            return {
                'message': 'Codelist {} was deleted'.format(code)
                }
        except:
            return {'message': 'Something went wrong'}, 500



########### Dataitems #############

class NewDataitem(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        if mongo.db.dataitems.find_one({"id": data['id']}):
            return {'message': 'Dataitem {} already exists'.format(data['id'])}
        #data['created_date'] = datetime.datetime.utcnow()
        #data['template_data'] = json.loads(data['template_data'])
        #data['data_access'] = json.loads(dumps(data['data_access']))
        
        try:
            mongo.db.dataitems.save(data)
            return {
                'message': 'Dataitem {} was created'.format(data['id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500




class AllDataitems(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        dataitems = []
        dataitems = json.loads(dumps(mongo.db.dataitems.find({"$query": {"$or":
                                                      [
                                                          {"id": re_search_str},
                                                          {"key": re_search_str},
                                                          {"type": re_search_str},
                                                          {"description": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        total_dataitems = mongo.db.dataitems.count()
        
        return {
                "dataitems": dataitems,
                'total_count': total_dataitems
                }


class UpdateDataitem(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        #data['created_date'] = datetime.datetime.utcnow()
        
        try:
            dataitem = mongo.db.dataitems.find_one({"id": data['id']})
            mongo.db.dataitems.update({'_id': ObjectId(dataitem['_id'])},  {'$set': data})
            return {
                'message': 'Dataitem {} was updated'.format(data['id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class ViewDataitemDetail(Resource):
    def get(self):
        id = request.args.get('id')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        dataitem = json.loads(dumps(mongo.db.dataitems.find_one({"id": id})))
        dataitem.pop('_id')
        return {"message": "Dataitem Available",
                "dataitem": dataitem}

class DeleteDataitem(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        id = request.args.get('id')  
        try:
            dataitem = mongo.db.dataitems.find_one({"id": id})
            mongo.db.dataitems.delete_one({'_id': ObjectId(dataitem['_id'])})
            return {
                'message': 'Dataitem {} was deleted'.format(id)
                }
        except:
            return {'message': 'Something went wrong'}, 500


########### Templates #############

class NewTemplate(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        if mongo.db.templates.find_one({"code": data['code']}):
            return {'message': 'Template {} already exists'.format(data['code'])}
        
        try:
            mongo.db.templates.save(data)
            return {
                'message': 'Template {} was created'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500




class AllTemplates(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        templates = []
        templates = json.loads(dumps(mongo.db.templates.find({"$query": {"$or":
                                                      [
                                                          {"code": re_search_str},
                                                          {"name": re_search_str},
                                                          {"description": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        total_templates = mongo.db.templates.count()
        
        return {
                "templates": templates,
                'total_count': total_templates
                }


class UpdateTemplate(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        #data['created_date'] = datetime.datetime.utcnow()
        
        try:
            template = mongo.db.templates.find_one({"code": data['code']})
            mongo.db.templates.update({'_id': ObjectId(template['_id'])},  {'$set': data})
            return {
                'message': 'Template {} was updated'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class ViewTemplateDetail(Resource):
    def get(self):
        code = request.args.get('code')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        template = json.loads(dumps(mongo.db.templates.find_one({"code": code})))
        template.pop('_id')
        return {"message": "Template Available",
                "template": template}

class DeleteTemplate(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        code = request.args.get('code')  
        try:
            template = mongo.db.templates.find_one({"code": code})
            mongo.db.templates.delete_one({'_id': ObjectId(template['_id'])})
            return {
                'message': 'Template {} was deleted'.format(code)
                }
        except:
            return {'message': 'Something went wrong'}, 500


########Workflows

class NewWorkflow(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        if mongo.db.workflows.find_one({"code": data['code']}):
            return {'message': 'Workflow {} already exists'.format(data['code'])}
        #data['created_date'] = datetime.datetime.utcnow()
        #data['template_data'] = json.loads(data['template_data'])
        #data['data_access'] = json.loads(dumps(data['data_access']))
        
        try:
            mongo.db.workflows.save(data)
            return {
                'message': 'Workflow {} was created'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500




class AllWorkflows(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        workflows = []
        workflows = json.loads(dumps(mongo.db.workflows.find({"$query": {"$or":
                                                      [
                                                          {"code": re_search_str},
                                                          {"name": re_search_str},
                                                          {"description": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        total_workflows = mongo.db.workflows.count()
        
        return {
                "workflows": workflows,
                'total_count': total_workflows
                }


class UpdateWorkflow(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        #data['created_date'] = datetime.datetime.utcnow()
        
        try:
            workflow = mongo.db.workflows.find_one({"code": data['code']})
            mongo.db.workflows.update({'_id': ObjectId(workflow['_id'])},  {'$set': data})
            return {
                'message': 'Workflow {} was updated'.format(data['code'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class ViewWorkflowDetail(Resource):
    def get(self):
        code = request.args.get('code')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        workflow = json.loads(dumps(mongo.db.workflows.find_one({"code": code})))
        workflow.pop('_id')
        return {"message": "Workflow Available",
                "workflow": workflow}

class GetWorkflowStates(Resource):
    def get(self):
        code = request.args.get('code')
        #mongo = conn.mongo(name=cfg.commondb['name']) 
        #claims = get_jwt_identity()
        #if claims['business_name']:
        #    business_name = (claims['business_name']).replace(' ', '')
        #    mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        workflow = json.loads(dumps(mongo.db.workflows.find_one({"code": code})))
        workflow.pop('_id')
        return workflow.states

class DeleteWorkflow(Resource):
    #@jwt_required
    #@privilege('9')
    def delete(self):
        code = request.args.get('code')  
        try:
            workflow = mongo.db.workflows.find_one({"code": code})
            mongo.db.workflows.delete_one({'_id': ObjectId(workflow['_id'])})
            return {
                'message': 'Workflow {} was deleted'.format(code)
                }
        except:
            return {'message': 'Something went wrong'}, 500

