from flask import jsonify, request
from flask_restful import Resource, reqparse
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
from functools import wraps
from base.run import jwt, app
from flask_pymongo import PyMongo
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import traceback
import datetime
from bson.json_util import loads, dumps
import json
import re
import pyotp
import email, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from base.user import otp
import hashlib
from base.run import schema, conn, cfg

#parser = reqparse.RequestParser()
#parser.add_argument('username', help = 'This field cannot be blank', required = True)
#parser.add_argument('password', help = 'This field cannot be blank', required = True)

mongo = conn.mongo(name=cfg.commondb['name'])

def privilege(id):
    def true_decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            r = {'message': 'Forbidden'}, 403
            #claims = get_jwt_claims() ##changing this in below line, not working in waitress server
            claims = get_jwt_identity()
            if id not in claims['roles']:
                r = {'message': 'Forbidden'}, 403
            else:
                r = f(*args, **kwargs)
            return r
        return wrapped
    return true_decorator

@jwt.user_claims_loader
def add_claims_to_access_token(user):
    return user

def generate_hash(passkey):
    return sha256.hash(passkey)

def generate_salt():
    return uuid.uuid4().hex

def verify_hash(passkey, hash):
    return sha256.verify(passkey, hash)

def check_if_token_in_blacklist(decrypted_token):
    jti = decrypted_token['jti']
    if mongo.db.revokedTokens.find_one({"jti": jti}):
        return true

class GenerateOTP(Resource):
    def post(self):
        data = request.get_json(force=True)
        mongo = conn.mongo(name=cfg.commondb['name'])
        if mongo.db.users.find_one({"username": data['email']}):
            return {'message': 'User {} already exists'.format(data['username'])}
        port = cfg.email['port']
        smtp_server = cfg.email['smtp_server']
        sender_email = cfg.email['email']
        receiver_email = data['email']
        context = ssl.create_default_context()        
        totp = otp.generate_otp()
        message = MIMEMultipart("alternative")
        message["Subject"] = "OTP Verification Code: "+ totp['otp']
        message["From"] = sender_email
        message["To"] = receiver_email
        message.attach(MIMEText("OTP Verification Code: "+ totp['otp'], "plain"))
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, cfg.email['pwd'])
            server.sendmail(sender_email, receiver_email, message.as_string())
        
        return totp


class UserRegistration(Resource):
    def post(self):
        data = request.get_json(force=True)
        mongo = conn.mongo(name=cfg.commondb['name'])
        if mongo.db.users.find_one({"username": data['email']}):
            return {'message': 'User {} already exists'.format(data['email'])}
        
        if not otp.verify(data['otp']):
            return {'message': 'OTP is Invalid!'}
        
        salt = generate_salt()
        data['username'] = data['email']
        data['passkey'] = generate_hash(data['passkey']+salt)
        data['active'] = 1
        data['salt'] = salt
        data['first_name'] = (data['first_name']).split()[0]         
        data['last_name'] = (data['first_name']).split()[0]
        data['roles'] = [{'_id':2}]
        data['created_date'] = datetime.datetime.utcnow()
        data.pop('otp')
                
        try:
            mongo.db.users.save(data)
            
            return {
                'message': 'User {} was created'.format(data['username'])
                }
        except:
            return {'message':  'Something went wrong '+traceback.print_exc()}, 500


class RegisterBusiness(Resource):
    def post(self):
        data = request.get_json(force=True)
        mongo = conn.mongo(name=cfg.commondb['name'])
        if mongo.db.users.find_one({"username": data['email']}):
            return {'message': 'Business already registered with {}'.format(data['email'])}
        
        if not otp.verify(data['otp']):
            return {'message': 'OTP is Invalid!'}
        salt = generate_salt()
        business_name = (data['business_name']).replace(" ", "")
        data['username'] = data['email']
        data['passkey'] = generate_hash(data['passkey']+salt)
        data['active'] = 1
        data['salt'] = salt
        data['last_name'] = ''
        data['created_date'] = datetime.datetime.utcnow()
        data['admin_user'] = data['email']
                
        try:            
            schema.create_tenant_schema(data)
            for e in ['passkey', 'roles', 'salt', 'otp']:
                data.pop(e)
            mongo.db.users.save(data)
            
            return {
                'message': 'Business {} was created'.format(data['business_name'])
                }
        except:
            return {'message':  'Something went wrong '+traceback.print_exc()}, 500

class NewUserCreation(Resource):
    @jwt_required
    @privilege('4')
    def post(self):
        data = request.get_json(force=True) 
        mongo = conn.mongo(name=cfg.commondb['name'])
        
        if mongo.db.users.find_one({"username": data['username']}):
            return {'message': 'User {} already exists'.format(data['username'])}
        common_data = data.copy()
        for e in ['passkey', 'roles']:
            common_data.pop(e)
        
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            data['business_name'] = business_name
            common_data['business_name'] = business_name
            admin_user = claims['admin_user']
            data['admin_user'] = admin_user
            common_data['admin_user'] = admin_user
            mongo.db.users.save(common_data)
            mongo = conn.mongo(name=business_name, user=admin_user, pwd=cfg.tenantdb['pwd'])
        
        salt = generate_salt()
        data['passkey'] = generate_hash(data['passkey']+salt)
        data['active'] = 1
        data['salt'] = salt        
        data['created_date'] = datetime.datetime.utcnow()
        def role_to_json(role):
            return {
                '_id': role
            }
        data['roles'] = [role_to_json(role) for role in data['roles']]
        
        try:
            mongo.db.users.save(data)
            return {
                'message': 'User {} was created'.format(data['username'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class NewInvestigator(Resource):
    @jwt_required
    @privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        data['active'] = 1
        data['can_login'] = 'N'
        data['type'] = 'Investigator'
        data['created_date'] = datetime.datetime.utcnow()

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
        
        try:
            mongo.db.users.save(data)
            return {
                'message': 'Investigator {} was created'.format(data['first_name'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class UserLogin(Resource):
    def post(self):
        data = request.get_json(force=True)
        mongo = conn.mongo(name=cfg.commondb['name'])
        
        current_user = json.loads(dumps(mongo.db.users.find_one({"username": data['username']})))        

        if not current_user:
            return {'message': 'User {} doesn\'t exist'.format(data['username'])}
        
        business_name = ''
        admin_user = ''
        
        if 'business_name' in current_user:            
            business_name = (current_user['business_name']).replace(' ', '')
            admin_user = current_user['admin_user']
            mongo = conn.mongo(name=business_name, user=admin_user, pwd=cfg.tenantdb['pwd'])
            current_user = json.loads(dumps(mongo.db.users.find_one({"username": data['username']}))) 
        
        #current_user_roles = [mongo.db.roles.find_one({"_id": role['_id']}, {"_id": 0})['name'] for role in current_user['roles']]
        current_privileges = [mongo.db.roles.find_one({"_id": role['_id']}, {"_id": 0})['privileges'] for role in current_user['roles']]
        current_user_privileges = []
        for privilege in current_privileges:
            for privid in privilege:
                current_user_privileges.append(str(privid['_id']))
        
        

        user = {
            'username': current_user['username'],
            'roles': current_user_privileges,
            'business_name': business_name,
            'admin_user': admin_user
            }
        
        if verify_hash(data['passkey']+current_user['salt'], current_user['passkey']):
            access_token = create_access_token(identity = user)
            refresh_token = create_refresh_token(identity = user)
            return {
                'message': 'Logged in as {}'.format(current_user['username']),
                'access_token': access_token,
                'refresh_token': refresh_token
                }
        else:
            return {'message': 'Wrong credentials'}




class UserLogoutAccess(Resource):
    @jwt_required
    def post(self):
        jti = get_raw_jwt()['jti']
        claims = get_jwt_identity()
        try:
            if claims['business_name']:
                business_name = (claims['business_name']).replace(' ', '')
                mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
                mongo.db.revokedTokens.save({"jti": jti})
                return {'message': 'Access token has been revoked'}
        except:
            return {'message': 'Something went wrong'}, 500


class UserLogoutRefresh(Resource):
    @jwt_refresh_token_required
    def post(self):
        jti = get_raw_jwt()['jti']
        try:
            mongo.db.revokedTokens.save({"jti": jti})
            return {'message': 'Refresh token has been revoked'}
        except:
            return {'message': 'Something went wrong'}, 500


class TokenRefresh(Resource):
    @jwt_refresh_token_required
    def post(self):
        current_user = get_jwt_identity()
        access_token = create_access_token(identity = current_user)
        return {'access_token': access_token}


class AllUsers(Resource):
    @jwt_required
    @privilege('1')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = request.args.get('pageIndex')
        pageSize = request.args.get('pageSize')
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        business_name_exists = False
        if claims['business_name']:
            business_name_exists = True
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
        users = []
        users = json.loads(dumps(mongo.db.users.find({"$query": {"$and": [{"$or":
                                                      [
                                                          {"username": re_search_str},
                                                          {"first_name": re_search_str},
                                                          {"last_name": re_search_str}
                                                          ]},{"type": {"$exists": False }},
                                                          {"business_name": {"$exists": business_name_exists }}]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"passkey": 0, "salt": 0, "_id": 0}).skip(int(pageIndex)).limit(int(pageSize))))
        total_users = mongo.db.users.count({"type": {"$exists": False }})
        
        #for user in users:
        #    del user['password']
        #    del user['salt']
        return {
                "users": users,
                'total_count': total_users
                }


class AllInvestigators(Resource):
    @jwt_required
    @privilege('8')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = request.args.get('pageIndex')
        pageSize = request.args.get('pageSize')

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        users = []
        users = json.loads(dumps(mongo.db.users.find({"$query": {"$and": [{"$or":
                                                      [
                                                          
                                                          {"first_name": re_search_str},
                                                          {"last_name": re_search_str}
                                                          ]},{"type": "Investigator"}]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"passkey": 0, "salt": 0, "_id": 0}).skip(int(pageIndex)).limit(int(pageSize))))

        return {
                "users": users,
                'total_count': len(users)
                }


class AllRoles(Resource):
    @jwt_required
    @privilege('2')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = ""
        
        if search_str.isdigit():
            search_str = int(search_str)
        else:
            re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = request.args.get('pageIndex')
        pageSize = request.args.get('pageSize')
        
        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
            
        roles = json.loads(dumps(mongo.db.roles.find({"$query": {"$or":
                                                      [
                                                          {"_id": search_str},
                                                          {"name": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }).skip(int(pageIndex)).limit(int(pageSize))))
        for role in roles:
            role['id'] = role.pop('_id')
        return {
            "roles": roles,
            'total_count': len(roles)
            }

class NewRole(Resource):
    @jwt_required
    @privilege('5')
    def post(self):
        data = request.get_json(force=True)

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])
        
        if mongo.db.roles.find_one({"_id": data['role_id']}):
            return {'message': 'Role {} already exists'.format(data['role_id'])}

        
        def privilege_to_json(privilege):
            return {
                '_id': privilege
            }
        
        data['_id'] = data.pop('role_id')
        data['name'] = data.pop('role_name')
        data['privileges'] = [privilege_to_json(privilege) for privilege in data['privileges']]
        data['active'] = 1
        data['created_date'] = datetime.datetime.utcnow()
        
        try:
            mongo.db.roles.save(data)
            return {
                'message': 'Role {} was created'.format(data['name'])
                }
        except:
            return {'message': 'Something went wrong'}, 500
        

class AllPrivileges(Resource):
    @jwt_required
    @privilege('3')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = ""
        if search_str.isdigit():
            search_str = int(search_str)
        else:
            re_search_str = re.compile(search_str, re.IGNORECASE)         
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = request.args.get('pageIndex')
        pageSize = request.args.get('pageSize')

        mongo = conn.mongo(name=cfg.commondb['name'])
        claims = get_jwt_identity()
        if claims['business_name']:
            business_name = (claims['business_name']).replace(' ', '')
            mongo = conn.mongo(name=business_name, user=claims['admin_user'], pwd=cfg.tenantdb['pwd'])

        privileges = json.loads(dumps(mongo.db.privileges.find({"$query": {"$or":
                                                      [
                                                          {"_id": search_str},
                                                          {"name": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }).skip(int(pageIndex)).limit(int(pageSize))))
        
        for privilege in privileges:
            privilege['id'] = privilege.pop('_id')
        return {
            "privileges": privileges,
            'total_count': len(privileges)
            }


class EnsureAuthenticated(Resource):
    @jwt_required
    def get(self):
        return {'isAuthenticated': 1}


