from flask import jsonify, request, session
from flask_restful import Resource, reqparse
from base.run import jwt, app
from flask_jwt_extended import (create_access_token, create_refresh_token, jwt_required, jwt_refresh_token_required, get_jwt_identity, get_raw_jwt, get_jwt_claims)
from functools import wraps
from passlib.hash import pbkdf2_sha256 as sha256
import uuid
import traceback
import datetime
from bson.json_util import loads, dumps
import json
from bson.dbref import DBRef
import re
import email, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import hashlib
from werkzeug.utils import secure_filename
import os
import base.appconfig as cfg
from base.run import conn

#parser = reqparse.RequestParser()
#parser.add_argument('username', help = 'This field cannot be blank', required = True)
#parser.add_argument('password', help = 'This field cannot be blank', required = True)

mongo = conn.mongo(name=cfg.commondb['name'], user=cfg.commondb['user'], pwd=cfg.commondb['pwd'])

ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'csv'])

def privilege(id):
    def true_decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            r = {'message': 'Forbidden'}, 403
            #claims = get_jwt_claims() ##changing this in below line, not working in waitress server
            claims = get_jwt_identity()
            if id not in claims['roles']:
                r = {'message': 'Forbidden'}, 403
            else:
                r = f(*args, **kwargs)
            return r
        return wrapped
    return true_decorator

@jwt.user_claims_loader
def add_claims_to_access_token(user):
    return user


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class NewStudy(Resource):
    #@jwt_required
    #@privilege('9')
    def post(self):
        data = request.get_json(force=True) 
        
        if mongo.db.studies.find_one({"study_id": data['study_id']}):
            return {'message': 'Study {} already exists'.format(data['study_id'])}
        
        data['active'] = 'Yes'
        data['created_date'] = datetime.datetime.utcnow()

        
        try:
            mongo.db.studies.save(data)
            return {
                'message': 'Study {} was created'.format(data['study_id'])
                }
        except:
            return {'message': 'Something went wrong'}, 500


class AllStudies(Resource):
    @jwt_required
    @privilege('8')
    def get(self):
        search_str = request.args.get('filter')
        re_search_str = re.compile(search_str, re.IGNORECASE)
        sort_field = request.args.get('sortField')
        sortDirection = request.args.get('sortDirection')
        orderby = 1
        if sortDirection != 'asc':
            orderby = -1
        pageIndex = int(request.args.get('pageIndex'))
        pageSize = request.args.get('pageSize')
        studies = []
        studies = json.loads(dumps(mongo.db.studies.find({"$query": {"$or":
                                                      [
                                                          {"study_id": re_search_str},
                                                          {"title": re_search_str},
                                                          {"phase": re_search_str}
                                                          ]
                                                      }, "$orderby": {sort_field: orderby}
                                                               }, {"_id": 0}).skip(pageIndex*10).limit(int(pageSize))))
        
        total_studies = mongo.db.studies.count()
        
        return {
                "studies": studies,
                'total_count': total_studies
                }


class UploadFile(Resource):
    #@jwt_required
    #@privilege('8')
    def post(self):
        file = request.files['file']
        if file and allowed_file(file.filename):
            # From flask uploading tutorial
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return {'success': 'True'}
        else:
            return {'success': 'False'}
            


        
