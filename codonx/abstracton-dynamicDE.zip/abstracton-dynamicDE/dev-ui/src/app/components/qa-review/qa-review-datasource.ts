import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Abstract } from '../../models/abstract';
import { UserService } from '../../services/user.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';


export class AbstractDataSource extends DataSource<Abstract> {

  private abstractionsSubject = new BehaviorSubject<Abstract[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  data: Abstract[]=[];
  total_count: number;
  

  constructor(private service: UserService) {
    super();
  }
  
  loadAbstractions(filter:string,
			sortField:string,
			sortDirection:string,
			pageIndex:number,
			pageSize:number) {
	console.log("testing");
	this.loadingSubject.next(true);

	this.service.allQAReviews(localStorage.getItem('token'), filter, sortField, sortDirection,
		pageIndex, pageSize).pipe(
			catchError(() => of([])),
			finalize(() => this.loadingSubject.next(false))
		)
		.subscribe((allAbstractions) => {
			this.total_count = allAbstractions.total_count,
			this.abstractionsSubject.next(allAbstractions.abstractions)
		});
  }
  
  connect(collectionViewer: CollectionViewer): Observable<Abstract[]> {
	console.log("Connecting data source");
	return this.abstractionsSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
	this.abstractionsSubject.complete();
	this.loadingSubject.complete();
  }


}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
