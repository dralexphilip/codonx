import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QaReviewComponent } from './qa-review.component';

describe('QaReviewComponent', () => {
  let component: QaReviewComponent;
  let fixture: ComponentFixture<QaReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QaReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QaReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
