import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjudication',
  templateUrl: './adjudication.component.html',
  styleUrls: ['./adjudication.component.css']
})
export class AdjudicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
