import {Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormGroupDirective, FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { UploadService } from '../../services/upload.service';
import { Chart } from '../../models/chart';
import { Subject, Observable } from 'rxjs';
import {MatAccordion} from '@angular/material/expansion';
import states from '../../resources/states.json';
import { Project } from '../../models/project';
import { map, startWith } from 'rxjs/operators';
import { FormlyFieldConfig, FormlyFormOptions } from '@ngx-formly/core';


@Component({
  selector: 'app-new-chart',
  templateUrl: './new-chart.component.html',
  styleUrls: ['./new-chart.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class NewChartComponent implements OnInit {

  @ViewChild('file', { static: false }) file;
  @ViewChild(FormGroupDirective, { static: false }) formDirective: FormGroupDirective;
  
  public files: Set<File> = new Set();
  showChartDetail = false;
  selectedFile = null;  
  uploading = false;  
  chart: FormGroup;  
  charts: Chart[] = [];
  filename;
  genders = ["Male", "Female", "Other"]
  step = 0;
  states = states;
  projects: Project[] = [];
  filteredOptions: Observable<Project[]>;
  project = new FormControl();
  project_id: string;

  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[];

			

  constructor(private fb: FormBuilder, private router: Router, private auth: UserService, public uploadService: UploadService) { }
  
  onSubmit({ value, valid }: { value: Chart, valid: boolean }): void{
	  console.log(this.model);
	
	let status = 0;
	if (this.form.valid){
		this.uploading = true;
		let data: any =	this.uploadService.upload(this.selectedFile, this.project_id, this.model['chart_id']); 		
		for(let file_status in data)
			{				
				let file_observable: any = data[file_status].progress;
				console.log(file_observable);
				file_observable.subscribe(resp => {
					status = resp;
					console.log(status);
					if (status === 100) {
						this.auth.newChart(localStorage.getItem('token'),this.form.value)
							.subscribe((data) => {
							  this.uploading = false;
							  this.files.delete(this.selectedFile);
							  this.showChartDetail=false;
							  this.chart.reset();
							  this.formDirective.resetForm();
							  var iterator = this.files.values();
							  if (this.files.size != 0){
								this.selectFile(iterator.next().value);
							  }
							});
					}
				});
				
				
                
			}
	
	}
	
  }

  ngOnInit() {	  	  
   	this.getProjects();
   	
  
   this.chart = this.fb.group({
	chart_id: [null, Validators.required],
	patient_id: [null, Validators.required],
	project_id: [null, Validators.required],
	lastname: [null, Validators.required], 
	firstname: [null, Validators.required],
	middlename: null,
	dob: null,
	age: [null, Validators.compose([Validators.minLength(1), Validators.maxLength(3)])],
	gender: [null, Validators.required],
	filename: null,
	upload_file: null,
	address: null,
	city: null,
	state: null,		
	postalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
	cplastname: null, 
	cpfirstname: null,
	cpmiddlename: null,
	cpaddress: null,
	cpcity: null,
	cpstate: null,		
	cppostalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
	npi: null,
	facility: null
  });	
  }
  
  onFilesAdded(event) {
    const files: { [key: string]: File } = this.file.nativeElement.files;
	
    for (let key in files) {
      if (!isNaN(parseInt(key))) {
        this.files.add(files[key]);
      }	  
    }
	let first_file = this.file.nativeElement.files[0];
	this.selectFile(first_file);
  }

  addFiles() {
    this.file.nativeElement.click();
  }


  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
	  const element = event[index];
	  if(index == 0) {
		  this.selectFile(element);
		}
      
      this.files.add(element)
    }  	
	
	
  }
  deleteAttachment(file) {
    this.files.delete(file);
	if(this.files.size == 0){
		this.showChartDetail = false;
	}
	else {
		this.selectFile(this.file.nativeElement.files[0])
	}
  }
   
  selectFile(file) {
	this.selectedFile = file;	
	this.filename = file.name.replace(/\s/g, "");
	this.chart.patchValue({'filename':this.filename});
	this.model['filename'] = this.filename;
	//this.chart.patchValue({'status':'Uploaded'});
	this.showChartDetail = true;	
	//var iterator = this.files.values();
	this.getXmlContent();
  }
  
  onCancel(){
	this.router.navigateByUrl('/main/charts');
  }
  
  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
  
  getProjects(){
	  this.auth.allProjects(localStorage.getItem('token'), '', 'name', 'asc', 0, 100)
		.subscribe((data) => {
		this.projects = data.projects,
		this.filteredOptions = this.project.valueChanges.pipe(
			startWith(''),
			map(value => typeof value === 'string' ? value : value.name),
			map(project => project ? this._filter(project) : this.projects.slice())
		)}
		);
  }
  
  previewChart(file){
	  let fileType =  file.type;
	  console.log(file.type);
	  if (file.type == 'text/xml') {
		  let xsltContent;
		  let xmlContent;
		  this.auth.getCdaXsl()
			.subscribe((data) => {
			  xsltContent = data;
			  
			  let fileReader = new FileReader();
			  fileReader.readAsText(file)
			  fileReader.onloadend = function(){
			  xmlContent = fileReader.result;
			  const parser = new DOMParser();
			  let xsl_doc = parser.parseFromString(xsltContent, "application/xml");
			  let xml_doc = parser.parseFromString(xmlContent, "application/xml");
			  const xsltProcessor = new XSLTProcessor();
			  xsltProcessor.importStylesheet(xsl_doc);
			  const html = xsltProcessor.transformToDocument(xml_doc);
			  let xmlwin = window.open("", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
			  xmlwin.document.write(html.documentElement.innerHTML);
			};				  
		  });		
	  }
	  if (file.type == 'application/pdf') {
		  let blob = new Blob([file], { type: 'application/pdf'});
		  let url = window.URL.createObjectURL(blob);
		  window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
	  }
  }

  getXmlContent(){
	this.auth.getXmlContent(localStorage.getItem('token'),this.selectedFile, this.project_id)
	.subscribe((data) => {
		console.log(data);
		//this.chart.patchValue({patient_id: data.data.ClinicalDocument.recordTarget.patientRole.id['@extension']});
		this.chart.patchValue({firstname: data.data.data.content.given});
		this.chart.patchValue({lastname: data.data.data.content.family});
		this.chart.patchValue({gender: data.data.data.content.gender});
		//this.chart.patchValue({firstname: data.data.ClinicalDocument.recordTarget.patientRole.patient.name.given});
		//this.chart.patchValue({address: data.data.ClinicalDocument.component.structuredBody.component[0].section.code['@code']});
		//const dob_json = data.data.ClinicalDocument.recordTarget.patientRole.patient.birthTime['@value'];
		//this.chart.patchValue({dob: this.fromJsonDate(dob_json)});
		//this.chart.patchValue({age: new Date().getFullYear() - +this.fromJsonDate(dob_json).substring(0,4)});
		//const genderCode = data.data.ClinicalDocument.recordTarget.patientRole.patient.administrativeGenderCode['@code'];
		//var genderText = (genderCode == 'M'? 'Male': genderCode == 'F'? 'Female':'Other');
		//this.chart.patchValue({gender: genderText});
		
		this.model = {"project_id": this.project_id};
		this.model['lastname'] = data.data.data.content.given;
		this.model['firstname'] = data.data.data.content.family;
		this.model['gender'] = data.data.data.content.gender;
		this.model['dob'] = data.data.data.content.dob;
		this.model['patient_id'] = data.data.data.content.ids.id;
		//this.model.accordion.demoPanel.row1.chart_id = '2345';
		//this.model.accordion.demoPanel['row2']['lastname'] = data.data.data.content.name;
		console.log(this.model);
	});
  }

  fromJsonDate(jDate): string {	
	const bDate: Date = new Date(jDate.substring(0,4)+'-'+jDate.substring(4,6)+'-'+jDate.substring(6,8) + 'T00:00:00.000Z');
	console.log(bDate);
	console.log(jDate.substring(0,4)+'-'+jDate.substring(4,6)+'-'+jDate.substring(6,8) + ' T00:00:00.000Z');
	return bDate.toISOString().substring(0, 10);  //Ignore time
  }

  private _filter(value: string): Project[] {
	const filterValue = value.toLowerCase();	
	return this.projects.filter(item => item.name.toLowerCase().indexOf(filterValue) === 0);
  }

  displayFn(project: Project): string {
	return project && project.name +' ['+ project.project_id +']' ? project.name +' ['+ project.project_id +']' : '';
  }

  selectedProject(event,option){
	console.log(option.project_id);  
	if (event.source.selected) {
		this.project_id = option.project_id;
		this.chart.patchValue({'project_id': option.project_id});
		this.getInitialTemplate(option.project_id);
	}
	//this.project_id = option.project_id;
  }

  getInitialTemplate(project_id){
	const chart_status = 'START';
	this.auth.viewProjectDetail(localStorage.getItem('token'), project_id)
		.subscribe((data) => {
			console.log(data.project.workflow.states[0].template.fields)
		  	this.fields = data.project.workflow.states.find(x => x.code === chart_status).template.fields;
	});
  }

}


function getKeyValues(data, parent = '') {
    var q = [];
    var keys = Object.keys(data);
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        var value = data[key];
        if (value == null) {
            //q.push(parent+'.'+key);
        } else if (typeof value == "object") {
			//getKeyValues(value, key);
			if(Array.isArray(value)){
				//if(!isReallyAPlainArray(value))
					//q.push(getKeyValues(value, parent+'.'+key+'----test----'));
				//else 
				console.log(value.length + '='+isNaN(+Object.keys(value)[0]))
				console.log(typeof value == "object");
				if (value.length > 0 && typeof value[0] != "object")
					q.push(parent+'.'+key);
				else if (typeof value[0] == "object"){
					value.forEach(element => {
						if (element != null && Object.keys(element).length < 0){
							q.push(getKeyValues(element, parent+'.'+key+'----test----'));
						}						//q.push(parent+'.'+key+'.'+getKeyValues(element, key));
					});
				}
			}
			//getKeyValues(value, parent+'.'+key);
            q.push(getKeyValues(value, parent+'.'+key));
        } else {
            q.push(parent+'.'+key);
        }
    }
    return q.join(",");
}

