import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyFormOptions, FormlyFieldConfig } from '@ngx-formly/core';
import template from '../../resources/default-template.json';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { Abstract } from '../../models/abstract';
import { map, catchError, finalize } from 'rxjs/operators';
import { Subject, Observable, of } from 'rxjs';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-abstract-form',
  templateUrl: './abstract-form.component.html',
  styleUrls: ['./abstract-form.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AbstractFormComponent implements OnInit{
	
  abstraction: Abstract = null;
  step = 0;  
  panelOpenState = false;  
  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[];
  
  abstract_id;
  src;
  viewfilename;
  showChartDetail = true;
  from_component;
   
   constructor( private service: UserService, private router: Router, private route: ActivatedRoute ) { }
   
   ngOnInit() {
	console.log(JSON.stringify(this.fields));
	
	
  
  //console.log(JSON.parse(template));
	this.route.queryParams.subscribe((queryParams:any) => {
		//console.log(queryParams);
      this.abstract_id = queryParams['abstract_id'];
	  this.viewfilename = queryParams['filename'];
	  this.from_component = queryParams['t'];
     });	
	 
	 
	this.getTemplate(this.abstract_id) 
	this.viewAbstractionDetail(this.abstract_id);  
	this.viewChart(this.viewfilename);
  
   }
   
   setStep(index: number) {
    this.step = index;
  }
  
  getTemplate(abstract_id){
	this.service.getTemplate(localStorage.getItem('token'), abstract_id)
		.subscribe((data) => {
		  this.fields = data.template.fields;
	});
  }
  
  submit() {
	let token = localStorage.getItem('token');
	let jwtData = token.split('.')[1];
	let decodedJwtJsonData = window.atob(jwtData);
	let decodedJwtData = JSON.parse(decodedJwtJsonData);
	let username = decodedJwtData.identity.username;
	//this.abstraction = {"abstract_id": null, "abstract_date": null, "abstract_by": username,"chart_id": null, "project_id": null, "data": this.model, "nlp_data": null};
	//let abstract_data = JSON.stringify(this.model);
	  //instead of this.model using form.value to have all fields
	this.abstraction.abstract_by = username;
	//console.log(this.model);
	//console.log(this.form.value);
	//console.log(this.abstraction.data);
	//console.log(this.abstraction);
    if (this.form.valid) {
      //alert(JSON.stringify(this.model));
	  if (this.from_component == 'abs'){ //abstraction
		  this.abstraction.data = JSON.stringify(this.form.value);
		  this.service.updateAbstraction(localStorage.getItem('token'), this.abstraction)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main/abstraction');
			}); 
	  }
	  else { //qa review
		  this.abstraction.qa_data = JSON.stringify(this.form.value);
		  this.service.updateQA(localStorage.getItem('token'), this.abstraction)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main/qa-review');
			}); 
	  }
    }
  }
  
  
  viewAbstractionDetail(abstract_id) {
	this.service.viewAbstractionDetail(localStorage.getItem('token'), abstract_id).pipe(
			catchError(() => of([])),
			finalize(() => console.log('Success'))
		)
		.subscribe((data) => {
			//this.created_date = data.astract.created_date.$date;
			//delete data.abstract['created_date'];
			//data.chart['fail_reason'] = '';
			//data.chart['review_comments'] = '';
			//this.chart.setValue(data.chart);
			this.abstraction = data.abstraction;
			//this.abstraction.data.options = this.getCodelistConcepts('GENDER');
			if (data.abstraction.data != null && this.from_component == 'abs'){				
				//data.abstraction.data['stepper']['step3']['panel2']['fieldRow']['bpValue'] ='120/80';
				//console.log(data.abstraction.data);
				this.model = data.abstraction.data;
				
			}
			else if (data.abstraction.qa_data != null){
				this.model = data.abstraction.qa_data;
			}		
		});  
  }
  
  viewChart(filename) {
	this.service.downloadChart(localStorage.getItem('token'), filename).subscribe(response => this.viewFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
				 
  }
  viewFile(data: any, type: string) {
		let blob = new Blob([data], { type: type});
        this.src = window.URL.createObjectURL(blob);
        //window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
  }
  
  previewChart() {
	this.service.downloadChart(localStorage.getItem('token'), this.viewfilename).subscribe(response => this.previewFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
				 
	
	//window.open('/main/charts/view_chart?filename='+filename, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800")
  }
  
  previewFile(data: any, type: string) {
		this.showChartDetail = false;
		let blob = new Blob([data], { type: type});
        let url = window.URL.createObjectURL(blob);
        window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
  }
  
  splitView() {
	this.showChartDetail = true;
  }
  
}

