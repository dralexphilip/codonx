import { Component } from '@angular/core';
import { FieldWrapper } from '@ngx-formly/core';

@Component({
  selector: 'formly-row-panel',
  template: `
    
        <ng-container #fieldComponent></ng-container>
    
    
  `,
})
export class RowWrapperComponent extends FieldWrapper {
}