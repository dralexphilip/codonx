import { Component } from '@angular/core';
import { FieldWrapper } from '@ngx-formly/core';

@Component({
  selector: 'formly-accordion-panel',
  template: `
    
    <mat-accordion class="example-headers-align" #panel>

    

    <mat-expansion-panel [expanded]=panel.templateOptions.expand *ngFor="let panel of field.fieldGroup;">
    <mat-expansion-panel-header> 
		<mat-panel-title> {{ panel.templateOptions.label }} </mat-panel-title>
		<mat-panel-description>  {{ panel.templateOptions.description }} <mat-icon color="accent">{{panel.templateOptions.icon}}</mat-icon>
		 </mat-panel-description>
	</mat-expansion-panel-header>
  <formly-field [field]="panel"></formly-field>
    </mat-expansion-panel>
    </mat-accordion>
    
  `,
})
export class AccordionWrapperComponent extends FieldWrapper {
}