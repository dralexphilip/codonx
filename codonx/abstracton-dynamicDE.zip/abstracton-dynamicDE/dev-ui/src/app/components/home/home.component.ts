import { Component } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  /** Based on the screen size, switch from standard to one column per row */
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Studies', cols: 1, rows: 1, ui: 'app-users' },
          { title: 'Roles', cols: 1, rows: 1, ui: 'app-roles' },
          { title: 'Privileges', cols: 1, rows: 1, ui: 'app-permissions' }
        ];
      }

      return [
        { title: 'Users', cols: 2, rows: 2 },
        { title: 'Roles', cols: 1, rows: 1 },
        { title: 'Privileges', cols: 1, rows: 2 },
        { title: 'Card 4', cols: 1, rows: 1 }
      ];
    })
  );

  constructor(private breakpointObserver: BreakpointObserver) {}
}
