import { AfterViewInit, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { State } from '../../models/state';
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from '../select-users/select-users.component';
import { WorkflowService } from '../../services/workflow.service';
import { catchError, finalize, map, startWith } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Workflow } from '../../models/workflow';
import { Codelist } from '../../models/codelist';
import { CodelistService } from '../../services/codelist.service';
import { Template } from '../../models/template';
import { TemplateService } from '../../services/template.service';




@Component({
  selector: 'app-workflow-form',
  templateUrl: './workflow-form.component.html',
  styleUrls: ['./workflow-form.component.css']
})
export class WorkflowFormComponent implements OnInit, AfterViewInit {

	@ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  	@ViewChild(MatSort, { static: false }) sort: MatSort;

  	hide = true;
	workflow: FormGroup;	
	states_data: State[] = [];
  	displayedColumns = ['code', 'name', 'description', 'allowedStates', 'edit', 'delete'];
	dataSource: MatTableDataSource<State>;
	stateEditMode: boolean = false;
	editMode: boolean = false;
	code: string;

	codelists: Codelist[] = [];
  	filteredOptions: Observable<Codelist[]>;
	codelist = new FormControl();
	

	constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute, private workflowService: WorkflowService, 
				private codelistService: CodelistService, public dialog: MatDialog) {
		this.dataSource = new MatTableDataSource(this.states_data);
		
		
	 }

	 ngAfterViewInit() {
		
		this.dataSource.paginator = this.paginator;
		this.dataSource.sort = this.sort;
	 }
	
	onSubmit({ value, valid }: { value: Workflow, valid: boolean }): void {
		
		if (this.editMode){			
			if (valid)
				value['code'] = this.workflow.getRawValue()['code'];
				this.workflowService.updateWorkflow(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/workflows');
			});
		}
		else{
			if (valid)
				this.workflowService.newWorkflow(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/workflows');
			});  
		}
	}

	onCancel(): void {
		this.router.navigateByUrl('/main/workflows');
	}

	ngOnInit() {
		this.getCodelists();
		this.workflow = this.fb.group({
			code: [{ value: null, disabled: false }, Validators.required],
			name: [null, Validators.required],
      		description: null,
			codelist: this.codelist,
			states: null,//this.fb.group({ forename: [null, Validators.required], surname: null }),
		});

		this.route.queryParams.subscribe((queryParams:any) => {
			this.code = queryParams['code'];
			if (this.code != null){
				this.viewWorkflowDetail(this.code); 
			  	this.editMode = true;				  	
			}
			else {
			  this.editMode = false;
			  this.workflow.get('code').enable()
			}
		   });
		
	}
	
	addRow(row, i){		
		console.log(row);
		console.log(Object.keys(row).length);
		let edit: boolean = false;
		if(Object.keys(row).length > 0){
			this.stateEditMode = true;
		}
		else{
			this.stateEditMode = false;
		}
		const dialogRef = this.dialog.open(DialogStateForm, {
			width: '800px',
			data: {stateCode: row.code, stateName: row.name, description: row.description, stateEditMode: this.stateEditMode, 
					states: this.codelist.value['concepts'], allowedStates: row.allowedStates, template: row.template, isManual: row.isManual,
					isBlinded: row.isBlinded }
		});		

		dialogRef.afterClosed().subscribe(result => {
			if(!this.stateEditMode) {
				console.log(result);
				this.dataSource.data.push({code: result.stateCode, name: result.stateName, description: result.description, allowedStates: result.allowedStates,
					template: result.template, isManual: result.isManual, isBlinded: result.isBlinded});
				this.dataSource.filter = "";
				this.workflow.patchValue({['states']: this.dataSource.data});
			}
			if(this.stateEditMode){
				let index = this.dataSource.data.indexOf(this.dataSource.data.find(item => item.code == row.code));
				this.dataSource.data[index].name = result.stateName;
				this.dataSource.data[index].description = result.description;
				this.dataSource.data[index].allowedStates = result.allowedStates;
				this.dataSource.data[index].template = result.template;
				this.dataSource.data[index].isManual = result.isManual;
				this.dataSource.data[index].isBlinded = result.isBlinded;
				this.workflow.patchValue({['states']: this.dataSource.data});
			}	
			console.log(this.workflow);
		});

	}

	deleteRow(i){		
		this.dataSource.data.splice(i,1);		 
		this.dataSource.filter = "";
	}

	viewWorkflowDetail(code) {
		this.workflowService.viewWorkflowDetail(localStorage.getItem('token'), code).pipe(
				catchError(() => of([])),
				finalize(() => console.log('Success'))
			)
			.subscribe((data) => {					
				this.dataSource.data = data.workflow.states;
				this.workflow.setValue(data.workflow);
				this.workflow.get('code').disable();				
			});  
	  }


	private _filter(value: string): Codelist[] {
	const filterValue = value.toLowerCase();	
	return this.codelists.filter(item => item.name.toLowerCase().indexOf(filterValue) === 0);
	}

	displayFn(codelist: Codelist): string {
	return codelist && codelist.name +' ['+ codelist.code +']' ? codelist.name +' ['+ codelist.code +']' : '';
	}

	getCodelists(){
		this.codelistService.codelists(localStorage.getItem('token'), '', 'name', 'asc', 0, 100)
		.subscribe((data)=>{
			this.codelists = data.codelists,
			this.filteredOptions = this.codelist.valueChanges.pipe(
				startWith(''),
				map(value => typeof value === 'string' ? value : value.name),
				map(codelist => codelist ? this._filter(codelist) : this.codelists.slice())
			)
		});
	}

	selectCodelist(event,option){
		console.log(option);  
		if (event.source.selected) {
			//this.concepts = option.concepts;
		}
	  }

}


@Component({
	selector: 'dialog-state-form',
	templateUrl: 'state-form.html',
	styleUrls: ['./workflow-form.component.css']
  })
  export class DialogStateForm {
	
	stateName;
	templates: Template[] = [];
  	filteredOptions: Observable<Template[]>;
	template = new FormControl();

	constructor(public dialogRef: MatDialogRef<DialogStateForm>,	@Inject(MAT_DIALOG_DATA) public data: DialogData, private templateService: TemplateService) {	

		this.templateService.templates(localStorage.getItem('token'), '', 'name', 'asc', 0, 100)
		.subscribe((data)=>{
			this.templates = data.templates,
			this.filteredOptions = this.template.valueChanges.pipe(
				startWith(''),
				map(value => typeof value === 'string' ? value : value.name),
				map(template => template ? this._filter(template) : this.templates.slice())
			)
		});
	}
	
	onCancel(): void {
		this.dialogRef.close();
	}

	selectConceptCode(event,option){
		console.log(option);  
		if (event.source.selected) {
			this.stateName = option.label;
		}
	}

	private _filter(value: string): Template[] {
		const filterValue = value.toLowerCase();	
		return this.templates.filter(item => item.name.toLowerCase().indexOf(filterValue) === 0);
	}
	
	displayFn(template: Template): string {
	return template && template.name +' ['+ template.code +']' ? template.name +' ['+ template.code +']' : '';
	}
  }