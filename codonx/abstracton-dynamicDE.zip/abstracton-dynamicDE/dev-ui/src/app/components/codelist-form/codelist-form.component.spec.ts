import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CodelistFormComponent } from './codelist-form.component';

describe('CodelistFormComponent', () => {
  let component: CodelistFormComponent;
  let fixture: ComponentFixture<CodelistFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CodelistFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CodelistFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
