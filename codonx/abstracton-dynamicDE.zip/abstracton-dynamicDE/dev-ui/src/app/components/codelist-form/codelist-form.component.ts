import { AfterViewInit, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Concept } from '../../models/concept';
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from '../select-users/select-users.component';
import { CodelistService } from '../../services/codelist.service';
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';
import { Codelist } from '../../models/codelist';

@Component({
  selector: 'app-codelist-form',
  templateUrl: './codelist-form.component.html',
  styleUrls: ['./codelist-form.component.css']
})
export class CodelistFormComponent implements OnInit, AfterViewInit {

	@ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  	@ViewChild(MatSort, { static: false }) sort: MatSort;

  	hide = true;
	codelist: FormGroup;	
	concepts_data: Concept[] = [];
  	displayedColumns = ['value', 'label', 'description', 'edit', 'delete'];
	dataSource: MatTableDataSource<Concept>;
	conceptEditMode: boolean = false;
	editMode: boolean = false;
	code: string;

	constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute, private codelistService: CodelistService, public dialog: MatDialog) {
		this.dataSource = new MatTableDataSource(this.concepts_data);
		
	 }

	 ngAfterViewInit() {
		
		this.dataSource.paginator = this.paginator;
		this.dataSource.sort = this.sort;
	 }
	
	onSubmit({ value, valid }: { value: Codelist, valid: boolean }): void {
		
		if (this.editMode){			
			if (valid)
				value['code'] = this.codelist.getRawValue()['code'];
				this.codelistService.updateCodelist(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/codelists');
			});
		}
		else{
			if (valid)
				this.codelistService.newCodelist(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/codelists');
			});  
		}
	}

	onCancel(): void {
		this.router.navigateByUrl('/main/codelists');
	}

	ngOnInit() {
		this.codelist = this.fb.group({
			code: [{ value: null, disabled: false }, Validators.required],
			name: [null, Validators.required],
      		description: null,
			concepts: null,//this.fb.group({ forename: [null, Validators.required], surname: null }),
		});

		this.route.queryParams.subscribe((queryParams:any) => {
			this.code = queryParams['code'];
			if (this.code != null){
				this.viewCodelistDetail(this.code); 
			  	this.editMode = true;				  	
			}
			else {
			  this.editMode = false;
			  this.codelist.get('code').enable()
			}
		   });
		
	}
	
	addRow(row, i){		
		console.log(row);
		console.log(Object.keys(row).length);
		let edit: boolean = false;
		if(Object.keys(row).length > 0){
			this.conceptEditMode = true;
		}
		else{
			this.conceptEditMode = false;
		}
		const dialogRef = this.dialog.open(DialogCodeForm, {
			width: '600px',
			data: {value: row.value, label: row.label, description: row.description, conceptEditMode: this.conceptEditMode}
		});		

		dialogRef.afterClosed().subscribe(result => {
			if(!this.conceptEditMode) {
				this.dataSource.data.push({value: result.value, label: result.label, description: result.description});
				this.dataSource.filter = "";
				this.codelist.patchValue({['concepts']: this.dataSource.data});
			}
			if(this.conceptEditMode){
				let index = this.dataSource.data.indexOf(this.dataSource.data.find(item => item.value == row.value));
				this.dataSource.data[index].label = result.label;
				this.dataSource.data[index].description = result.description;
				this.codelist.patchValue({['concepts']: this.dataSource.data});
			}	
			console.log(this.codelist);
		});

	}

	deleteRow(i){		
		this.dataSource.data.splice(i,1);		 
		this.dataSource.filter = "";
	}

	viewCodelistDetail(code) {
		this.codelistService.viewCodelistDetail(localStorage.getItem('token'), code).pipe(
				catchError(() => of([])),
				finalize(() => console.log('Success'))
			)
			.subscribe((data) => {					
				this.dataSource.data = data.codelist.concepts;
				this.codelist.setValue(data.codelist);
				this.codelist.get('code').disable();				
			});  
	  }

}


@Component({
	selector: 'dialog-code-form',
	templateUrl: 'code-form.html',
	styleUrls: ['./codelist-form.component.css']
  })
  export class DialogCodeForm {
	
	constructor(public dialogRef: MatDialogRef<DialogCodeForm>,	@Inject(MAT_DIALOG_DATA) public data: DialogData) {}
	
	onCancel(): void {
		this.dialogRef.close();
	}
  }