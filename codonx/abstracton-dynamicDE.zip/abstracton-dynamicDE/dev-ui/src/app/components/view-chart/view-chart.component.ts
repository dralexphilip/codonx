import { Component, OnInit, ViewEncapsulation  } from '@angular/core';
import { parseString } from 'xml2js';
import { UserService } from '../../services/user.service';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { of } from 'rxjs';
import { DomSanitizer, SafeResourceUrl, SafeUrl, SafeHtml} from '@angular/platform-browser';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-view-chart',
  templateUrl: './view-chart.component.html',
  styleUrls: ['./view-chart.component.css', './cda.css'], 
  encapsulation: ViewEncapsulation.None
})


export class ViewChartComponent implements OnInit {
	
  filename = '';
  
  

  constructor(private userService: UserService, private sanitizer: DomSanitizer, private route: ActivatedRoute) { }
  
  
  transformed_html: SafeHtml;

  loadChart(file) {
	this.userService.viewChart(localStorage.getItem('token'), file).pipe(
			catchError(() => of([])),
			finalize(() => console.log('Final'))
		)
		.subscribe((file_content) => {
			this.transformed_html = this.sanitizer.bypassSecurityTrustHtml(file_content.file_content);			
		});  
  }

  ngOnInit() {
	  
	this.route.queryParams.subscribe((queryParams:any) => {
		//console.log(queryParams);
      this.filename = queryParams['filename'.replace(/\s/g, "")];
     });
	 
	
 
	this.loadChart(this.filename);
  }
  

  

}
