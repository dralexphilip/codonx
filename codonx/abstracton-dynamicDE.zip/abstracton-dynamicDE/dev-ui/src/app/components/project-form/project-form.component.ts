import { Component, OnInit, ViewChild, Inject, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { Project } from '../../models/project';
import { ActivatedRoute } from '@angular/router';
import { map, catchError, finalize, startWith } from 'rxjs/operators';
import { Subject, Observable, of } from 'rxjs';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import {SelectionModel} from '@angular/cdk/collections';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { SelectUsersComponent } from '../select-users/select-users.component'
import { User } from '../../models/user';
import { Template } from '../../models/template';
import { TemplateService } from '../../services/template.service';
import { MatAutocompleteTrigger } from '@angular/material';
import { Workflow } from '../../models/workflow';
import { WorkflowService } from '../../services/workflow.service';

@Component({
  selector: 'app-project-form',
  templateUrl: './project-form.component.html',
  styleUrls: ['./project-form.component.css']
})
export class ProjectFormComponent implements OnInit {

	@ViewChild('file', { static: false }) file;
	@ViewChild('pdfXsl', { static: false }) pdfXsl;
	@ViewChild('srcXsl', { static: false }) srcXsl;
	project: FormGroup;
	project_status;
	edit_mode = false;
	created_date;
	project_id;
	statuses = ['Created', 'Chart Loading', 'Abstraction In-progress', 'Completed'];
	default_status = 'Created';
	horizontalPosition: MatSnackBarHorizontalPosition = 'center';
	verticalPosition: MatSnackBarVerticalPosition = 'top';
	selectedFile;
	selectedFilename;
	template_data;
	viewTemplate = false;
	reviews = ['None', 'Daily', 'Weekly', 'Total'];
	types = ['Risk Adjustment', 'HEDIS Abstraction', 'Special Abstraction', 'Other'];
	extraction_status = 'Pending';
	extraction_file;
	data_access: User[];
	displayedColumns = ['first_name', 'last_name', 'username', 'edit'];
	@Input()selected_users: any;
	selected_users_count = 0;
	pdfXslFile;
	srcXslFile;


	template = new FormControl();
	templates: Template[];
	filteredOptions: Observable<Template[]>;
	templateName: string = '';
	@ViewChild(MatAutocompleteTrigger, { static: false }) trigger: MatAutocompleteTrigger;

	workflow = new FormControl();
	workflows: Workflow[];
	wfFilteredOptions: Observable<Workflow[]>;
  
  

  constructor(private fb: FormBuilder, private router: Router, private service: UserService, private route: ActivatedRoute, private _snackBar: MatSnackBar, 
				public dialog: MatDialog, private templateService: TemplateService, private workflowService: WorkflowService) {}

  onSubmit({ value, valid }: { value: Project, valid: boolean }): void{
	
	
		  
	if (this.edit_mode){
		if (valid)
			this.service.updateProject(localStorage.getItem('token'),value, this.pdfXslFile, this.srcXslFile)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main/projects');
			});
	}
	else{
		if (valid)
			this.service.newProject(localStorage.getItem('token'),value, this.pdfXslFile, this.srcXslFile)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main/projects');
			});  
	}
  }
		
  onCancel(): void {
	this.router.navigateByUrl('/main/projects');
  }
  
  ngOnInit() {

	this.templateService.templates(localStorage.getItem('token'),  '', 'name', 'asc', 0, 100).pipe(
		catchError(() => of([])),
		finalize(() => '')
	)
		.subscribe((templates) => {
			this.templates = templates.templates
			//this.codelistNames = codelists.codelists.map(codelist => codelist.name);
			console.log(this.templates);
			this.filteredOptions = this.template.valueChanges.pipe(
				startWith(''),
				map(value => typeof value === 'string' ? value : value.name),
				map(template => template ? this._filter(template) : this.templates.slice())
			  );
		});

	this.workflowService.workflows(localStorage.getItem('token'),  '', 'name', 'asc', 0, 100).pipe(
		catchError(() => of([])),
		finalize(() => '')
	)
		.subscribe((workflows) => {
			this.workflows = workflows.workflows,
			console.log(this.workflows),
			this.wfFilteredOptions = this.workflow.valueChanges.pipe(
				startWith(''),
				map(value => typeof value === 'string' ? value : value.name),
				map(workflow => workflow ? this.wf_filter(workflow) : this.workflows.slice())
				)
		});
	
	//let project_status = this.fb.group({});
	this.route.queryParams.subscribe((queryParams:any) => {
		//console.log(queryParams);
      this.project_id = queryParams['project_id'];
	  if (this.project_id != null){
		this.edit_mode = true;
		this.viewProjectDetail(this.project_id); 
	  }
	  else {
		this.edit_mode = false;
	  }
     });	
 
	
	this.project = this.fb.group({
		project_id: [null, Validators.required],
		name: [null, Validators.required],
		description: null,
		customer: [null, Validators.required],
		project_status: null,
		start_date: null,
		end_date: null,
		project_type: null,
		qa_review: null, 
		percentage: null,
		template_data: this.template,
		data_access: null,
		pdfXsl: null,
		srcXsl: null,
		workflow: this.workflow
	});
  
  }
  
  viewProjectDetail(project_id) {
	this.service.viewProjectDetail(localStorage.getItem('token'), project_id).pipe(
			catchError(() => of([])),
			finalize(() => console.log('Success'))
		)
		.subscribe((data) => {
			this.created_date = data.project.created_date.$date;
			delete data.project['created_date'];
			//data.chart['review_comments'] = '';
			console.log(data.project['extraction_status']);
			this.extraction_status = data.project['extraction_status'];
			delete data.project['extraction_status'];
			delete data.project['extraction_file'];
			//data.project['data_access'] = '';
			console.log(data.project['extraction_status']);
			
			this.project.setValue(data.project);
			this.template_data = data.project.template_data;	
			this.data_access = data.project.data_access;
			
		});  
  }
  
  addTemplate(event){
	var
		 file = (this.file.nativeElement.files[0] ? this.file.nativeElement.files[0] : this.file.nativeElement.files[0].value || undefined),
		 supportedFormats = ['.json','application/json'];
	
	if (file && file.type) {
		if (0 > supportedFormats.indexOf(file.type)) {
			this._snackBar.open('File Format Not Supported', 'Close', {
			  duration: 5000,
			  horizontalPosition: this.horizontalPosition,
			  verticalPosition: this.verticalPosition,
			});
		}
		else {
			this.selectedFile = event.target.files[0];
			this.selectedFilename = this.selectedFile.name;
			const fileReader = new FileReader();
			fileReader.readAsText(this.selectedFile, "UTF-8");
			fileReader.onload = () => {
				this.template_data = JSON.parse(fileReader.result as string);
				this.project.patchValue({
					  ['template_data']: JSON.parse(fileReader.result as string)
				  });
				//this.template_data = JSON.stringify((JSON.parse(fileReader.result as string)), undefined, 4);
				//document.getElementById('template_area').innerHTML = this.template_data;
				//this.project.patchValue({
				//	['template_data']: this.template.value['fields']
				//});
			}
			fileReader.onerror = (error) => {
				console.log(error);
			}
		}
	}

	
  }
  
  showTemplate(){
	this.closeAutocomplete();
	 this.viewTemplate = !this.viewTemplate;
  }
  
  prepareExtract(){
	this.service.initiateExtract(localStorage.getItem('token'), this.project_id).pipe(
			catchError(() => of([])),
			finalize(() => console.log('Success'))
		)
		.subscribe((data) => {
			console.log(data)			
			
		});
  }
  
  downloadExtract(){
	this.service.downloadExtract(localStorage.getItem('token'), this.project_id).subscribe(response => this.downloadFile(response, "text/csv")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
  }
  
   downloadFile(data: any, type: string) {
        let blob = new Blob([data], { type: type});
        let url = window.URL.createObjectURL(blob);
		var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = this.project_id+this.getDateTime()+'.csv';
        link.click();
        window.URL.revokeObjectURL(link.href);
    }
	
	getDateTime(): string { 
		var d = new Date(); 
		var mo = this.addZero(d.getMonth() + 1); 
		var yr = this.addZero(d.getFullYear()); 
		var dt = this.addZero(d.getDate()); 
		var h = this.addZero(d.getHours()); 
		var m = this.addZero(d.getMinutes()); 
		var s = this.addZero(d.getSeconds()); 

		return ("_" + mo + '-' + dt + '-' + yr + '-' + h + "-" + m + "-" + s ); 
	}
	
	addZero(i) {
	  if (i < 10) {
		i = "0" + i;
	  }
	  return i;
	}
	
	
 
  
  launchSFS(): void {
    const dialogRef = this.dialog.open(SelectUsersComponent, {
      width: '800px',
	  data: {selected_users:this.selected_users, existing_users:this.data_access}
    });

    dialogRef.afterClosed().subscribe(result => {
	  
	  result.selected_users.forEach(element => {
			delete element['created_date'];
		});
	  this.data_access = result.selected_users;
	  this.selected_users_count = result.selected_users.length;
	  
	  this.project.patchValue({
		['data_access']: this.data_access
	  });
    });
  }
  
  delete(row) {
	this.data_access = this.data_access.filter(i => i !== row);
	this.selected_users_count = this.data_access.length;
	this.project.patchValue({
		['data_access']: this.data_access
	});
  }


  private _filter(value: string): Template[] {
	const filterValue = value.toLowerCase();	
	return this.templates.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  displayFn(template: Template): string {
	return template && template.name ? template.name : '';
  }

  closeAutocomplete() {
    this.trigger.closePanel();
  }


  addPdfXsl(event){
	var
		 file1 = (this.pdfXsl.nativeElement.files[0] ? this.pdfXsl.nativeElement.files[0] : this.pdfXsl.nativeElement.files[0].value || undefined),
		 supportedFormats1 = ['.xsl', '.xml', 'text/xml'];
	
	if (file1 && file1.type) {
		if (0 > supportedFormats1.indexOf(file1.type)) {
			this._snackBar.open('File Format Not Supported', 'Close', {
			  duration: 5000,
			  horizontalPosition: this.horizontalPosition,
			  verticalPosition: this.verticalPosition,
			});
		}
		else {
			this.pdfXslFile = event.target.files[0];
			console.log(this.pdfXslFile.name);
			this.project.patchValue({['pdfXsl']: this.pdfXslFile.name});
			//this.selectedFilename = this.selectedFile.name;
			
		}
	}
	
  }

  addSrcXsl(event){
	var
		 file2 = (this.srcXsl.nativeElement.files[0] ? this.srcXsl.nativeElement.files[0] : this.srcXsl.nativeElement.files[0].value || undefined),
		 supportedFormats1 = ['.xsl', '.xml', 'text/xml'];
	
	if (file2 && file2.type) {
		if (0 > supportedFormats1.indexOf(file2.type)) {
			this._snackBar.open('File Format Not Supported', 'Close', {
			  duration: 5000,
			  horizontalPosition: this.horizontalPosition,
			  verticalPosition: this.verticalPosition,
			});
		}
		else {
			this.srcXslFile = event.target.files[0];
			this.project.patchValue({['srcXsl']: this.srcXslFile.name});
			//this.selectedFilename = this.selectedFile.name;
			
		}
	}
	
  }

  private wf_filter(value: string): Workflow[] {
	const filterValue = value.toLowerCase();	
	return this.workflows.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  wfDisplayFn(workflow: Workflow): string {
	return workflow && workflow.name ? workflow.name : '';
  }

}


