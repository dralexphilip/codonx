import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
	hide = true;
	user: FormGroup;
	message: string;

  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) { }

 
  onSubmit({ value, valid }: { value: User, valid: boolean }): void{
	if (valid)
		this.auth.generate_otp(value)
		.subscribe((data) => {
		  localStorage.setItem('user', JSON.stringify(value));
		  this.router.navigateByUrl('/verifyotp');
		});  
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/login-page');
  }
  
  ngOnInit() {
	  
	this.user = this.fb.group({
	first_name: [null, Validators.required],
	email: [null, Validators.required],
	passkey: [null, Validators.required]
  });  
  
  }

}
