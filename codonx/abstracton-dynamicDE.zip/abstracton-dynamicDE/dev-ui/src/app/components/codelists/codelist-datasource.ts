import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Codelist } from '../../models/codelist';
import { CodelistService } from '../../services/codelist.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs'

/**
 * Data source for the Permissions view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class CodelistsDataSource extends DataSource<Codelist> {

    private codelistsSubject = new BehaviorSubject<Codelist[]>([]);
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();
    data: Codelist[] = [];
    total_count: number;

    constructor(private codelistService: CodelistService) {
        super();
    }

    /**
     * Connect this data source to the table. The table will only update when
     * the returned stream emits new items.
     * @returns A stream of the items to be rendered.
     */

    loadCodelists(
        filter: string,
        sortField: string,
        sortDirection: string,
        pageIndex: number,
        pageSize: number) {
        this.loadingSubject.next(true);

        this.codelistService.codelists(localStorage.getItem('token'),  filter, sortField, sortDirection, pageIndex, pageSize).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe((codelists) => {
                this.total_count = codelists.total_count,
                this.codelistsSubject.next(codelists.codelists)
            });
    }

    connect(collectionViewer: CollectionViewer): Observable<Codelist[]> {
        // Combine everything that affects the rendered data into one update
        // stream for the data-table to consume.
        return this.codelistsSubject.asObservable();
    }

    /**
     *  Called when the table is being destroyed. Use this function, to clean up
     * any open connections or free any held resources that were set up during connect.
     */
    disconnect(collectionViewer: CollectionViewer): void {
        this.codelistsSubject.complete();
        this.loadingSubject.complete();
    }

}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a, b, isAsc) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
