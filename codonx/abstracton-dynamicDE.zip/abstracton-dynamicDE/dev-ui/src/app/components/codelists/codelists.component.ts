import { CodelistsDataSource } from './codelist-datasource';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CodelistService } from '../../services/codelist.service';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { Codelist } from 'src/app/models/codelist';

@Component({
  selector: 'app-codelists',
  templateUrl: './codelists.component.html',
  styleUrls: ['./codelists.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CodelistsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;

  dataSource: CodelistsDataSource;
  codelist: Codelist;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['code', 'name', 'description', 'edit', 'delete'];
  //expandedElement: any;
  //isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');

  constructor(private route: ActivatedRoute, private router: Router, private codelistService: CodelistService) { }

  ngOnInit() {
    this.codelist = this.route.snapshot.data['codelist'];
    this.dataSource = new CodelistsDataSource(this.codelistService);
    this.dataSource.loadCodelists( '', 'name', 'asc', 0, 10);
  }

  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;

          this.loadCodelistsPage();
        })
      )
      .subscribe();

    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => this.loadCodelistsPage())
      )
      .subscribe();
  }

  loadCodelistsPage() {
    this.dataSource.loadCodelists(
    this.input.nativeElement.value,
	  this.sort.active,
	  this.sort.direction,
	  this.paginator.pageIndex,
	  this.paginator.pageSize);
  }

  newCodelist() {
    this.router.navigateByUrl('/main/codelists/new_codelist');
  }

  editCodelist(code) {
    this.router.navigateByUrl('/main/codelists/new_codelist?code='+code);
  }

  deleteCodelist(code) {
    this.codelistService.deleteCodelist(localStorage.getItem('token'), code)
				.subscribe((data) => {
					this.loadCodelistsPage();
        });
  }

}
