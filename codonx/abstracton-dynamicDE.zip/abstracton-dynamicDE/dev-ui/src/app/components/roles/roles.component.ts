import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { UserService } from '../../services/user.service';
import { Role } from '../../models/role';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import { RolesDataSource } from './roles-datasource';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: RolesDataSource;
  role: Role;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'name', 'edit'];
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.role = this.route.snapshot.data["role"];
    this.dataSource = new RolesDataSource(this.userService);
    this.dataSource.loadRoles('', 'name', 'asc', 0, 10);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadRolesPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadRolesPage())
	)
	.subscribe();
  }
  
  loadRolesPage() {
	this.dataSource.loadRoles(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  newRole() {
	this.router.navigateByUrl('/main/roles/new_role');
  }
  
  onRowClicked(row) {
    console.log('Row clicked: ', row);
  }
  
}
