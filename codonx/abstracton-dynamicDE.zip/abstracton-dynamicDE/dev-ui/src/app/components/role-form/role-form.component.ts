import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { Privilege } from '../../models/privilege';
import { Role } from '../../models/role';

@Component({
  selector: 'app-role-form',
  templateUrl: './role-form.component.html',
  styleUrls: ['./role-form.component.css']
})

export class RoleFormComponent implements OnInit {
  
  hide = true;
  role: FormGroup;
  

  hasUnitNumber = false;

  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) {}

  privileges: Privilege[] = [];
  
  
  getPrivileges(){
	  console.log('test');
	  this.auth.privilege_list(localStorage.getItem('token'), '', 'name', 'asc', 0, 15)
		.subscribe((data) => this.privileges = data.privileges);
  }
  onSubmit({ value, valid }: { value: Role, valid: boolean }): void{
	if (valid)
		this.auth.newRole(localStorage.getItem('token'),value)
		.subscribe((data) => {
		  this.router.navigateByUrl('/main/roles');
		});  
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/main/roles');
  }
  
  ngOnInit() {
	this.getPrivileges();
	this.role = this.fb.group({
		role_id: [null, Validators.required],
		role_name: [null, Validators.required],
		privileges: null
  });
  }
}
