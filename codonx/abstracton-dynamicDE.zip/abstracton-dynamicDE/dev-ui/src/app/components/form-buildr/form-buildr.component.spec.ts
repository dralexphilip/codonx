import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBuildrComponent } from './form-buildr.component';

describe('FormBuildrComponent', () => {
  let component: FormBuildrComponent;
  let fixture: ComponentFixture<FormBuildrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBuildrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBuildrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
