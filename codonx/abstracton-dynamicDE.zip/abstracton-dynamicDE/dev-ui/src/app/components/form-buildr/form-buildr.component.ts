import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-form-buildr',
  templateUrl: './form-buildr.component.html',
  styleUrls: ['./form-buildr.component.css']
})
export class FormBuildrComponent implements OnInit {

   controls = 'matInput';

  formItems = [
    
  ];
  
  phases = [{value: 101, display: 'Phase I'}, 
			{value: 102, display: 'Phase II'}, 
			{value: 103, display: 'Phase III'}, 
			{value: 104, display: 'Phase IV'}];
  
  formGroupItems: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
	this.formGroupItems = this.fb.group({
		textbox: null  
	});
	
  }
  
  fieldArray: Array<any> = [];
  fieldArray1: Array<any> = [];
  textAttribute: any = {};
  dropAttribute: any = {};
  droppedItems = [];
  currentDraggedItem: any;


  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
	  
	  
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);

		//this.fieldArray.push(this.dropAttribute);
		this.fieldArray.splice(event.currentIndex, 0, event.previousIndex);
						
    }
	//console.log("Previous "+event.previousIndex);
	//this.addFieldValue();
  }
  
  addFieldValue() {
    //this.fieldArray.push(this.textAttribute);

    }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  

  
}