import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { UsersDataSource } from './users-datasource';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: UsersDataSource;
  user: User;  
  data_access;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['first_name', 'last_name', 'username', 'active', 'edit'];
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.user = this.route.snapshot.data["user"];
    this.dataSource = new UsersDataSource(this.userService);
    this.dataSource.loadUsers('', 'first_name', 'asc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadUsersPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadUsersPage())
	)
	.subscribe();
	
	
  }
  
  loadUsersPage() {
	this.dataSource.loadUsers(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  newUser() {
	this.router.navigateByUrl('/main/users/new_user');
  }
  
  onRowClicked(row, i) {
    console.log('Row clicked: ',i, row);
  }
  
}

