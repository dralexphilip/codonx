import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { User } from '../../models/user';
import { UserService } from '../../services/user.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';


export class UsersDataSource extends DataSource<User> {

  private usersSubject = new BehaviorSubject<User[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  data: User[]=[];
  total_count: number;
  

  constructor(private userService: UserService) {
    super();
  }
  
  loadUsers(filter:string,
			sortField:string,
			sortDirection:string,
			pageIndex:number,
			pageSize:number) {
	this.loadingSubject.next(true);

	this.userService.allUsers(localStorage.getItem('token'), filter, sortField, sortDirection,
		pageIndex, pageSize).pipe(
			catchError(() => of([])),
			finalize(() => this.loadingSubject.next(false))
		)
		.subscribe((allusers) => {
			this.total_count = allusers.users.length;
			this.data = allusers.users;
			this.usersSubject.next(allusers.users);
		});
  }
  
  connect(collectionViewer: CollectionViewer): Observable<User[]> {
	return this.usersSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
	this.usersSubject.complete();
	this.loadingSubject.complete();
  }

}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
