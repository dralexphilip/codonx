import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { AbstractDataSource } from './abstraction-datasource';
import { UserService } from '../../services/user.service';
import { Abstract } from '../../models/abstract';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {animate, state, style, transition, trigger} from '@angular/animations';

@Component({
  selector: 'app-abstraction',
  templateUrl: './abstraction.component.html',
  styleUrls: ['./abstraction.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AbstractionComponent implements OnInit, AfterViewInit {

 @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: AbstractDataSource;
  abstraction: Abstract;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['abstract_id', 'chart_id', 'project_id', 'lastname', 'firstname', 'abstract_status', 'abstract_created_date', 'abstract_date', 'abstract_by', 'edit', 'delete'];
  //expandedElement: dataSource | null;
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.abstraction = this.route.snapshot.data["abstraction"];
    this.dataSource = new AbstractDataSource(this.userService);
    this.dataSource.loadAbstractions('', 'abstract_created_date', 'desc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadAbstractionsPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadAbstractionsPage())
	)
	.subscribe();
  }
  
  loadAbstractionsPage() {
	this.dataSource.loadAbstractions(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  editAbstract(abstract_id, filename) {
	this.router.navigateByUrl('/main/abstraction/new_abstraction?abstract_id='+abstract_id+'&filename='+filename+'&t=abs');
  }

  deleteAbstraction(abstract_id) {
    this.userService.deleteAbstraction(localStorage.getItem('token'), abstract_id)
				.subscribe((data) => {
					this.loadAbstractionsPage();
        });
  }
  
}

