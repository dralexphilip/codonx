import { DataitemsDataSource } from './dataitem-datasource';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataitemService } from '../../services/dataitem.service';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { FormlyFieldConfig } from '@ngx-formly/core';

@Component({
  selector: 'app-dataitems',
  templateUrl: './dataitems.component.html',
  styleUrls: ['./dataitems.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class DataitemsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;

  dataSource: DataitemsDataSource;
  dataitem: FormlyFieldConfig;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'key', 'label', 'type', 'className', 'wrappers', 'description', 'edit', 'delete'];
  //expandedElement: any;
  //isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');

  constructor(private route: ActivatedRoute, private router: Router, private dataitemService: DataitemService) { }

  ngOnInit() {
    this.dataitem = this.route.snapshot.data['dataitem'];
    this.dataSource = new DataitemsDataSource(this.dataitemService);
    this.dataSource.loadDataitems( '', 'name', 'asc', 0, 100);
  }

  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;

          this.loadDataitemsPage();
        })
      )
      .subscribe();

    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => this.loadDataitemsPage())
      )
      .subscribe();
  }

  loadDataitemsPage() {
    this.dataSource.loadDataitems(
    this.input.nativeElement.value,
	  this.sort.active,
	  this.sort.direction,
	  this.paginator.pageIndex,
	  this.paginator.pageSize);
  }

  newDataitem() {
    this.router.navigateByUrl('/main/dataitems/new_dataitem');
  }

  editDataitem(id) {
    this.router.navigateByUrl('/main/dataitems/new_dataitem?id='+id);
  }

  deleteDataitem(id) {
    this.dataitemService.deleteDataitem(localStorage.getItem('token'), id)
				.subscribe((data) => {
					this.loadDataitemsPage();
        });
  }


}

