import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataitemsComponent } from './dataitems.component';

describe('DataitemsComponent', () => {
  let component: DataitemsComponent;
  let fixture: ComponentFixture<DataitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
