import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { DataitemService } from '../../services/dataitem.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs'
import { FormlyFieldConfig } from '@ngx-formly/core';

/**
 * Data source for the Permissions view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class DataitemsDataSource extends DataSource<FormlyFieldConfig> {

    private dataitemsSubject = new BehaviorSubject<FormlyFieldConfig[]>([]);
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();
    data: FormlyFieldConfig[] = [];
    total_count: number;

    constructor(private dataitemService: DataitemService) {
        super();
    }

    /**
     * Connect this data source to the table. The table will only update when
     * the returned stream emits new items.
     * @returns A stream of the items to be rendered.
     */

    loadDataitems(
        filter: string,
        sortField: string,
        sortDirection: string,
        pageIndex: number,
        pageSize: number) {
        this.loadingSubject.next(true);

        this.dataitemService.dataitems(localStorage.getItem('token'),  filter, sortField, sortDirection, pageIndex, pageSize).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe((dataitems) => {
                this.total_count = dataitems.total_count,
                this.dataitemsSubject.next(dataitems.dataitems)
            });
    }

    connect(collectionViewer: CollectionViewer): Observable<FormlyFieldConfig[]> {
        // Combine everything that affects the rendered data into one update
        // stream for the data-table to consume.
        return this.dataitemsSubject.asObservable();
    }

    /**
     *  Called when the table is being destroyed. Use this function, to clean up
     * any open connections or free any held resources that were set up during connect.
     */
    disconnect(collectionViewer: CollectionViewer): void {
        this.dataitemsSubject.complete();
        this.loadingSubject.complete();
    }

}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a, b, isAsc) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
