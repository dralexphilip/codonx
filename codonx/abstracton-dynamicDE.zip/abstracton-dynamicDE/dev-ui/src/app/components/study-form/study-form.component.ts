import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { UploadService } from '../../services/upload.service';
import { Study } from '../../models/study';
import countries from '../../resources/countries.json';

@Component({
  selector: 'app-study-form',
  templateUrl: './study-form.component.html',
  styleUrls: ['./study-form.component.css']
})
export class StudyFormComponent implements OnInit {
  @ViewChild('file', { static: false }) file;
  public files: Set<File> = new Set();
  
  step = 0;
  
  dragfiles: any = [];
  
  progress;
  canBeClosed = true;
  primaryButtonText = 'Upload';
  showCancelButton = true;
  uploading = false;
  uploadSuccessful = false;
  
  study: FormGroup;
  secondFormGroup: FormGroup;
  selected_type = '';
  phases = [{value: 101, display: 'Phase I'}, 
			{value: 102, display: 'Phase II'}, 
			{value: 103, display: 'Phase III'}, 
			{value: 104, display: 'Phase IV'}]
			
  types = [{value: 101, display: 'Interventional'}, 
			{value: 102, display: 'Observational'}, 
			{value: 103, display: 'Expanded Access'}]
			
  countries = countries;
  
  maskings = [{value: 101, display: 'Open Label'}, 
			{value: 102, display: 'Single Blind'}, 
			{value: 103, display: 'Double Blind'}, 
			{value: 104, display: 'Triple Blind'}]
			
  constructor(private _formBuilder: FormBuilder, private router: Router, private auth: UserService, public uploadService: UploadService) { }
  
  onSubmit({ value, valid }: { value: Study, valid: boolean }): void{
	//if (valid){
	//	this.uploadService.upload(this.files, 'upload_study_file'); 
		//this.auth.newStudy(localStorage.getItem('token'),value)
		//.subscribe((data) => {
		 // this.router.navigateByUrl('/main/studies');
		//});  
	//}
  }

  ngOnInit() {
	   this.study= this._formBuilder.group({
      study_id: ['', Validators.required],
	  type: ['', Validators.required],
	  title: ['', Validators.required],
	  phase: [null, Validators.required],
	  description: null,
	  upload_file: null, 
	  primary_obj: null,
	  secondary_obj: null, 
	  start_date: null,
	  end_date: null,
	  enrollment: null,
	  country: null, 
	  sites: null,
	  sites_country: null, 
	  subjects_site: null,
	  intervention: null,
	  masking: null
    });
	this.secondFormGroup= this._formBuilder.group({
	  description: null
    });
  }
  
  onFilesAdded() {
    const files: { [key: string]: File } = this.file.nativeElement.files;
    for (let key in files) {
      if (!isNaN(parseInt(key))) {
        this.files.add(files[key]);
      }
    }
  }

  addFiles() {
    this.file.nativeElement.click();
  }


  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      this.files.add(element)
    }  	
  }
  deleteAttachment(file) {
    this.files.delete(file)
  }
  
  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

}
