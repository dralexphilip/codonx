import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide = true;
  user: FormGroup;
  ngOnInit() {
  this.user = this.fb.group({
    username: [null, Validators.required],
    passkey: [null, Validators.required]
  });
  }

  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) {}

  onSubmit({ value, valid }: { value: User, valid: boolean }): void {
	if (valid)
	this.auth.login(value)
	.subscribe((data) => {
	  localStorage.setItem('token', data.access_token);
	  //console.log(localStorage.getItem('token'));
	  //alert(localStorage.getItem('token'));
	  this.router.navigateByUrl('/main');
	});    
  }
  
  register(): void {
	  this.router.navigateByUrl('/register');
  }
  
  registerBusiness(): void {
	this.router.navigateByUrl('/register_business');
  }
}
