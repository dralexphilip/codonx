import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataitemFormComponent } from './dataitem-form.component';

describe('DataitemFormComponent', () => {
  let component: DataitemFormComponent;
  let fixture: ComponentFixture<DataitemFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataitemFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataitemFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
