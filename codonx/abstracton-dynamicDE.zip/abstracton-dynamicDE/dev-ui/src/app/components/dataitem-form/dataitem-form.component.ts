import { AfterViewInit, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataitemService } from '../../services/dataitem.service';
import { catchError, finalize, map, startWith } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Codelist } from '../../models/codelist';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { CodelistService } from '../../services/codelist.service';

@Component({
  selector: 'app-dataitem-form',
  templateUrl: './dataitem-form.component.html',
  styleUrls: ['./dataitem-form.component.css']
})
export class DataitemFormComponent implements OnInit {


  	hide = true;
	dataitem: FormGroup;	
	editMode: boolean = false;
	id: string;
	types = [{id: 'input', display: 'Input'}, 
			{id: 'textarea', display: 'Textarea'},
			{id: 'select', display: 'Select'},
			{id: 'autocomplete', display: 'Autocomplete'},
			{id: 'datepicker', display: 'Date Picker'},
			{id: 'checkbox', display: 'Checkbox'},
			{id: 'radio', display: 'Radiobutton'},
			{id: 'toggle', display: 'Toggle'},
			{id: 'slider', display: 'Slider'},
			{id: 'stepper', display: 'Stepper Vertical'},
			{id: 'stepperHorizontal', display: 'Stepper Horizontal'},
			{id: 'tabs', display: 'Tabs'},
			{id: 'file', display: 'File Input'}
		];
	templateOptionTypes = [{id: 'text', display: 'Text'}, 
							{id: 'number', display: 'Number'},
							{id: 'password', display: 'Password'}
						];
	
	wrappers = [{id: 'accwrap', display: 'Accordian'}, 
				{id: 'panel', display: 'Expansion Panel'},
				{id: 'rowwrap', display: 'Row Wrapper'}
			];

	options = new FormControl();
	codelists: Codelist[];
	filteredOptions: Observable<Codelist[]>;

	constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute, private dataitemService: DataitemService,
		private codelistService: CodelistService) {
		
	 }


	onSubmit({ value, valid }: { value: FormlyFieldConfig, valid: boolean }): void {
		//value.templateOptions.options = this.options.value['concepts'];
		/*const filtered = {};
		if (valid) {
			for (let key in value) {
			  if (value[key]) {
				filtered[key] = value[key];
			  }
			}
			console.log(filtered);
		  }*/
		if (this.editMode){			
			if (valid)
				value['id'] = this.dataitem.getRawValue()['id'];
				this.dataitemService.updateDataitem(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/dataitems');
			});
		}
		else{
			if (valid)
				this.dataitemService.newDataitem(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/dataitems');
			});  
		}
	}

	onCancel(): void {
		this.router.navigateByUrl('/main/dataitems');
	}

	ngOnInit() {

		this.codelistService.codelists(localStorage.getItem('token'),  '', 'name', 'asc', 0, 100).pipe(
            catchError(() => of([])),
            finalize(() => '')
        )
            .subscribe((codelists) => {
                this.codelists = codelists.codelists
				//this.codelistNames = codelists.codelists.map(codelist => codelist.name);
				console.log(this.codelists);
				this.filteredOptions = this.options.valueChanges.pipe(
					startWith(''),
					map(value => typeof value === 'string' ? value : value.name),
					map(codelist => codelist ? this._filter(codelist) : this.codelists.slice())
				  );
            });

		

		this.dataitem = this.fb.group({
			id: [{ value: null, disabled: false }, Validators.required],
			key: null,
			type: null,
			className: null,
			template: null,
			defaultValue: null, 
			hide: false,
			hideExpression: null,
			wrappers: null,
			fieldGroupClassName: null,
			templateOptions: this.fb.group({
				label: null,
				type: null,
				description: null,
				required: null,
				placeholder: null,
				pattern: null,
				minLength: null,
				maxLength: null,
				min: null,
				max: null,				
				options: this.options,
				expand: null,
				icon: null,
				addonRight: this.fb.group({
					icon: null
				}),				
			}),
			validation: this.fb.group({
				messages: this.fb.group({
					pattern: null
				})
			}),
			
		});

		this.route.queryParams.subscribe((queryParams:any) => {
			this.id = queryParams['id'];
			if (this.id != null){
				this.viewDataitemDetail(this.id); 
			  	this.editMode = true;				  	
			}
			else {
			  this.editMode = false;
			  this.dataitem.get('id').enable()
			}
		   });
		
		   
	}	

	viewDataitemDetail(id) {
		this.dataitemService.viewDataitemDetail(localStorage.getItem('token'), id).pipe(
				catchError(() => of([])),
				finalize(() => console.log('Success'))
			)
			.subscribe((data) => {					
				this.dataitem.setValue(data.dataitem);
				this.dataitem.get('id').disable();				
			});  
	  }

	  private _filter(value: string): Codelist[] {
		const filterValue = value.toLowerCase();	
		return this.codelists.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
	  }

	  displayFn(codelist: Codelist): string {
		return codelist && codelist.name ? codelist.name : '';
	  }

}

