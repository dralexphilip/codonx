import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { Role } from '../../models/role';
import { User } from '../../models/user';
import countries from '../../resources/countries.json';
import states from '../../resources/states.json';

@Component({
  selector: 'app-investigator-form',
  templateUrl: './investigator-form.component.html',
  styleUrls: ['./investigator-form.component.css']
})
export class InvestigatorFormComponent implements OnInit{
  
  hide = true;
  user: FormGroup;
  

  hasUnitNumber = false;
  countries = countries;
  states = states;
  genders = [
			{value: 101, display: 'Male'}, 
			{value: 102, display: 'Female'}, 
			{value: 103, display: 'Indeterminate'}, 
			];

  qualifications = [
			{value: 101, display: 'MD'}, 
			{value: 102, display: 'MCh'}, 
			{value: 103, display: 'MS'}, 
			];
  
  specialities = [
			{value: 101, display: 'Anaesthesiology'}, 
			{value: 102, display: 'Cardio-Thoracic Surgery'}, 
			{value: 103, display: 'Cadiology'}, 
			{value: 103, display: 'Endocrinology'},
			{value: 103, display: 'Gastroenterology'}, 
			{value: 103, display: 'Ophthalmalogy'}, 
			{value: 103, display: 'Paediatrics'}, 
			{value: 103, display: 'Dermatology'}, 
			{value: 103, display: 'Nephrology'}, 
			{value: 103, display: 'Urology'}, 
			];
			
  rfs = [
			{value: 101, display: 'Harvard Medical School, Boston'}, 
			{value: 102, display: 'New York Presbyterian Hospital, New York City'}, 
			{value: 103, display: 'Massachusetts General Hospital, Boston'}, 
			{value: 103, display: 'University Medical Center, Utah'},
			{value: 103, display: 'Mayo Clinic, San Francisco'}, 
			{value: 103, display: 'John Hopkins Medical School, New Jersey'}, 
			{value: 103, display: 'Conway Medical, Ohio'}, 
			];
			
  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) {}


  onSubmit({ value, valid }: { value: User, valid: boolean }): void{
	if (valid)
		this.auth.newInvestigator(localStorage.getItem('token'),value)
		.subscribe((data) => {
		  this.router.navigateByUrl('/main/investigators');
		});  
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/main/investigators');
  }
  
  ngOnInit() {
	this.user = this.fb.group({
		first_name: [null, Validators.required],
		last_name: [null, Validators.required],
		middle_name: null,
		gender: null,
		age: null,
		qualification: null,
		speciality: null,
		clinical_exp: null,
		study_exp: null,
		rf: null,
		tel: null,
		address: null,
		city: null,
		state: null,
		postalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
		country: null
  });
  }
}

