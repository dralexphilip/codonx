import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Template } from '../../models/template';
import { TemplateService } from '../../services/template.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs'

/**
 * Data source for the Permissions view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class TemplatesDataSource extends DataSource<Template> {

    private templatesSubject = new BehaviorSubject<Template[]>([]);
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();
    data: Template[] = [];
    total_count: number;

    constructor(private templateService: TemplateService) {
        super();
    }

    /**
     * Connect this data source to the table. The table will only update when
     * the returned stream emits new items.
     * @returns A stream of the items to be rendered.
     */

    loadTemplates(
        filter: string,
        sortField: string,
        sortDirection: string,
        pageIndex: number,
        pageSize: number) {
        this.loadingSubject.next(true);

        this.templateService.templates(localStorage.getItem('token'),  filter, sortField, sortDirection, pageIndex, pageSize).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe((templates) => {
                this.total_count = templates.total_count,
                this.templatesSubject.next(templates.templates)
            });
    }

    connect(collectionViewer: CollectionViewer): Observable<Template[]> {
        // Combine everything that affects the rendered data into one update
        // stream for the data-table to consume.
        return this.templatesSubject.asObservable();
    }

    /**
     *  Called when the table is being destroyed. Use this function, to clean up
     * any open connections or free any held resources that were set up during connect.
     */
    disconnect(collectionViewer: CollectionViewer): void {
        this.templatesSubject.complete();
        this.loadingSubject.complete();
    }

}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a, b, isAsc) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
