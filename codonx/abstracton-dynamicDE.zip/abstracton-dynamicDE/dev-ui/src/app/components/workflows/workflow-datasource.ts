import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Workflow } from '../../models/workflow';
import { WorkflowService } from '../../services/workflow.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs'

/**
 * Data source for the Permissions view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class WorkflowsDataSource extends DataSource<Workflow> {

    private workflowsSubject = new BehaviorSubject<Workflow[]>([]);
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();
    data: Workflow[] = [];
    total_count: number;

    constructor(private workflowService: WorkflowService) {
        super();
    }

    /**
     * Connect this data source to the table. The table will only update when
     * the returned stream emits new items.
     * @returns A stream of the items to be rendered.
     */

    loadWorkflows(
        filter: string,
        sortField: string,
        sortDirection: string,
        pageIndex: number,
        pageSize: number) {
        this.loadingSubject.next(true);

        this.workflowService.workflows(localStorage.getItem('token'),  filter, sortField, sortDirection, pageIndex, pageSize).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe((workflows) => {
                this.total_count = workflows.total_count,
                this.workflowsSubject.next(workflows.workflows)
            });
    }

    connect(collectionViewer: CollectionViewer): Observable<Workflow[]> {
        // Combine everything that affects the rendered data into one update
        // stream for the data-table to consume.
        return this.workflowsSubject.asObservable();
    }

    /**
     *  Called when the table is being destroyed. Use this function, to clean up
     * any open connections or free any held resources that were set up during connect.
     */
    disconnect(collectionViewer: CollectionViewer): void {
        this.workflowsSubject.complete();
        this.loadingSubject.complete();
    }

}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a, b, isAsc) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
