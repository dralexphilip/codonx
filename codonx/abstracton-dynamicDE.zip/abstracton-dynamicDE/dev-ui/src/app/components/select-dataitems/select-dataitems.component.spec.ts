import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectDataitemsComponent } from './select-dataitems.component';

describe('SelectDataitemsComponent', () => {
  let component: SelectDataitemsComponent;
  let fixture: ComponentFixture<SelectDataitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectDataitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectDataitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
