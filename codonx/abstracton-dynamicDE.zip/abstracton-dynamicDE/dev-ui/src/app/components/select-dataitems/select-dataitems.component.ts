import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, Input, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { DataitemsDataSource } from '../dataitems/dataitem-datasource';
import { DataitemService } from '../../services/dataitem.service';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {SelectionModel} from '@angular/cdk/collections';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormlyFieldConfig } from '@ngx-formly/core';

@Component({
  selector: 'app-select-dataitems',
  templateUrl: './select-dataitems.component.html',
  styleUrls: ['./select-dataitems.component.css']
})
export class SelectDataitemsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  displayedColumns = ['select', 'id', 'key', 'type', 'className'];
  dataSource: DataitemsDataSource;
  @Input()existing_dataitems: any;
  
  constructor(private route: ActivatedRoute, private router: Router, private dataitemService: DataitemService, public dialogRef: MatDialogRef<SelectDataitemsComponent>,@Inject(MAT_DIALOG_DATA) public data: DialogData) {
	  
	
  }
  
  ngOnInit() {
    this.dataSource = new DataitemsDataSource(this.dataitemService);
    this.dataSource.loadDataitems('', 'id', 'asc', 0, 100);
	  console.log(this.dataSource.total_count);
  }
  
  
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadDataitemsPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadDataitemsPage())
	)
	.subscribe();
	
	
	
	
  }
  
  loadDataitemsPage() {
	this.dataSource.loadDataitems(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
	
  }

  onCancel(): void {
    this.dialogRef.close();
  }
  
  addSelectedDataitems(){
	this.data.selected_dataitems = this.selection.selected;
  }
  
 
  selection = new SelectionModel<FormlyFieldConfig>(true, []);
  
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
	 //console.log(this.dataSource.data);
	
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.total_count;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row: FormlyFieldConfig, i): string {
	
	this.dataSource.data.forEach(row => {
		if(this.data.existing_dataitems != null)
		this.data.existing_dataitems.forEach(dataitem=> {
			if(row.id == dataitem.id){
				console.log(row)
				this.selection.select(row)
			}
		})		
	});
	
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${i + 1}`;
  }

}

export interface DialogData {
  selected_dataitems: any;
  existing_dataitems: any;
}