import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private breakpointObserver: BreakpointObserver, private router: Router, private auth: UserService) {}
  
  onLogout(): void {
	
	
	this.auth.logout(localStorage.getItem('token'))
	.subscribe((data) => {
	  localStorage.removeItem('token');
	  this.router.navigateByUrl('/login');
	},
	error => console.log(error) 
	);
	
	
  }

}
