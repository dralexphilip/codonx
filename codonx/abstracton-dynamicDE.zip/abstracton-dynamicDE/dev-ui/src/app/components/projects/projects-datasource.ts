import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Project } from '../../models/project';
import { UserService } from '../../services/user.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';


export class ProjectsDataSource extends DataSource<Project> {

  private projectsSubject = new BehaviorSubject<Project[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  data: Project[]=[];
  total_count: number;
  

  constructor(private service: UserService) {
    super();
  }
  
  loadProjects(filter:string,
			sortField:string,
			sortDirection:string,
			pageIndex:number,
			pageSize:number) {
	this.loadingSubject.next(true);

	this.service.allProjects(localStorage.getItem('token'), filter, sortField, sortDirection,
		pageIndex, pageSize).pipe(
			catchError(() => of([])),
			finalize(() => this.loadingSubject.next(false))
		)
		.subscribe((projects) => {
			this.total_count = projects.total_count,
			this.projectsSubject.next(projects.projects)
		});
  }
  
  connect(collectionViewer: CollectionViewer): Observable<Project[]> {
	console.log("Connecting data source");
	return this.projectsSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
	this.projectsSubject.complete();
	this.loadingSubject.complete();
  }

}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
