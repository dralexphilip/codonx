import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ProjectsDataSource } from './projects-datasource';
import { UserService } from '../../services/user.service';
import { Project } from '../../models/project';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: ProjectsDataSource;
  project: Project;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['project_id', 'project_name', 'description', 'customer', 'project_status', 'created_date', 'edit', 'delete'];
  
  constructor(private route: ActivatedRoute, private router: Router, private service: UserService) { }

  ngOnInit() {
    this.project = this.route.snapshot.data["project"];
    this.dataSource = new ProjectsDataSource(this.service);
    this.dataSource.loadProjects('', 'created_date', 'desc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadProjectsPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadProjectsPage())
	)
	.subscribe();
  }
  
  loadProjectsPage() {
	this.dataSource.loadProjects(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  newProject() {
	this.router.navigateByUrl('/main/projects/new_project');
  }
  
  editProject(project_id) {
	this.router.navigateByUrl('/main/projects/new_project?project_id='+project_id);
  }

  deleteProject(project_id) {
    this.service.deleteProject(localStorage.getItem('token'), project_id)
				.subscribe((data) => {
					this.loadProjectsPage();
        });
  }

}
