import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Study } from '../../models/study';
import { UserService } from '../../services/user.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';


export class StudyDataSource extends DataSource<Study> {

  private studiesSubject = new BehaviorSubject<Study[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  data: Study[]=[];
  total_count: number;
  

  constructor(private userService: UserService) {
    super();
  }
  
  loadStudies(filter:string,
			sortField:string,
			sortDirection:string,
			pageIndex:number,
			pageSize:number) {
	console.log("testing");
	this.loadingSubject.next(true);

	this.userService.allStudies(localStorage.getItem('token'), filter, sortField, sortDirection,
		pageIndex, pageSize).pipe(
			catchError(() => of([])),
			finalize(() => this.loadingSubject.next(false))
		)
		.subscribe((allstudies) => {
			this.total_count = allstudies.total_count,
			this.studiesSubject.next(allstudies.studies)
		});
  }
  
  connect(collectionViewer: CollectionViewer): Observable<Study[]> {
	console.log("Connecting data source");
	return this.studiesSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
	this.studiesSubject.complete();
	this.loadingSubject.complete();
  }

  /**
  getUserData(): void {
	this.userService.allUsers(localStorage.getItem('token'))
		.subscribe(users => this.data = users.users);
	console.log(this.data);
  }
  

   connect(): Observable<User[]> {
	//this.getUserData();
    const dataMutations = [
      this.data, //this.userService.allUsers(localStorage.getItem('token')),
      this.paginator.page,
      this.sort.sortChange
    ];
	
    this.paginator.length = this.data.length;

    return merge(...dataMutations).pipe(map(() => {
      return this.getPagedData(this.getSortedData([...this.data]));
    }));
  }

  disconnect() {}

  private getPagedData(data: User[]) {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    return data.splice(startIndex, this.paginator.pageSize);
  }

  private getSortedData(data: User[]) {
    if (!this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort.direction === 'asc';
      switch (this.sort.active) {
        case 'first_name': return compare(a.first_name, b.first_name, isAsc);
        case 'last_name': return compare(+a.last_name, +b.last_name, isAsc);
        default: return 0;
      }
    });
  }
  */
}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
