import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { StudyDataSource } from './study-datasource';
import { UserService } from '../../services/user.service';
import { Study } from '../../models/study';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {animate, state, style, transition, trigger} from '@angular/animations';

@Component({
  selector: 'app-studies',
  templateUrl: './studies.component.html',
  styleUrls: ['./studies.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class StudiesComponent implements OnInit, AfterViewInit {

 @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: StudyDataSource;
  study: Study;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['study_id', 'title', 'phase', 'active', 'edit'];
  //expandedElement: dataSource | null;
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.study = this.route.snapshot.data["study"];
    this.dataSource = new StudyDataSource(this.userService);
    this.dataSource.loadStudies('', 'study_id', 'asc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadStudiesPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadStudiesPage())
	)
	.subscribe();
  }
  
  loadStudiesPage() {
	this.dataSource.loadStudies(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  newStudy() {
	this.router.navigateByUrl('/main/studies/new_study');
  }
  
  onRowClicked(row) {
    console.log('Row clicked: ', row);
  }
}
