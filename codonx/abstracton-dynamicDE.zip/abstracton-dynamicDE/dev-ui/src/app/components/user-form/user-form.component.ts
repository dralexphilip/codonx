import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { Role } from '../../models/role';
import { User } from '../../models/user';
import countries from '../../resources/countries.json';
import states from '../../resources/states.json';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit{
  
  hide = true;
  user: FormGroup;
  

  hasUnitNumber = false;
  countries = countries;
  states = states;

  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) {}

  roles: Role[] = [];
  
  
  getRoles(){
	  console.log('test');
	  this.auth.role_list(localStorage.getItem('token'), '', 'name', 'asc', 0, 15)
		.subscribe((data) => this.roles = data.roles);
  }
  onSubmit({ value, valid }: { value: User, valid: boolean }): void{
	if (valid)
		this.auth.newUser(localStorage.getItem('token'),value)
		.subscribe((data) => {
		  this.router.navigateByUrl('/main/users');
		});  
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/main/users');
  }
  
  ngOnInit() {
	this.getRoles();
	this.user = this.fb.group({
		username: [null, Validators.required],
		passkey: [null, Validators.required],
		first_name: [null, Validators.required],
		last_name: null,
		address: null,
		city: null,
		state: null,
		postalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
		roles: null,
		country: null
  });
  }
}
