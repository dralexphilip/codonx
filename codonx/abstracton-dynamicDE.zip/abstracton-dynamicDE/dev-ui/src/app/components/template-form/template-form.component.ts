import { AfterViewInit, Component, Inject, OnInit, ViewChild, Injectable, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Concept } from '../../models/concept';
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from '../select-users/select-users.component';
import { TemplateService } from '../../services/template.service';
import { catchError, finalize, map, startWith } from 'rxjs/operators';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Template } from '../../models/template';
import { FormlyFieldConfig } from '@ngx-formly/core';
import {CollectionViewer, SelectionChange, DataSource} from '@angular/cdk/collections';
import {NestedTreeControl} from '@angular/cdk/tree';
import {MatTreeNestedDataSource} from '@angular/material/tree';
import { DataitemService } from '../../services/dataitem.service';
import { SelectDataitemsComponent } from '../select-dataitems/select-dataitems.component';

const TREE_DATA: FormlyFieldConfig[] = [];

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit, AfterViewInit {

	@ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  hide = true;
	template: FormGroup;	
	fieldEditMode: boolean = false;
	editMode: boolean = false;
	code: string;
  dataitems: FormlyFieldConfig[];


  treeControl = new NestedTreeControl<FormlyFieldConfig>(node => node.fieldGroup);
  treeDataSource = new MatTreeNestedDataSource<FormlyFieldConfig>();
  dataChange = new BehaviorSubject<FormlyFieldConfig[]>([]);
  get data(): FormlyFieldConfig[] { return this.dataChange.value; }
  

  @Input()selected_dataitems: any;
  template_dataitems: FormlyFieldConfig[];


	constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute, private templateService: TemplateService, public dialog: MatDialog,
              private dataitemService: DataitemService) {

    this.dataChange.subscribe(data => {
      this.treeDataSource.data = data;
    });
    
	 }

   hasChild = (_: number, node: FormlyFieldConfig) => !!node.fieldGroup && node.fieldGroup.length > 0;

	 ngAfterViewInit() {
	   
	 }
	
	onSubmit({ value, valid }: { value: Template, valid: boolean }): void {
		
    
    console.log(value);
		if (this.editMode){			
			if (valid)
				value['code'] = this.template.getRawValue()['code'];
				this.templateService.updateTemplate(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/templates');
			});
		}
		else{
			if (valid)
				this.templateService.newTemplate(localStorage.getItem('token'), value)
				.subscribe((data) => {
					this.router.navigateByUrl('/main/templates');
			});  
		}
	}

	onCancel(): void {
		this.router.navigateByUrl('/main/templates');
	}

	ngOnInit() {

    this.dataitemService.dataitems(localStorage.getItem('token'),  '', 'id', 'asc', 0, 100).pipe(
      catchError(() => of([])),
      finalize(() => '')
      )
      .subscribe((dataitems) => {
          this.dataitems = dataitems.dataitems;          
      });

		this.template = this.fb.group({
			code: [{ value: null, disabled: false }, Validators.required],
			name: [null, Validators.required],
      description: null,
			fields: null
		});

		this.route.queryParams.subscribe((queryParams:any) => {
			this.code = queryParams['code'];
			if (this.code != null){
				this.viewTemplateDetail(this.code); 
			  	this.editMode = true;				  	
			}
			else {
			  this.editMode = false;
			  this.template.get('code').enable()
			}
		   });


       
		
	}
	
	

	viewTemplateDetail(code) {
		this.templateService.viewTemplateDetail(localStorage.getItem('token'), code).pipe(
				catchError(() => of([])),
				finalize(() => console.log('Success'))
			)
			.subscribe((data) => {					
				
				this.template.setValue(data.template);
        this.treeDataSource.data = data.template.fields;
        this.treeControl.expandAll;
				this.template.get('code').disable();				
			});  
	  }


    launchSFS(index, node: FormlyFieldConfig): void {
      const dialogRef = this.dialog.open(SelectDataitemsComponent, {
        width: '800px',
      data: {selected_dataitems:this.selected_dataitems}
      });
  
      dialogRef.afterClosed().subscribe(result => {
		
      if(result != '' && result != undefined && result != null){
		
		
		result.selected_dataitems.forEach(row => {
			if(row.templateOptions.options != null && row.templateOptions.options != '' && row.templateOptions.options != undefined)
				result.selected_dataitems[result.selected_dataitems.indexOf(row)].templateOptions.options = row.templateOptions.options.concepts;	
		  });
		result.selected_dataitems = cleanObject(result.selected_dataitems);
		  //console.log(cleanObject(result.selected_dataitems));
		/*  Form to fill when uploading the chart
		  var j = result.selected_dataitems.length
			while (j--) {
				result.selected_dataitems[j].templateOptions.addonRight.icon = clean(result.selected_dataitems[j].templateOptions.addonRight.icon);
				result.selected_dataitems[j].templateOptions.addonRight = clean(result.selected_dataitems[j].templateOptions.addonRight);
				result.selected_dataitems[j].validation.messages = clean(result.selected_dataitems[j].validation.messages);
				result.selected_dataitems[j].validation = clean(result.selected_dataitems[j].validation);
				result.selected_dataitems[j].templateOptions = clean(result.selected_dataitems[j].templateOptions);
				result.selected_dataitems[j] = clean(result.selected_dataitems[j]);
				
			}*/
		  console.log(result.selected_dataitems);
        if(node != '' && node != undefined && node != null){
          node.fieldGroup = result.selected_dataitems;  
          //this.treeDataSource.data.push(node);
          //this.treeDataSource.data.filter(item => item === node)[0].fieldGroup = result.selected_dataitems; 
          this.treeDataSource.data =[];
          this.dataChange.next(this.data);
          
        }
        else{
          for(var i = 0; i < result.selected_dataitems.length; i++){          
              this.treeDataSource.data.push(result.selected_dataitems[i]);
          }          
        }
      }
      this.dataChange.next(this.treeDataSource.data);
      this.template.patchValue({['fields']: this.treeDataSource.data});
      });
    }

    removeDataitem(node:FormlyFieldConfig){

    }

}

function clean(obj) {
	for (var propName in obj) {		
		if (obj[propName] === null || obj[propName] === undefined || obj[propName] ==='') {
			delete obj[propName];
		}
	}
	return obj
  }
  

  function cleanObject(object) {
    Object
        .entries(object)
        .forEach(([k, v]) => {
            if (v && typeof v === 'object')
                cleanObject(v);
            if (v && typeof v === 'object' && !Object.keys(v).length || v === null || v === undefined || v === '' ) {                
                delete object[k];
            }
        });
    return object;
}


/**************************************/
