import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AbstractionFormComponent } from './abstraction-form.component';

describe('AbstractionFormComponent', () => {
  let component: AbstractionFormComponent;
  let fixture: ComponentFixture<AbstractionFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AbstractionFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbstractionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
