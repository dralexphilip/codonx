import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { Tenant } from '../../models/tenant';

@Component({
  selector: 'app-register-business',
  templateUrl: './register-business.component.html',
  styleUrls: ['./register-business.component.css']
})
export class RegisterBusinessComponent implements OnInit {

  business_types: Tenant[] = [];
	
  hide = true;
  user: FormGroup;
	
  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) { }
  
    onSubmit({ value, valid }: { value: User, valid: boolean }): void{
	if (valid)
		this.auth.generate_otp(value)
		.subscribe((data) => {
		  localStorage.setItem('user', JSON.stringify(value));
		  this.router.navigateByUrl('/verifyotp');
		});  
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/login-page');
  }
  
  ngOnInit() {
	this.business_types = [
							{id: '1', name: 'Clinic'},
							{id: '2', name: 'Hospital'},
							{id: '3', name: 'Lab'},
							{id: '4', name: 'Pharmacy'}
						];
	this.user = this.fb.group({
	business_type: null,
	business_name: [null, Validators.required],
	email: [null, Validators.required],
	passkey: [null, Validators.required],
	first_name: [null, Validators.required]
  });
  }

}
