import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, Input, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { UsersDataSource } from '../users/users-datasource';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {SelectionModel} from '@angular/cdk/collections';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-select-users',
  templateUrl: './select-users.component.html',
  styleUrls: ['./select-users.component.css']
})
export class SelectUsersComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  displayedColumns = ['select', 'first_name', 'last_name', 'username'];
  dataSource: UsersDataSource;
  @Input()existing_users: any;
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService, public dialogRef: MatDialogRef<SelectUsersComponent>,@Inject(MAT_DIALOG_DATA) public data: DialogData) {
	  
	
  }
  
  ngOnInit() {
    this.dataSource = new UsersDataSource(this.userService);
    this.dataSource.loadUsers('', 'first_name', 'asc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
	//this.dataSource.forEach(row=> console.log(row))
	console.log(this.dataSource.total_count);
	
	
	
	
  }
  
  
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadUsersPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadUsersPage())
	)
	.subscribe();
	
	
	
	
  }
  
  loadUsersPage() {
	this.dataSource.loadUsers(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
	
  }

  onCancel(): void {
    this.dialogRef.close();
  }
  
  addSelectedUsers(){
	this.data.selected_users = this.selection.selected;
  }
  
 
  selection = new SelectionModel<User>(true, []);
  
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
	 //console.log(this.dataSource.data);
	
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.total_count;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row: User, i): string {
	
	this.dataSource.data.forEach(row => {
		if(this.data.existing_users != null)
		this.data.existing_users.forEach(user=> {
			if(row.username == user.username){
				console.log(row)
				this.selection.select(row)
			}
		})		
	});
	
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${i + 1}`;
  }

}

export interface DialogData {
  selected_users: any;
  existing_users: any;
}