import {Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormGroupDirective} from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { UploadService } from '../../services/upload.service';
import { Chart } from '../../models/chart';
import { map, catchError, finalize } from 'rxjs/operators';
import { Subject, Observable, of } from 'rxjs';
import {MatAccordion} from '@angular/material/expansion';
import states from '../../resources/states.json';
import {ActivatedRoute} from '@angular/router';
import { FormlyFieldConfig, FormlyFormOptions } from '@ngx-formly/core';

@Component({
  selector: 'app-chart-detail',
  templateUrl: './chart-detail.component.html',
  styleUrls: ['./chart-detail.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ChartDetailComponent implements OnInit {

  @ViewChild('file', { static: false }) file;
  @ViewChild(FormGroupDirective, { static: false }) formDirective: FormGroupDirective;
  @ViewChild(MatAccordion, { static: false }) accordion: MatAccordion; 
  public files: Set<File> = new Set();
  showChartDetail = true;
  selectedFile = null;  
  uploading = false;  
  chart: FormGroup;  
  charts: Chart[] = [];
  filename;
  genders = ["Male", "Female", "Other"];
  step = 3;
  states = states;
  chart_id;
  src;
  viewfilename;
  statuses = ['Uploaded', 'Review in-progress', 'Ready for Abstraction', 'Review Failed']
  reasons = ["Chart content not legible", "Artifacts in Chart", "Chart not loading", "Chart has multiple patient details", "Insufficient content in chart"]
  created_date;
  showReviewFailedField = false;
  readyForAbstraction = false;
  
  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[];
  chart_status;
  project_id;


			

  constructor(private fb: FormBuilder, private router: Router, private service: UserService, public uploadService: UploadService, private route: ActivatedRoute) { }
  
  onSubmit({ value, valid }: { value: Chart, valid: boolean }): void{
	  //console.log(this.chart.value); 
	//this.uploading = true;
	//let status = 0;
	//if (valid){
		//let data: any =	this.uploadService.upload(this.selectedFile); 
		
		//for(let file_status in data)
			//{				
				//let file_observable: any = data[file_status].progress;
				//console.log(file_observable);
				//file_observable.subscribe(resp => {
				//	status = resp;
				//	console.log(status);
					//if (status === 100) {
						this.service.updateChart(localStorage.getItem('token'), JSON.stringify(this.form.value))
							.subscribe((data) => {
							  //this.uploading = false;
							  //this.files.delete(this.selectedFile);
							 // this.showChartDetail=false;
							  //this.chart.reset();
							  //this.formDirective.resetForm();
							  //var iterator = this.files.values();
							  //if (this.files.size != 0){
								//this.selectFile(iterator.next().value);
								//console.log(data);
								this.router.navigateByUrl('/main/charts');
							  }
							); 
					//}
				//});
				
				
                
			//}
	
	//}
	
  }

  ngOnInit() {
	   this.chart = this.fb.group({
		chart_id: [null, Validators.required],
		patient_id: [null, Validators.required],
		project_id: [null, Validators.required],
		lastname: [null, Validators.required], 
		firstname: [null, Validators.required],
		middlename: null,
		dob: null,
		age: [null, Validators.compose([Validators.minLength(1), Validators.maxLength(3)])],
		gender: [null, Validators.required],
		address: null,
		city: null,
		state: null,		
		postalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
		cplastname: null, 
		cpfirstname: null,
		cpmiddlename: null,
		cpaddress: null,
		cpcity: null,
		cpstate: null,		
		cppostalCode: [null, Validators.compose([Validators.minLength(5), Validators.maxLength(5)])],
		npi: null,
		facility: null,
		chart_status: null,
		review_comments: null,
		fail_reason: null
  });

	this.route.queryParams.subscribe((queryParams:any) => {
		//console.log(queryParams);
      this.chart_id = queryParams['chart_id'];
	  this.project_id = queryParams['project_id'];
	  this.chart_status = queryParams['chart_status'];

	  //this.viewfilename = queryParams['filename'];
     });	
 
	this.viewChartDetail(this.chart_id); 
	this.viewChart(this.chart_id);
	this.getInitialTemplate(this.project_id, this.chart_status)
	
  }
  
  onFilesAdded(event) {
    const files: { [key: string]: File } = this.file.nativeElement.files;
	
    for (let key in files) {
      if (!isNaN(parseInt(key))) {
        this.files.add(files[key]);
      }	  
    }
	let first_file = this.file.nativeElement.files[0];
	this.selectFile(first_file);
  }

  addFiles() {
    this.file.nativeElement.click();
  }


  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
	  const element = event[index];
	  if(index == 0) {
		  this.selectFile(element);
		}
      
      this.files.add(element)
    }  	
	
	
  }
  deleteAttachment(file) {
    this.files.delete(file);
	this.showChartDetail=false;
  }
   
  selectFile(file) {
	this.selectedFile = file;	
	this.filename = file.name.replace(/\s/g, "");
	this.chart.patchValue({'filename':this.filename});
	//this.chart.patchValue({'status':'Uploaded'});
	this.showChartDetail = true;	
	var iterator = this.files.values();
  }
  
  onCancel(){
	this.router.navigateByUrl('/main/charts');
  }
  
  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
  
  viewChartDetail(chart_id) {
	this.service.viewChartDetail(localStorage.getItem('token'), chart_id).pipe(
			catchError(() => of([])),
			finalize(() => console.log('Success'))
		)
		.subscribe((data) => {
			this.created_date = data.chart.created_date.$date;
			console.log(this.created_date)
			delete data.chart['created_date'];
			if ('fail_reason' in data.chart == false)
				data.chart['fail_reason'] = '';
			if ('review_comments' in data.chart == false)
				data.chart['review_comments'] = '';
			//this.chart.setValue(data.chart);
			this.model = data.chart;
			console.log(this.chart.get('chart_status').value);
			this.reviewFailCheck(this.chart.value.chart_status);
			//if (this.chart.value.chart_status == 'Ready for Abstraction') {		
			//  this.readyForAbstraction = true;
			//} else {
			//  this.readyForAbstraction = false;
			//}
		});  
		
  }
  
  viewChart(filename) {
	this.service.downloadChart(localStorage.getItem('token'), filename).subscribe(response => this.viewFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
				 
  }
  viewFile(data: any, type: string) {
		let blob = new Blob([data], { type: type});
        this.src = window.URL.createObjectURL(blob);
        //window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
  }

  onSelectionChanged({value}) {
    this.reviewFailCheck(value);	
  }
  
  reviewFailCheck(value){
	if (value === 'Review Failed') {		
      this.showReviewFailedField = true;
    } else {
      this.showReviewFailedField = false;
    }
  }
  
  previewChart() {
	this.service.downloadChart(localStorage.getItem('token'), this.chart_id).subscribe(response => this.previewFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
	this.showChartDetail = false;				 
	
	//window.open('/main/charts/view_chart?filename='+filename, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800")
  }
  
  previewFile(data: any, type: string) {
		
		let blob = new Blob([data], { type: type});
        let url = window.URL.createObjectURL(blob);
        window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
  }
  
  splitView() {
	this.showChartDetail = true;
  }

  getInitialTemplate(project_id, chart_status){
	//const chart_status = 'START';
	this.service.viewProjectDetail(localStorage.getItem('token'), project_id)
		.subscribe((data) => {
			console.log(data.project.workflow.states[0].template.fields)
		  	this.fields = data.project.workflow.states.find(x => x.code === 'UPLOAD').template.fields;
	});
  }

}
