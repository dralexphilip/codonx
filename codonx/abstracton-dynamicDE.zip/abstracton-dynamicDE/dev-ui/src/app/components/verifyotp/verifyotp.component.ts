import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';

@Component({
  selector: 'app-verifyotp',
  templateUrl: './verifyotp.component.html',
  styleUrls: ['./verifyotp.component.css']
})
export class VerifyotpComponent implements OnInit {

  user: FormGroup; 
  registration: User = JSON.parse(localStorage.getItem('user'));
  business_name = this.registration['business_name'];
  
  
  ngOnInit() {
 
  this.user = this.fb.group({
    otp: [null, Validators.required],
	passkey: this.registration['passkey'],
	email: this.registration['email'],
	first_name: this.registration['first_name'],
	business_name: this.registration['business_name'],
	business_type: this.registration['business_type'],
  });
  

  
  //this.registration.otp = this.user.value.otp;
  }
  
  
  constructor(private fb: FormBuilder, private router: Router, private auth: UserService) {}

  
  onSubmit({ value, valid }: { value: User, valid: boolean }): void {
	if (valid){
		if (this.registration['business_name']){
			this.auth.register_business(value)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main');
			});
		}		
		else
		{
			this.auth.register(value)
			.subscribe((data) => {
			  this.router.navigateByUrl('/main');
			});
		}
	}
  }
  
  onCancel(): void {
	this.router.navigateByUrl('/main');
  }  

}
