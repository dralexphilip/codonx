import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ChartDataSource } from './chart-datasource';
import { UserService } from '../../services/user.service';
import { Chart } from '../../models/chart';
import { debounceTime, distinctUntilChanged, startWith, tap, delay } from 'rxjs/operators';
import { merge, fromEvent } from 'rxjs';
import {animate, state, style, transition, trigger} from '@angular/animations';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ChartsComponent implements OnInit, AfterViewInit {

 @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('input', { static: false }) input: ElementRef;
  
  dataSource: ChartDataSource;
  chart: Chart;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['chart_id', 'lastname', 'firstname', 'age', 'gender', 'project_id', 'chart_status', 'created_date', 'edit', 'view', 'download', 'delete'];
  innerColumns = ['chart_id', 'chart_status', 'gender', 'middlename',]
  problemColumns = ['code', 'name'];
  //expandedElement: dataSource | null;
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.chart = this.route.snapshot.data["chart"];
    this.dataSource = new ChartDataSource(this.userService);
    this.dataSource.loadCharts('', 'created_date', 'desc', 0, 10);
    //this.dataSource = new UsersDataSource(this.userService, this.paginator, this.sort);
  }
  
  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

	fromEvent(this.input.nativeElement,'keyup')
		.pipe(
			debounceTime(150),
			distinctUntilChanged(),
			tap(() => {
				this.paginator.pageIndex = 0;

				this.loadChartsPage();
			})
		)
		.subscribe();

	merge(this.sort.sortChange, this.paginator.page)
	.pipe(
		tap(() => this.loadChartsPage())
	)
	.subscribe();
  }
  
  loadChartsPage() {
	this.dataSource.loadCharts(
	this.input.nativeElement.value,
	this.sort.active,
	this.sort.direction,
	this.paginator.pageIndex,
	this.paginator.pageSize);
  }
  
  newChart() {
	this.router.navigateByUrl('/main/charts/new_chart');
  }
  
  viewChart(filename) {
	this.userService.downloadChart(localStorage.getItem('token'), filename).subscribe(response => this.viewFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
				 
	
	//window.open('/main/charts/view_chart?filename='+filename, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800")
  }
  
  downloadChart(filename) {	  
	 this.userService.downloadChart(localStorage.getItem('token'), filename).subscribe(response => this.downloadFile(response, "application/pdf")),
                 error => console.log('Error downloading the file.'),
                 () => console.info('OK');
  }
  
  onRowClicked(row) {
    console.log('Row clicked: ', row);
  }
  
  downloadFile(data: any, type: string) {
        let blob = new Blob([data], { type: type});
        let url = window.URL.createObjectURL(blob);
		var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = 'ccda_pdf.pdf';
        link.click();
        window.URL.revokeObjectURL(link.href);
		//for opening in another window
        //let pwa = window.open(url);
        //if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
        //    alert( 'Please disable your Pop-up blocker and try again.');
        //}
    }
	
	
  viewFile(data: any, type: string) {
		let blob = new Blob([data], { type: type});
        let url = window.URL.createObjectURL(blob);
        window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=800,height=800");
  }
  
  editChart(row) {
	this.router.navigateByUrl('/main/charts/chart_detail'+'?chart_id='+row.chart_id+'&project_id='+row.project_id+'&chart_status='+row.chart_status);
  }

  deleteChart(chart_id) {
    this.userService.deleteChart(localStorage.getItem('token'), chart_id)
				.subscribe((data) => {
					this.loadChartsPage();
        });
  }
}
