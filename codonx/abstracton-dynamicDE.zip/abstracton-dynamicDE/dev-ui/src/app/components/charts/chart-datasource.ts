import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { map, catchError, finalize } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Chart } from '../../models/chart';
import { UserService } from '../../services/user.service';
import { BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';


export class ChartDataSource extends DataSource<Chart> {

  private chartsSubject = new BehaviorSubject<Chart[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  data: Chart[]=[];
  total_count: number;
  

  constructor(private userService: UserService) {
    super();
  }
  
  loadCharts(filter:string,
			sortField:string,
			sortDirection:string,
			pageIndex:number,
			pageSize:number) {
	console.log("testing");
	this.loadingSubject.next(true);

	this.userService.allCharts(localStorage.getItem('token'), filter, sortField, sortDirection,
		pageIndex, pageSize).pipe(
			catchError(() => of([])),
			finalize(() => this.loadingSubject.next(false))
		)
		.subscribe((allcharts) => {
			this.total_count = allcharts.total_count,
			this.chartsSubject.next(allcharts.charts)
		});
  }
  
  connect(collectionViewer: CollectionViewer): Observable<Chart[]> {
	console.log("Connecting data source");
	return this.chartsSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
	this.chartsSubject.complete();
	this.loadingSubject.complete();
  }

}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
