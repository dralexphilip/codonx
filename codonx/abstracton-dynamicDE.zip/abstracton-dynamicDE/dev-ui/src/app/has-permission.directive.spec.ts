import { HasPermissionDirective } from './has-permission.directive';

describe('HasPermissionDirective', () => {
  it('should create an instance', () => {
    const directive = new HasPermissionDirective();
    expect(directive).toBeTruthy();
  });
});
