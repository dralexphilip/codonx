import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class LoginRedirectService {
  constructor(private auth: UserService, private router: Router) {}
  canActivate(): boolean {
  const token = localStorage.getItem('token');
    if (token) {
	  this.router.navigateByUrl('/main');
	  return false;		
    }
	else {
	  return true;
	}    
  }
}
