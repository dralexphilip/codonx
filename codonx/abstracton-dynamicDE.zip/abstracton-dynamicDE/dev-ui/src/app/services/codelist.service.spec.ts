import { TestBed } from '@angular/core/testing';

import { CodelistService } from './codelist.service';

describe('CodelistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CodelistService = TestBed.get(CodelistService);
    expect(service).toBeTruthy();
  });
});
