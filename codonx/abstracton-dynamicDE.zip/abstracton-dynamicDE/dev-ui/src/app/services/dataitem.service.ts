import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class DataitemService {
  private BASE_URL: string = environment.apiUrl;
  
  constructor(private http: HttpClient) {}
  
  dataitems(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/dataitems`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				        .set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  newDataitem(token, dataitem): Observable<any> {
    let url: string = `${this.BASE_URL}/new_dataitem`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, dataitem, {headers: httpOptions});
  }

  viewDataitemDetail(token, id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/dataitem_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('id', id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  updateDataitem(token, dataitem): Observable<any> {
    let url: string = `${this.BASE_URL}/update_dataitem`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, dataitem, {headers: httpOptions});
  }

  deleteDataitem(token, id): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_dataitem?id=`+id;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }
} 
