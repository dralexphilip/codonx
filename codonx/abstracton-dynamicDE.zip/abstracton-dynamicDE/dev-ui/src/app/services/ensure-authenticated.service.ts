import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UserService } from './user.service';


@Injectable()
export class EnsureAuthenticated implements CanActivate {
  
  constructor(private auth: UserService, private router: Router) { }
  
  canActivate(): boolean {    
	let token = localStorage.getItem('token');
    if (token) {
		this.auth.ensureAuthenticated(token).subscribe((data) => {
			console.log('Token Valid!'+token);			
		},
		error => {
			console.log('Error:', error);
			localStorage.removeItem('token');
			this.router.navigateByUrl('/login');
			return false;
		});
		//let jwtData = token.split('.')[1];
		//let decodedJwtJsonData = window.atob(jwtData);
		//let decodedJwtData = JSON.parse(decodedJwtJsonData);
		//console.log('Is admin: ' + decodedJwtData.identity.roles + this.router.url);
		//if (decodedJwtData.identity.roles==='Admin' && this.router.url === '/')
			
		return true;
	  }
	  else {
		this.router.navigateByUrl('/login');
		return false;
      }
    }

}
