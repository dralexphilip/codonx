import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpRequest,
  HttpEventType,
  HttpResponse,
  HttpHeaders
} from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { environment } from '../../environments/environment'

//const url = 'http://localhost:5000/upload_file';

//const httpOptions = {
//  headers: new HttpHeaders({
//    'Content-Type':  'multipart/form-data'
//  })
//};

@Injectable()
export class UploadService {
  token = localStorage.getItem('token');
  private BASE_URL: string = environment.apiUrl;
  
  constructor(private http: HttpClient) { }

  public upload(file: File, project_id, chart_id): { [key: string]: { progress: Observable<number> } } {
    // this will be the our resulting map
    const status: { [key: string]: { progress: Observable<number> } } = {};

    //files.forEach(file => {
      // create a new multipart-form for every file
      const formData: FormData = new FormData();
      formData.append('file', file, file.name);
      formData.append('project_id', project_id);
      formData.append('chart_id', chart_id);

      // create a http-post request and pass the form
      // tell it to report the upload progress
	  let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${this.token}`
    });
	  let url: string = `${this.BASE_URL}/`+'upload_file';
      const req = new HttpRequest('POST', url, formData, {
        reportProgress: true,
		headers: httpOptions
      });

      // create a new progress-subject for every file
      const progress = new Subject<number>();
	  const filedetails: any = null;

      // send the http-request and subscribe for progress-updates

      const startTime = new Date().getTime();
      this.http.request(req).subscribe(event => {
        if (event.type === HttpEventType.UploadProgress) {
          // calculate the progress percentage

          const percentDone = Math.round((100 * event.loaded) / event.total);
          // pass the percentage into the progress-stream
          progress.next(percentDone);
        } else if (event instanceof HttpResponse) {
          // Close the progress-stream if we get an answer form the API
          // The upload is complete
		  //console.log(event);
          progress.complete();		  
		  
        }
      });
      // Save every progress-observable in a map of all observables
      status[file.name] = {
        progress: progress.asObservable()
      };
    //});

    // return the map of progress.observables
    return status;
  }
  
}