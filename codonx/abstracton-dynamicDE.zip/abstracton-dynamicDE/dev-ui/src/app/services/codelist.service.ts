import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class CodelistService {
  private BASE_URL: string = environment.apiUrl;
  
  constructor(private http: HttpClient) {}
  
  codelists(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/codelists`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				        .set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  newCodelist(token, codelist): Observable<any> {
    let url: string = `${this.BASE_URL}/new_codelist`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, codelist, {headers: httpOptions});
  }

  viewCodelistDetail(token, code:string): Observable<any> {
    let url: string = `${this.BASE_URL}/codelist_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('code', code);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  updateCodelist(token, codelist): Observable<any> {
    let url: string = `${this.BASE_URL}/update_codelist`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, codelist, {headers: httpOptions});
  }

  deleteCodelist(token, code): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_codelist?code=`+code;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }

  getCodelistConcepts(token, code:string): Observable<any> {
    let url: string = `${this.BASE_URL}/codelist_concepts`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('code', code);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
} 
