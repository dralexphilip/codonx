import { TestBed } from '@angular/core/testing';

import { DataitemService } from './dataitem.service';

describe('DataitemService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataitemService = TestBed.get(DataitemService);
    expect(service).toBeTruthy();
  });
});
