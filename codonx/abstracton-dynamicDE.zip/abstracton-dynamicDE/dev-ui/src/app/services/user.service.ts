import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { Role } from '../models/role';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private BASE_URL: string = environment.apiUrl;
  
  constructor(private http: HttpClient) {}
  
  login(user: User):Observable<any>{
    let url: string = `${this.BASE_URL}/login`;
    return this.http.post(url, user, httpOptions);
  }
  
  generate_otp(user: User): Observable<any> {
    let url: string = `${this.BASE_URL}/generate_otp`;
    return this.http.post(url, user, httpOptions);
  }
  
  register(user: User): Observable<any> {
    let url: string = `${this.BASE_URL}/register`;
    return this.http.post(url, user, httpOptions);
  }
  
  register_business(user: User): Observable<any> {
    let url: string = `${this.BASE_URL}/register_business`;
    return this.http.post(url, user, httpOptions);
  }
  
  newUser(token, user): Observable<any> {
    let url: string = `${this.BASE_URL}/new_user`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, user, {headers: httpOptions});
  }
  
  ensureAuthenticated(token): Observable<any> {
    let url: string = `${this.BASE_URL}/ensure_auth`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.get(url, {headers: httpOptions});
  }
  
  logout(token): Observable<any> {
    let url: string = `${this.BASE_URL}/logout/access`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, null, {headers: httpOptions});
  }
  
  userDetail(token): Observable<any> {
    let url: string = `${this.BASE_URL}/secret`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.get(url, {headers: httpOptions});
  }
  
  allUsers(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/users`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  allRoles(token, filter = '', sortField:'name', sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/roles`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.get(url, {headers: httpOptions});
  }
  
  role_list(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/roles`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  newRole(token, role): Observable<any> {
    let url: string = `${this.BASE_URL}/new_role`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, role, {headers: httpOptions});
  }
  
  privilege_list(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/privileges`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
    allStudies(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/studies`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  newAbstraction(token, study): Observable<any> {
    let url: string = `${this.BASE_URL}/new_abstraction`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, study, {headers: httpOptions});
  }
  
  upload(token, formData): Observable<any> {
    let url: string = `${this.BASE_URL}/upload_file`;
    let httpOptions1 = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, formData, {headers: httpOptions1});
  }
  
  
  allCharts(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/charts`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  newChart(token, chart): Observable<any> {
    let url: string = `${this.BASE_URL}/new_chart`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, chart, {headers: httpOptions});
  }
  
  updateChart(token, chart): Observable<any> {
    let url: string = `${this.BASE_URL}/update_chart`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, chart, {headers: httpOptions});
  }
  
  viewChart(token, filename:string): Observable<any> {
    let url: string = `${this.BASE_URL}/view_chart`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filename', filename);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  viewChartDetail(token, chart_id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/chart_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('chart_id', chart_id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  downloadChart(token, filename:string): Observable<any> {
    let url: string = `${this.BASE_URL}/download_chart`;
    let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filename', filename);
    return this.http.get(url, {
            params: params,
			responseType: 'arraybuffer',
		    headers: httpOptions
        });
  }

  deleteChart(token, chart_id): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_chart?chart_id=`+chart_id;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }
  
  
    allInvestigators(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/investigators`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  newInvestigator(token, user): Observable<any> {
    let url: string = `${this.BASE_URL}/new_investigator`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, user, {headers: httpOptions});
  }
  
  getTemplate(token, abstract_id): Observable<any> {
	//return this.http.get('assets/default-template.json');
	  
	let url: string = `${this.BASE_URL}/get_template`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('abstract_id', abstract_id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
    });
  }
  
  
  allProjects(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/projects`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  newProject(token, project, file: File, src: File): Observable<any> {
    let url: string = `${this.BASE_URL}/new_project`;
    let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
    const formData: FormData = new FormData();
    if(file)
      formData.append('file', file, file.name);
    if(src)
      formData.append('src', src, src.name);
    const mData = JSON.stringify(project);
    formData.append('data', mData);
    return this.http.post(url, formData, {headers: httpOptions});
  }
  
  updateProject(token, project, file: File, src: File): Observable<any> {
    let url: string = `${this.BASE_URL}/update_project`;
    let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
    const formData: FormData = new FormData();
    if(file)
      formData.append('file', file, file.name);
    if(src)
      formData.append('src', src, src.name);
    const mData = JSON.stringify(project);
    formData.append('data', mData);
    return this.http.post(url, formData, {headers: httpOptions});
  }
  
  viewProjectDetail(token, project_id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/project_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('project_id', project_id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  updateProjectStatus(token, project_id, project_status): Observable<any> {
    let url: string = `${this.BASE_URL}/project_status`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('project_id', project_id)
				.set('project_status', project_status);
    return this.http.post(url,  {
            params: params,
		    headers: httpOptions
        });
  }

  deleteProject(token, project_id): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_project?project_id=`+project_id;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }
  
  allAbstractions(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/abstractions`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  viewAbstractionDetail(token, abstract_id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/abstraction_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('abstract_id', abstract_id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  updateAbstraction(token, abstraction): Observable<any> {
    let url: string = `${this.BASE_URL}/update_abstraction`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, abstraction, {headers: httpOptions});
  }
  
  deleteAbstraction(token, abstract_id): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_abstraction?abstract_id=`+abstract_id;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }
  
  initiateExtract(token, project_id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/extract_data`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('project_id', project_id);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }
  
  downloadExtract(token, project_id:string): Observable<any> {
    let url: string = `${this.BASE_URL}/download_extract`;
    let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${token}`,
	  'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
    });
	let params = new HttpParams()                
                .set('project_id', project_id);
    return this.http.get(url, {
            params: params,
			responseType: 'arraybuffer',
		    headers: httpOptions
        });
  }

  updateQA(token, abstraction): Observable<any> {
    let url: string = `${this.BASE_URL}/update_qa`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, abstraction, {headers: httpOptions});
  }
  
  getCdaXsl(): Observable<any> {
	  
	  let httpOptions = new HttpHeaders({
		'Content-Type': 'text/xml',
		'Accept': 'text/xml'
	  });
	  return this.http.get("/assets/CDA.xsl", { responseType: "text" });
  }
  
  allQAReviews(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/qareviews`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				.set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  getXmlContent(token, file: File, project_id): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    formData.append('project_id', project_id);
    let url: string = `${this.BASE_URL}/get_xml_content`;
    let httpOptions = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, formData, {headers: httpOptions});
  }
  
}

