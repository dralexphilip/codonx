import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class TemplateService {
  private BASE_URL: string = environment.apiUrl;
  
  constructor(private http: HttpClient) {}
  
  templates(token, filter = '', sortField:string, sortDirection = 'asc', pageIndex = 0, pageSize = 3): Observable<any> {
    let url: string = `${this.BASE_URL}/templates`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('filter', filter)
				        .set('sortField', sortField)
                .set('sortDirection', sortDirection)
                .set('pageIndex', pageIndex.toString())
                .set('pageSize', pageSize.toString());
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  newTemplate(token, template): Observable<any> {
    let url: string = `${this.BASE_URL}/new_template`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, template, {headers: httpOptions});
  }

  viewTemplateDetail(token, code:string): Observable<any> {
    let url: string = `${this.BASE_URL}/template_detail`;
    let httpOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
	let params = new HttpParams()                
                .set('code', code);
    return this.http.get(url, {
            params: params,
		    headers: httpOptions
        });
  }

  updateTemplate(token, template): Observable<any> {
    let url: string = `${this.BASE_URL}/update_template`;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.post(url, template, {headers: httpOptions});
  }

  deleteTemplate(token, code): Observable<any> {
    let url: string = `${this.BASE_URL}/delete_template?code=`+code;
    let httpOptions = new HttpHeaders({
	  'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
    return this.http.delete(url, {headers: httpOptions});
  }
} 
