import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './components/login/login.component';
import { MatInputModule, MatButtonModule, MatSelectModule, MatRadioModule, MatCardModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatListModule, MatMenuModule, MatGridListModule, MatTableModule, MatPaginatorModule, MatSortModule, MatProgressSpinnerModule, MatStepperModule, MatDialogModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatCheckboxModule, MatTooltipModule, MatSnackBarModule, MatTabsModule, MatSlideToggleModule, MatAutocompleteModule, MatTreeModule, MatChipsModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { LayoutModule } from '@angular/cdk/layout';
import { MainComponent } from './components/main/main.component';
import { HomeComponent } from './components/home/home.component';
import { UsersComponent } from './components/users/users.component';
import { RolesComponent } from './components/roles/roles.component';
import { PermissionsComponent } from './components/permissions/permissions.component';
import { EnsureAuthenticated } from './services/ensure-authenticated.service';
import { LoginRedirectService } from './services/login-redirect.service';
import { UploadService } from './services/upload.service';
import { UserFormComponent } from './components/user-form/user-form.component';
import { RegisterComponent } from './components/register/register.component';
import { RegisterBusinessComponent } from './components/register-business/register-business.component';
import { VerifyotpComponent } from './components/verifyotp/verifyotp.component';
import { StudiesComponent } from './components/studies/studies.component';
import { StudyFormComponent } from './components/study-form/study-form.component'; 
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { DragDropDirective } from './drag-drop.directive';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ChartsComponent } from './components/charts/charts.component';
import { NewChartComponent } from './components/new-chart/new-chart.component';
import { ViewChartComponent } from './components/view-chart/view-chart.component';
import { HasPermissionDirective } from './has-permission.directive';
import { InvestigatorsComponent } from './components/investigators/investigators.component';
import { InvestigatorFormComponent } from './components/investigator-form/investigator-form.component';
import { FacilitiesComponent } from './components/facilities/facilities.component';
import { FormBuildrComponent } from './components/form-buildr/form-buildr.component';
import { RoleFormComponent } from './components/role-form/role-form.component';
import { ProjectsComponent } from './components/projects/projects.component';
import { QaReviewComponent } from './components/qa-review/qa-review.component';
import { AdjudicationComponent } from './components/adjudication/adjudication.component';
import { TenantsComponent } from './components/tenants/tenants.component';
import { AbstractionComponent } from './components/abstraction/abstraction.component';
import { AbstractionFormComponent } from './components/abstraction-form/abstraction-form.component';
import { FormlyModule } from '@ngx-formly/core';
import { FormlyMaterialModule } from '@ngx-formly/material';
import { AbstractFormComponent } from './components/abstract-form/abstract-form.component';
import { PanelWrapperComponent } from './components/abstract-form/panel-wrapper.component';
import { FormlyFieldStepper } from './components/abstract-form/stepper.type';
import { ChartDetailComponent } from './components/chart-detail/chart-detail.component';
import { RowWrapperComponent } from './components/abstract-form/row-wrapper.component';
import { AccordionWrapperComponent } from './components/abstract-form/accordion-wrapper.component';
import { FormlyMatDatepickerModule } from '@ngx-formly/material/datepicker';
import { ProjectFormComponent } from './components/project-form/project-form.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { FormlyWrapperAddons } from './components/abstract-form/addons.wrapper';
import { addonsExtension } from './components/abstract-form/addons.extension';
import { SelectUsersComponent } from './components/select-users/select-users.component';
import { CodelistsComponent } from './components/codelists/codelists.component';
import { CodelistFormComponent, DialogCodeForm } from './components/codelist-form/codelist-form.component';
import { FormsModule } from '@angular/forms';
import { DataitemsComponent } from './components/dataitems/dataitems.component';
import { DataitemFormComponent } from './components/dataitem-form/dataitem-form.component';
import { TemplatesComponent } from './components/templates/templates.component';
import { TemplateFormComponent } from './components/template-form/template-form.component';
import { TreetableModule } from 'ng-material-treetable';
import { SelectDataitemsComponent } from './components/select-dataitems/select-dataitems.component';
import { WorkflowsComponent } from './components/workflows/workflows.component';
import { DialogStateForm, WorkflowFormComponent } from './components/workflow-form/workflow-form.component';
import { FormlyFieldStepperHorizontal } from './components/abstract-form/stepper.horizontal';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainComponent,
    HomeComponent,
    UsersComponent,
    RolesComponent,
    PermissionsComponent,
    UserFormComponent,
    RegisterComponent,
	RegisterBusinessComponent,
    VerifyotpComponent,
    StudiesComponent,
    StudyFormComponent,
	DragDropDirective,
	ChartsComponent,
	NewChartComponent,
	ViewChartComponent,
	HasPermissionDirective,
	InvestigatorsComponent,
	InvestigatorFormComponent,
	FacilitiesComponent,
	FormBuildrComponent,
	RoleFormComponent,
	ProjectsComponent,
	QaReviewComponent,
	AdjudicationComponent,
	TenantsComponent,
	AbstractionComponent,
	AbstractionFormComponent,
	AbstractFormComponent,
	PanelWrapperComponent,
	FormlyFieldStepper,
	ChartDetailComponent,
	RowWrapperComponent,
	AccordionWrapperComponent,
	ProjectFormComponent,
	FormlyWrapperAddons,
	SelectUsersComponent,
	CodelistsComponent,
	CodelistFormComponent,
	DialogCodeForm,
	DataitemsComponent,
	DataitemFormComponent,
	TemplatesComponent,
	TemplateFormComponent,
	SelectDataitemsComponent,
	WorkflowsComponent,
	WorkflowFormComponent,
	DialogStateForm,
	FormlyFieldStepperHorizontal
  ],
  imports: [
    BrowserModule,
	FormsModule,
	ReactiveFormsModule,
	HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,    
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
	MatMenuModule,
	MatGridListModule,
	MatTableModule,
	MatPaginatorModule,
	MatSortModule,
	MatProgressSpinnerModule,
	MatStepperModule,
	MatProgressBarModule,
	MatDialogModule,
	MatExpansionModule,
	MatDatepickerModule, 
	MatNativeDateModule, 
	MatCheckboxModule,
	MatTooltipModule,
	MatSnackBarModule,
	MatTabsModule, 
	MatSlideToggleModule,
	MatAutocompleteModule,
	MatTreeModule,
	MatChipsModule,
	DragDropModule,	
	PdfViewerModule,
	TreetableModule,
	FormlyMatDatepickerModule,
	FormlyModule.forRoot({ 
		extras: { lazyRender: true },
		validationMessages: [
        { name: 'required', message: 'This field is required' },
        { name: 'minlength', message: minlengthValidationMessage },
        { name: 'maxlength', message: maxlengthValidationMessage },
        { name: 'min', message: minValidationMessage },
        { name: 'max', message: maxValidationMessage },
      ],
	  types: [
        { name: 'stepper', component: FormlyFieldStepper }, 
		{ name: 'stepperHorizontal', component: FormlyFieldStepperHorizontal }, 
		//{ name: 'abstract-form', component: AbstractFormComponent , wrappers: ['form-field']},//, wrappers: ['form-field']
      ],
       wrappers: [
        { name: 'panel', component: PanelWrapperComponent },
		{ name: 'rowwrap', component: RowWrapperComponent },
		{ name: 'accwrap', component: AccordionWrapperComponent },
		{ name: 'addons', component: FormlyWrapperAddons },
      ],
	  extensions: [
        { name: 'addons', extension: { onPopulate: addonsExtension } },
      ],
	}),
	FormlyMaterialModule
  ],
  entryComponents: [
	  SelectUsersComponent,
	  DialogCodeForm,
	  SelectDataitemsComponent,
	  DialogStateForm

	],
  providers: [EnsureAuthenticated,
	LoginRedirectService,
	UploadService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


export function minlengthValidationMessage(err, field) {
	return `Should have atleast ${field.templateOptions.minLength} characters`;
  }
  
  export function maxlengthValidationMessage(err, field) {
	return `This value should be less than ${field.templateOptions.maxLength} characters`;
  }
  
  export function minValidationMessage(err, field) {
	return `This value should be more than ${field.templateOptions.min}`;
  }
  
  export function maxValidationMessage(err, field) {
	return `This value should be less than ${field.templateOptions.max}`;
  }