import { State } from "./state";

export class Workflow {
    code: string;
    name: string;
    description: string;
    states: State[];

    constructor(code?: string, name?: string, description?: string, states?: State[]) { }
}