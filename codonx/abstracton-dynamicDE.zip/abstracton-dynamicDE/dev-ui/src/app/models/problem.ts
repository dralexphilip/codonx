export class Problem {
  code: string;
  name: string;
  system_code: string;
  system_name: string;
  problem_date: string;
  problem_type: string

  constructor(
	code?: string,
	name?: string,
	system_code?: string,
	system_name?: string,
	problem_date?: string,
	problem_type?: string
	) {}
}
