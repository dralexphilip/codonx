export class Role {
  role_id: string;
  role_name: string;
  
  constructor(role_id?: string, role_name?: string) {}
}
