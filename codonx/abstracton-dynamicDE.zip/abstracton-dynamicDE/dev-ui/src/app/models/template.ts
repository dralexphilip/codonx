export class Template {
    code: string;
    name: string;
    description: string;
    fields: any;

    constructor(code?: string, name?: string, description?: string, fields?: any) { }
}