import { Role } from '../models/role'
import { Tenant } from '../models/tenant'

export class User {
  username: string;
  password: string;
  first_name: string;
  last_name: string;
  middle_name: string;
  gender: string;
  age: string;
  qualification: string;
  speciality: string;
  clinical_exp: string;
  study_exp: string;
  rf: string;
  tel: string;
  address: string;
  city: string;
  state: string;
  postal_code: string;
  active: string;
  tenant: Tenant;
  business_name: string;
  business_type: string;
  email: string;
  passkey: string;
  otp: string;
  roles: Role[];

  constructor(
  username?: string, 
  password?: string, 
  first_name?: string, 
  last_name?: string, 
  middle_name?: string,
  gender?: string,
  age?: string,
  qualification?: string,
  speciality?: string,
  clinical_exp?: string,
  study_exp?: string,
  rf?: string,
  tel?: string,
  address?: string, 
  city?: string, 
  state?: string, 
  postal_code?: string, 
  active?: string, 
  tenant?: Tenant,
  business_name?: string,
  business_type?: string,
  otp?: string, 
  roles?: string
  ) {}
}
