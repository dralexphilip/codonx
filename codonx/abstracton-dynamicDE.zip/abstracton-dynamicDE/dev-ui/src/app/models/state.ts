import { Template } from "./template";

export class State {
    code: string;
    name: string;
    description: string;
    allowedStates: string[];
    template: Template;
    isManual: boolean;
    isBlinded: boolean;

    constructor(value?: string, label?: string, description?: string, allowedStates?: string[], template?: any, isManual?: boolean, isBlinded?: boolean ) { }
}