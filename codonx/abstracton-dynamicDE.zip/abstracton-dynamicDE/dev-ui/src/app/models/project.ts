import { Tenant } from '../models/tenant'

export class Project {
  project_id: string;
  name: string; 
  description: string;
  customer: string;
  project_status: string;
  created_date: string;
  start_date: string;
  end_date: string;
  project_type: string;
  qa_review: string;
  percentage: string;
  template_data: any;
  data_access: any;
  tenant_id: string;
  
  constructor(
  project_id?: string, 
  name?: string, 
  description?: string, 
  customer?: string, 
  project_status?: string, 
  created_date?: string, 
  start_date?: string, 
  end_date?: string, 
  project_type?: string,
  qa_review?: string,
  percentage?: string,
  template_data?: any,
  data_access?: any,
  tenant_id?: string
  ) {}
}
