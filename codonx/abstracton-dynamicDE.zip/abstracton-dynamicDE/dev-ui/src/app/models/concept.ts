export class Concept {
    value: string;
    label: string;
    description: string;

    constructor(value?: string, label?: string, description?: string) { }
}