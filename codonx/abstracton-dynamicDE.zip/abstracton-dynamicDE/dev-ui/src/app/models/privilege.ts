export class Privilege {
  privilege_id: string;
  privilege_name: string;
  
  constructor(privilege_id?: string, privilege_name?: string) {}
}
