export class Study {
  study_id: string;
  type: string;
  title: string;
  phase: string;
  description: string;
  primary_obj: string;
  secondary_obj: string;
  start_date: string;
  end_date: string;
  active: string;

  constructor(
	study_id?: string,
	type?: string,
	title?: string, 
	phase?: string, 
	description?: string, 
	primary_obj?: string,
	secondary_obj?: string,
	start_date?: string,
	end_date?: string,
	active?: string) {}
}
