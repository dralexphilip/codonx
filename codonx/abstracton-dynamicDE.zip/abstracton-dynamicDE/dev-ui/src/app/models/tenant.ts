export class Tenant {
  id: string;
  name: string; 
  
  constructor(id?: string, name?: string) {}
}
