import { Concept } from '../models/concept'

export class Codelist {
    code: string;
    name: string;
    description: string;
    concepts: Concept[];

    constructor(code?: string, name?: string, description?: string, concepts?: string) { }
}
