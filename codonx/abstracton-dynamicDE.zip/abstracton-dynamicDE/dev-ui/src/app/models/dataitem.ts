import { AbstractControl } from "@angular/forms";
import { FormlyFieldConfig } from "@ngx-formly/core";
import { TemplateOption } from "./templateoption";

export class DataItem {
    key: string;
    //id: string;
    //name: string;
    type: string;
    className: string;


    templateOptions: TemplateOption;


    template: string;
    defaultValue: any;
    hide: boolean;
    hideExpression: boolean|string|any;
    //expressionProperties: boolean|string|any;
    //focus: boolean;
    wrappers: string[];
    //parsers: any;
    ////fieldGroup: FormlyFieldConfig[];
    ////fieldArray: FormlyFieldConfig;
    ////fieldGroupClassName: string;
    validation: object;
    //validators: any;
    //asyncValidators: any;
    //formControl: AbstractControl;
    //modelOptions: object;

    constructor(
        key?: string,
        id?: string,
        name?: string,
        type?: string,
        className?: string,
        templateOptions?: object,
        template?: string,
        defaultValue?: any,
        hide?: boolean,
        hideExpression?: boolean|string|any,
        expressionProperties?: boolean|string|any,
        focus?: boolean,
        wrappers?: string[],
        parsers?: any,
        fieldGroup?: FormlyFieldConfig[],
        fieldArray?: FormlyFieldConfig,
        fieldGroupClassName?: string,
        validation?: object,
        validators?: any,
        asyncValidators?: any,
        formControl?: AbstractControl,
        modelOptions?: object,
    ) { }
}