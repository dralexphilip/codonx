import { Problem } from '../models/problem';

export class Encounter {
  code: string;
  date: string;
  details: string;
  desc: string;
  problems: Problem[];

  constructor(
	code?: string,
	date?: string,
	details?: string,
	desc?: string,
	problems?: Problem[]
	) {}
}
