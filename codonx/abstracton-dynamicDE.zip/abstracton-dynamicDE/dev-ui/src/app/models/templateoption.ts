export class TemplateOption {
    type: string;
    label: string;
    required: boolean;
    placeholder: string;
    description: string;
    icon: string;
    expand: boolean;
    addonRight: any;
    addonLeft: any;
    maxLength: number;
    minLength: number;
    min: number;
    max: number;
    rows: number;
    pattern: string;

    constructor(
        type?: string,
        label?: string,
        required?: boolean,
        placeholder?: string,
        description?: string,
        icon?: string,
        expand?: boolean,
        addonRight?: any,
        addonLeft?: any,
        maxLength?: number,
        minLength?: number,
        min?: number,
        max?: number,
        rows?: number,
        pattern?: string,
    ) { }
}