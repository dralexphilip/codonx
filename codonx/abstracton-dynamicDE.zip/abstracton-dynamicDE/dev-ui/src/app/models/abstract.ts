import { Chart } from '../models/chart';

export class Abstract {
  abstract_id: string;
  abstract_date: string;
  abstract_by: string;
  chart_id: string;
  project_id: string;
  abstract_created_date: string;
  abstract_status:string;
  chart: Chart;
  data: any;
  qa_data: any;
  nlp_data: any;

  constructor(
	abstract_id?: string,
	abstract_date?: string,
	abstract_by?: string,
	chart_id?: string,
	project_id?: string,
	abstract_created_date?: string,
	abstract_status?:string,
	chart?: Chart,
	data?: any,
	qa_data?: any,
	nlp_data?:any
	) {}
}
