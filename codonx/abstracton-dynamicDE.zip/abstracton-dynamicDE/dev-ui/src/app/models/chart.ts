import { Problem } from '../models/problem';

export class Chart {
  chart_id: string;
  patient_id: string;
  project_id: string;
  patient_name: string;
  firstname: string;
  lastname: string;
  middlename: string;
  dob: string;
  age: string;
  gender: string;
  filename: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  chart_status: string;
  cpfirstname: string;
  cplastname: string;
  cpmiddlename: string;
  cpaddress: string;
  cpcity: string;
  cpstate: string;
  cppostalCode: string;
  npi: string;
  facility: string;
  review_comments: string;
  problems: Problem[]

  constructor(
	chart_id?: string,
	patient_id?: string,
	project_id?: string,
	patient_name?: string,
	firstname?: string,
	lastname?: string,
	middlename?: string,
	dob?: string,
	age?: string,
	gender?: string,
	filename?: string,
	address?:string,
	city?: string,
	state?: string,
	postalCode?: string,
	chart_status?: string,
	cpfirstname?: string,
	cplastname?: string,
	cpmiddlename?: string,
	cpaddress?:string,
	cpcity?: string,
	cpstate?: string,
	cppostalCode?: string,
	npi?: string,
	facility?: string,
	review_comments?: string,
	problems?: Problem[]
	) {}
}
