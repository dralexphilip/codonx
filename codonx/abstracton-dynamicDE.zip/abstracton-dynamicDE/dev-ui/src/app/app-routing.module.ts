import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MainComponent } from './components/main/main.component';
import { HomeComponent } from './components/home/home.component';
import { UsersComponent } from './components/users/users.component';
import { RolesComponent } from './components/roles/roles.component';
import { PermissionsComponent } from './components/permissions/permissions.component';
import { EnsureAuthenticated } from './services/ensure-authenticated.service';
import { LoginRedirectService } from './services/login-redirect.service';
import { UserFormComponent } from './components/user-form/user-form.component';
import { RoleFormComponent } from './components/role-form/role-form.component';
import { RegisterComponent } from './components/register/register.component';
import { VerifyotpComponent } from './components/verifyotp/verifyotp.component';
import { ChartsComponent } from './components/charts/charts.component';
import { NewChartComponent } from './components/new-chart/new-chart.component';
import { ViewChartComponent } from './components/view-chart/view-chart.component';
import { RegisterBusinessComponent } from './components/register-business/register-business.component';
import { StudiesComponent } from './components/studies/studies.component';
import { StudyFormComponent } from './components/study-form/study-form.component';
import { InvestigatorsComponent } from './components/investigators/investigators.component';
import { InvestigatorFormComponent } from './components/investigator-form/investigator-form.component';
import { FacilitiesComponent } from './components/facilities/facilities.component';
import { FormBuildrComponent } from './components/form-buildr/form-buildr.component'
import { ProjectsComponent } from './components/projects/projects.component';
import { QaReviewComponent } from './components/qa-review/qa-review.component';
import { AdjudicationComponent } from './components/adjudication/adjudication.component';
import { TenantsComponent } from './components/tenants/tenants.component';
import { AbstractionComponent } from './components/abstraction/abstraction.component';
import { AbstractFormComponent } from './components/abstract-form/abstract-form.component';
import { ChartDetailComponent } from './components/chart-detail/chart-detail.component';
import { ProjectFormComponent } from './components/project-form/project-form.component';
import { CodelistsComponent } from './components/codelists/codelists.component';
import { CodelistFormComponent } from './components/codelist-form/codelist-form.component';
import { DataitemsComponent } from './components/dataitems/dataitems.component';
import { DataitemFormComponent } from './components/dataitem-form/dataitem-form.component';
import { TemplatesComponent } from './components/templates/templates.component';
import { TemplateFormComponent } from './components/template-form/template-form.component';
import { WorkflowsComponent } from './components/workflows/workflows.component';
import { WorkflowFormComponent } from './components/workflow-form/workflow-form.component';

const routes: Routes = [
  { path: '', redirectTo: '/login-page', pathMatch: 'full' },
  { path: 'register', component: RegisterComponent },
  { path: 'verifyotp', component: VerifyotpComponent },
  { path: 'register_business', component: RegisterBusinessComponent },
  { path: 'login-page', component: LoginComponent, canActivate: [LoginRedirectService] },
  { path: 'main', component: MainComponent, canActivate: [EnsureAuthenticated],
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: HomeComponent, canActivate: [EnsureAuthenticated] },
      { path: 'users', component: UsersComponent, canActivate: [EnsureAuthenticated] },
      { path: 'roles', component: RolesComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'roles/new_role', component: RoleFormComponent, canActivate: [EnsureAuthenticated] },
      { path: 'permissions', component: PermissionsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'users/new_user', component: UserFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'charts', component: ChartsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'charts/new_chart', component: NewChartComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'charts/view_chart', component: ViewChartComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'charts/chart_detail', component: ChartDetailComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'studies', component: StudiesComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'studies/new_study', component: StudyFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'projects', component: ProjectsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'projects/new_project', component: ProjectFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'abstraction', component: AbstractionComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'abstraction/new_abstraction', component: AbstractFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'qa-review', component: QaReviewComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'qa-review/new_abstraction', component: AbstractFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'adjudication', component: AdjudicationComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'tenants', component: TenantsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'register_business', component: RegisterBusinessComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'investigators', component: InvestigatorsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'investigators/new_investigator', component: InvestigatorFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'facilities', component: FacilitiesComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'form-buildr', component: FormBuildrComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'codelists', component: CodelistsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'codelists/new_codelist', component: CodelistFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'dataitems', component: DataitemsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'dataitems/new_dataitem', component: DataitemFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'templates', component: TemplatesComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'templates/new_template', component: TemplateFormComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'workflows', component: WorkflowsComponent, canActivate: [EnsureAuthenticated] },
	  { path: 'workflows/new_workflow', component: WorkflowFormComponent, canActivate: [EnsureAuthenticated] },
    ] 
  },
  { path: '**', redirectTo: '/login-page', pathMatch: 'full' }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
